#ifndef EFL_GENERATED_EFL_GFX_STACK_HH
#define EFL_GENERATED_EFL_GFX_STACK_HH

extern "C"
{
#include <Efl.h>
}
#include <Eo.hh>

#include <eo_cxx_interop.hh>

extern "C"
{
#include "efl_gfx_stack.eo.h"
}


namespace efl { namespace gfx {

struct stack;

} }

/// @cond EO_CXX_ABSTRACT
namespace eo_cxx {

namespace efl { namespace gfx {

struct stack
{
   /// @brief Stack @p obj immediately below @p below
   ///
   /// Objects, in a given canvas, are stacked in the order they get added
   /// to it.  This means that, if they overlap, the highest ones will
   /// cover the lowest ones, in that order. This function is a way to
   /// change the stacking order for the objects.
   ///
   /// This function is intended to be used with <b>objects belonging to
   /// the same layer</b> in a given canvas, otherwise it will fail (and
   /// accomplish nothing).
   ///
   /// If you have smart objects on your canvas and @p obj is a member of
   /// one of them, then @p below must also be a member of the same
   /// smart object.
   ///
   /// Similarly, if @p obj is not a member of a smart object, @p below
   /// must not be either.
   ///
   /// @see evas_object_layer_get()
   /// @see evas_object_layer_set()
   /// @see evas_object_stack_below()
   ///
   /// @param below the object below which to stack
   ///
   void stack_below(Efl_Gfx_Stack * below_) const;

   /// @brief Raise @p obj to the top of its layer.
   ///
   /// @p obj will, then, be the highest one in the layer it belongs
   /// to. Object on other layers won't get touched.
   ///
   /// @see evas_object_stack_above()
   /// @see evas_object_stack_below()
   /// @see evas_object_lower()
   ///
   void raise() const;

   /// @brief Stack @p obj immediately above @p above
   ///
   /// Objects, in a given canvas, are stacked in the order they get added
   /// to it.  This means that, if they overlap, the highest ones will
   /// cover the lowest ones, in that order. This function is a way to
   /// change the stacking order for the objects.
   ///
   /// This function is intended to be used with <b>objects belonging to
   /// the same layer</b> in a given canvas, otherwise it will fail (and
   /// accomplish nothing).
   ///
   /// If you have smart objects on your canvas and @p obj is a member of
   /// one of them, then @p above must also be a member of the same
   /// smart object.
   ///
   /// Similarly, if @p obj is not a member of a smart object, @p above
   /// must not be either.
   ///
   /// @see evas_object_layer_get()
   /// @see evas_object_layer_set()
   /// @see evas_object_stack_below()
   ///
   /// @param above the object above which to stack
   ///
   void stack_above(Efl_Gfx_Stack * above_) const;

   /// @brief Lower @p obj to the bottom of its layer.
   ///
   /// @p obj will, then, be the lowest one in the layer it belongs
   /// to. Objects on other layers won't get touched.
   ///
   /// @see evas_object_stack_above()
   /// @see evas_object_stack_below()
   /// @see evas_object_raise()
   ///
   void lower() const;

   /// @brief Retrieves the layer of its canvas that the given object is part of.
   ///
   /// @return  Number of its layer
   ///
   /// @see evas_object_layer_set()
   ///
   /// @param l The number of the layer to place the object on.
   /// Must be between #EVAS_LAYER_MIN and #EVAS_LAYER_MAX.
   ///
   short layer_get() const;

   /// @brief Sets the layer of its canvas that the given object will be part of.
   ///
   /// If you don't use this function, you'll be dealing with an @b unique
   /// layer of objects, the default one. Additional layers are handy when
   /// you don't want a set of objects to interfere with another set with
   /// regard to @b stacking. Two layers are completely disjoint in that
   /// matter.
   ///
   /// This is a low-level function, which you'd be using when something
   /// should be always on top, for example.
   ///
   /// @warning Be careful, it doesn't make sense to change the layer of
   /// smart objects' children. Smart objects have a layer of their own,
   /// which should contain all their children objects.
   ///
   /// @see evas_object_layer_get()
   ///
   /// @param l The number of the layer to place the object on.
   /// Must be between #EVAS_LAYER_MIN and #EVAS_LAYER_MAX.
   ///
   void layer_set(short l_) const;

   /// @brief Get the Evas object stacked right below @p obj
   ///
   /// @return the #Efl_Gfx_Stack directly below @p obj, if any, or @c NULL,
   /// if none
   ///
   /// This function will traverse layers in its search, if there are
   /// objects on layers below the one @p obj is placed at.
   ///
   /// @see evas_object_layer_get()
   /// @see evas_object_layer_set()
   /// @see evas_object_below_get()
   ///
   Efl_Gfx_Stack * below_get() const;

   /// @brief Get the Evas object stacked right above @p obj
   ///
   /// @return the #Efl_Gfx_Stack directly above @p obj, if any, or @c NULL,
   /// if none
   ///
   /// This function will traverse layers in its search, if there are
   /// objects on layers above the one @p obj is placed at.
   ///
   /// @see evas_object_layer_get()
   /// @see evas_object_layer_set()
   /// @see evas_object_below_get()
   ///
   Efl_Gfx_Stack * above_get() const;



   static Eo_Class const* _eo_class()
   {
      return(EFL_GFX_STACK_INTERFACE);
   }

   operator ::efl::gfx::stack() const;
   operator ::efl::gfx::stack&();
   operator ::efl::gfx::stack const&() const;

   /// @cond LOCAL
   template <typename D>
   struct address_of
   {
      operator ::efl::gfx::stack*() const { return static_cast<::efl::gfx::stack*>(static_cast<D const*>(this)->p); }
      operator ::efl::gfx::stack const*() const { return static_cast<::efl::gfx::stack const*>(static_cast<D const*>(this)->p); }
   };

   template <typename D>
   struct address_const_of
   {
      operator ::efl::gfx::stack const*() const { return static_cast<::efl::gfx::stack const*>(static_cast<D const*>(this)->p); }
   };
   /// @endcond

private:

   /// @internal
   Eo* _concrete_eo_ptr() const
   {
      return static_cast<::efl::eo::concrete const*>(static_cast<void const*>(this))->_eo_ptr();
   }

};

} }

}
/// @endcond

namespace efl { namespace gfx {

/// @brief Class stack
struct stack
      : ::efl::eo::concrete
{
   //@{
   /**
      @brief Constructs a new efl::gfx::stack object.

      Constructs a new efl::gfx::stack object. If you want this object to be a child
      of another Eo object, use an @ref efl::eo::parent expression, like the example.

      Example:
      @code
      efl::gfx::stack my_stack(efl::eo::parent = parent_object);
      @endcode

      @see stack(Eo* eo)
   */
   explicit stack(::efl::eo::parent_type _p)
      : stack(_ctors_call(_p))
   {}

   explicit stack()
      : stack(_ctors_call(::efl::eo::parent = nullptr))
   {}
   //@}

   /// @brief Eo Constructor.
   ///
   /// Constructs the object from an Eo* pointer stealing its ownership.
   ///
   /// @param eo The Eo object pointer.
   ///
   explicit stack(Eo* eo)
      : ::efl::eo::concrete(eo)
   {}

   /// @brief nullptr_t Constructor.
   ///
   /// Constructs an empty (null) object.
   ///
   explicit stack(std::nullptr_t)
      : ::efl::eo::concrete(nullptr)
   {}

   /// @brief Copy Constructor.
   ///
   stack(stack const& other)
      : stack(eo_ref(other._eo_ptr()))
   {}

   ~stack() {}

   /// @brief Stack @p obj immediately below @p below
   ///
   /// Objects, in a given canvas, are stacked in the order they get added
   /// to it.  This means that, if they overlap, the highest ones will
   /// cover the lowest ones, in that order. This function is a way to
   /// change the stacking order for the objects.
   ///
   /// This function is intended to be used with <b>objects belonging to
   /// the same layer</b> in a given canvas, otherwise it will fail (and
   /// accomplish nothing).
   ///
   /// If you have smart objects on your canvas and @p obj is a member of
   /// one of them, then @p below must also be a member of the same
   /// smart object.
   ///
   /// Similarly, if @p obj is not a member of a smart object, @p below
   /// must not be either.
   ///
   /// @see evas_object_layer_get()
   /// @see evas_object_layer_set()
   /// @see evas_object_stack_below()
   ///
   /// @param below the object below which to stack
   ///
   void stack_below(Efl_Gfx_Stack * below_) const;

   /// @brief Raise @p obj to the top of its layer.
   ///
   /// @p obj will, then, be the highest one in the layer it belongs
   /// to. Object on other layers won't get touched.
   ///
   /// @see evas_object_stack_above()
   /// @see evas_object_stack_below()
   /// @see evas_object_lower()
   ///
   void raise() const;

   /// @brief Stack @p obj immediately above @p above
   ///
   /// Objects, in a given canvas, are stacked in the order they get added
   /// to it.  This means that, if they overlap, the highest ones will
   /// cover the lowest ones, in that order. This function is a way to
   /// change the stacking order for the objects.
   ///
   /// This function is intended to be used with <b>objects belonging to
   /// the same layer</b> in a given canvas, otherwise it will fail (and
   /// accomplish nothing).
   ///
   /// If you have smart objects on your canvas and @p obj is a member of
   /// one of them, then @p above must also be a member of the same
   /// smart object.
   ///
   /// Similarly, if @p obj is not a member of a smart object, @p above
   /// must not be either.
   ///
   /// @see evas_object_layer_get()
   /// @see evas_object_layer_set()
   /// @see evas_object_stack_below()
   ///
   /// @param above the object above which to stack
   ///
   void stack_above(Efl_Gfx_Stack * above_) const;

   /// @brief Lower @p obj to the bottom of its layer.
   ///
   /// @p obj will, then, be the lowest one in the layer it belongs
   /// to. Objects on other layers won't get touched.
   ///
   /// @see evas_object_stack_above()
   /// @see evas_object_stack_below()
   /// @see evas_object_raise()
   ///
   void lower() const;

   /// @brief Retrieves the layer of its canvas that the given object is part of.
   ///
   /// @return  Number of its layer
   ///
   /// @see evas_object_layer_set()
   ///
   /// @param l The number of the layer to place the object on.
   /// Must be between #EVAS_LAYER_MIN and #EVAS_LAYER_MAX.
   ///
   short layer_get() const;

   /// @brief Sets the layer of its canvas that the given object will be part of.
   ///
   /// If you don't use this function, you'll be dealing with an @b unique
   /// layer of objects, the default one. Additional layers are handy when
   /// you don't want a set of objects to interfere with another set with
   /// regard to @b stacking. Two layers are completely disjoint in that
   /// matter.
   ///
   /// This is a low-level function, which you'd be using when something
   /// should be always on top, for example.
   ///
   /// @warning Be careful, it doesn't make sense to change the layer of
   /// smart objects' children. Smart objects have a layer of their own,
   /// which should contain all their children objects.
   ///
   /// @see evas_object_layer_get()
   ///
   /// @param l The number of the layer to place the object on.
   /// Must be between #EVAS_LAYER_MIN and #EVAS_LAYER_MAX.
   ///
   void layer_set(short l_) const;

   /// @brief Get the Evas object stacked right below @p obj
   ///
   /// @return the #Efl_Gfx_Stack directly below @p obj, if any, or @c NULL,
   /// if none
   ///
   /// This function will traverse layers in its search, if there are
   /// objects on layers below the one @p obj is placed at.
   ///
   /// @see evas_object_layer_get()
   /// @see evas_object_layer_set()
   /// @see evas_object_below_get()
   ///
   Efl_Gfx_Stack * below_get() const;

   /// @brief Get the Evas object stacked right above @p obj
   ///
   /// @return the #Efl_Gfx_Stack directly above @p obj, if any, or @c NULL,
   /// if none
   ///
   /// This function will traverse layers in its search, if there are
   /// objects on layers above the one @p obj is placed at.
   ///
   /// @see evas_object_layer_get()
   /// @see evas_object_layer_set()
   /// @see evas_object_below_get()
   ///
   Efl_Gfx_Stack * above_get() const;



   static Eo_Class const* _eo_class()
   {
      return(EFL_GFX_STACK_INTERFACE);
   }

   /// @cond LOCAL
   struct address_of
      : ::eo_cxx::efl::gfx::stack::address_of<address_of>
      , ::efl::eo::detail::concrete_address_of
   {
      explicit address_of(::efl::gfx::stack* p)
         : ::efl::eo::detail::concrete_address_of(p)
      {}
   };
   address_of operator&() { return address_of(this); }

   struct address_const_of
      : ::eo_cxx::efl::gfx::stack::address_const_of<address_const_of>
      , ::efl::eo::detail::concrete_address_const_of
   {
      explicit address_const_of(::efl::gfx::stack const* p)
         : ::efl::eo::detail::concrete_address_const_of(p)
      {}
   };
   address_const_of operator&() const { return address_const_of(this); }

   /// @endcond

private:

   /// @internal
   static Eo* _ctors_call(::efl::eo::parent_type _p)
   {
      Eo* _ret_eo = eo_add_ref(EFL_GFX_STACK_INTERFACE, _p._eo_raw);

      return _ret_eo;
   }

   /// @internal
   Eo* _concrete_eo_ptr() const { return _eo_ptr(); }
};

static_assert(sizeof(::efl::gfx::stack) == sizeof(Eo*), "");
static_assert(std::is_standard_layout<::efl::gfx::stack>::value, "");

} }


#include "efl_gfx_stack.eo.impl.hh"

#endif // EFL_GENERATED_EFL_GFX_STACK_HH

