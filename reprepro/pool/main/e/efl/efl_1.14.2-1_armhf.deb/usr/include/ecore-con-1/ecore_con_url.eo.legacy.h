#ifndef _ECORE_CON_URL_EO_LEGACY_H_
#define _ECORE_CON_URL_EO_LEGACY_H_

#ifndef _ECORE_CON_URL_EO_CLASS_TYPE
#define _ECORE_CON_URL_EO_CLASS_TYPE

typedef Eo Ecore_Con_Url;

#endif

#ifndef _ECORE_CON_URL_EO_TYPES
#define _ECORE_CON_URL_EO_TYPES


#endif

/**
 *
 * No description supplied.
 *
 * @param[in] url The URL
 */
EAPI Eina_Bool ecore_con_url_url_set(Ecore_Con_Url *obj, const char *url);

/**
 *
 * No description supplied.
 *
 */
EAPI const char *ecore_con_url_url_get(const Ecore_Con_Url *obj);

#endif
