#ifndef EFL_GENERATED_EDJE_OBJECT_HH
#define EFL_GENERATED_EDJE_OBJECT_HH

extern "C"
{
#include <Efl.h>
}
#include <Eo.hh>

#include <eo_cxx_interop.hh>

extern "C"
{
#include "edje_object.eo.h"
}

#include "evas_smart_clipped.eo.hh"
#include "efl_file.eo.hh"
#include <Edje.h>
#include <canvas/evas_object.eo.hh>
#include <string>

namespace edje {

struct object;

}

/// @cond EO_CXX_ABSTRACT
namespace eo_cxx {

namespace edje {

struct object
{
   /// @brief @brief Removes all object from the table.
   ///
   /// @return @c EINA_TRUE clear the table, @c EINA_FALSE on failure
   ///
   /// Removes all object from the table indicated by part, except the
   /// internal ones set from the theme.
   ///
   /// @param part The part name
   /// @param clear If set, will delete subobjs on remove
   ///
   bool part_table_clear(::efl::eina::string_view part_, bool clear_) const;

   /// @brief Facility to query the type of the given parameter of the given part.
   ///
   /// @return @c EDJE_EXTERNAL_PARAM_TYPE_MAX on errors, or another value
   /// from #Edje_External_Param_Type on success.
   ///
   /// @param part The part name
   /// @param[out] param the parameter name to use.
   ///
   Edje_External_Param_Type part_external_param_type_get(::efl::eina::string_view part_, const char* param_) const;

   /// @brief @brief Enables selection if the entry is an EXPLICIT selection mode
   /// type.
   ///
   /// The default is to @b not allow selection. This function only affects user
   /// selection, functions such as edje_object_part_text_select_all() and
   /// edje_object_part_text_select_none() are not affected.
   ///
   /// @param part The part name
   /// @param allow EINA_TRUE to enable, EINA_FALSE otherwise
   ///
   void part_text_select_allow_set(::efl::eina::string_view part_, bool allow_) const;

   /// @brief @brief Returns the state of the Edje part.
   ///
   /// @return The part state:\n
   /// "default" for the default state\n
   /// "" for other states
   ///
   /// @param part The part name
   /// @param[out] val_ret 
   ///
   ::efl::eina::string_view part_state_get(::efl::eina::string_view part_, double* val_ret_) const;

   /// @brief Delete a function and matching user data from the markup filter list.
   ///
   /// Delete the given @p func filter and @p data user data from the list
   /// in @p part.
   /// Returns the user data pointer given when added.
   ///
   /// @see edje_object_text_markup_filter_callback_add
   /// @see edje_object_text_markup_filter_callback_del
   ///
   /// @return The same data pointer if successful, or NULL otherwise
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param func The function callback to remove
   /// @param data The data passed to the callback function
   ///
   void * text_markup_filter_callback_del_full(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_) const;

   /// @brief @brief Sets the drag step increment.
   ///
   /// Sets the x,y step increments for a dragable object.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1,
   /// representing the relative size of the dragable area on that axis by which the
   /// part will be moved.
   ///
   /// @see edje_object_part_drag_step_get()
   ///
   /// @param part The part name
   /// @param dx The x step amount
   /// @param dy The y step amount
   ///
   bool part_drag_step_set(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Gets the drag step increment values.
   ///
   /// Gets the x and y step increments for the dragable object.
   ///
   ///
   /// @see edje_object_part_drag_step_set()
   ///
   /// @param part The part
   /// @param[out] dx The x step increment pointer
   /// @param[out] dy The y step increment pointer
   ///
   bool part_drag_step_get(::efl::eina::string_view part_, double* dx_, double* dy_) const;

   /// @brief @brief Get the input method context in entry.
   ///
   /// If ecore_imf was not available when edje was compiled, this function returns NULL
   /// otherwise, the returned pointer is an Ecore_IMF
   ///
   /// @return The input method context (Ecore_IMF_Context *) in entry
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void * part_text_imf_context_get(::efl::eina::string_view part_) const;

   /// @brief @brief Starts selecting at current cursor position
   ///
   /// @param part The part name
   ///
   void part_text_select_begin(::efl::eina::string_view part_) const;

   /// @brief @brief Return the text of the object part.
   ///
   /// @return The text string
   ///
   /// This function returns the style associated with the textblock part.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   ::efl::eina::string_view part_text_style_user_peek(::efl::eina::string_view part_) const;

   /// @brief @brief Remove a signal-triggered callback from an object.
   ///
   /// @return The data pointer
   ///
   /// This function removes a callback, previously attached to the
   /// emittion of a signal, from the object @a obj. The parameters @a
   /// emission, @a source and @a func must match exactly those passed to
   /// a previous call to edje_object_signal_callback_add(). The data
   /// pointer that was passed to this call will be returned.
   ///
   /// @see edje_object_signal_callback_add().
   /// @see edje_object_signal_callback_del_full().
   ///
   /// @param emission The emission string.
   /// @param source The source string.
   /// @param func The callback function.
   /// @param data The callback function.
   ///
   template <typename F_func_>
   void * signal_callback_del(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_) const;

   /// @brief @brief Advances the cursor to the next cursor position.
   /// @see evas_textblock_cursor_char_next
   ///
   /// @param part The part name
   /// @param cur The edje cursor to advance
   ///
   bool part_text_cursor_next(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Set the style of the
   ///
   /// This function sets the style associated with the textblock part.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param style The style to set (textblock conventions).
   ///
   void part_text_style_user_push(::efl::eina::string_view part_, ::efl::eina::string_view style_) const;

   /// @brief @brief Insert text for an object part.
   ///
   /// This function inserts the text for an object part at the end; It does not
   /// move the cursor.
   ///
   /// @since 1.1
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   void part_text_append(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Retrieve the geometry of a given Edje part, in a given Edje
   /// object's group definition, <b>relative to the object's area</b>
   ///
   /// This function gets the geometry of an Edje part within its
   /// group. The @p x and @p y coordinates are relative to the top left
   /// corner of the whole @p obj object's area.
   ///
   /// @note Use @c NULL pointers on the geometry components you're not
   /// interested in: they'll be ignored by the function.
   ///
   /// @note On failure, this function will make all non-@c NULL geometry
   /// pointers' pointed variables be set to zero.
   ///
   /// @param part The Edje part's name
   /// @param[out] x A pointer to a variable where to store the part's x
   /// coordinate
   /// @param[out] y A pointer to a variable where to store the part's y
   /// coordinate
   /// @param[out] w A pointer to a variable where to store the part's width
   /// @param[out] h A pointer to a variable where to store the part's height
   ///
   bool part_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const;

   /// @brief @brief Hide the input panel (virtual keyboard).
   /// @see edje_object_part_text_input_panel_show
   ///
   /// Note that input panel is shown or hidden automatically according to the focus state.
   /// This API can be used in the case of manually controlling by using edje_object_part_text_input_panel_enabled_set.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void part_text_input_panel_hide(::efl::eina::string_view part_) const;

   /// @brief @brief Return item geometry.
   ///
   /// @return 1 if item exists, 0 if not
   ///
   /// This function return a list of Evas_Textblock_Rectangle item
   /// rectangles.
   ///
   /// @param part The part name
   /// @param item The item name
   /// @param[out] cx Item x return (relative to entry part)
   /// @param[out] cy Item y return (relative to entry part)
   /// @param[out] cw Item width return
   /// @param[out] ch Item height return
   ///
   bool part_text_item_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view item_, Evas_Coord* cx_, Evas_Coord* cy_, Evas_Coord* cw_, Evas_Coord* ch_) const;

   /// @brief @brief Removes an object from the table.
   ///
   /// @return @c EINA_TRUE object removed, @c EINA_FALSE on failure
   ///
   /// Removes an object from the table indicated by part.
   ///
   /// @param part The part name
   /// @param child_obj The object to pack in
   ///
   bool part_table_unpack(::efl::eina::string_view part_, ::evas::object child_obj_) const;

   /// @brief @brief Aborts any selection action on a part.
   ///
   /// @param part The part name
   ///
   void part_text_select_abort(::efl::eina::string_view part_) const;

   /// @brief Delete a function and matching user data from the filter list.
   ///
   /// Delete the given @p func filter and @p data user data from the list
   /// in @p part.
   /// Returns the user data pointer given when added.
   ///
   /// @see edje_object_text_insert_filter_callback_add
   /// @see edje_object_text_insert_filter_callback_del
   ///
   /// @return The same data pointer if successful, or NULL otherwise
   ///
   /// @param part The part name
   /// @param func The function callback to remove
   /// @param data The data passed to the callback function
   ///
   void * text_insert_filter_callback_del_full(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_) const;

   /// @brief @brief Delete the top style form the user style stack.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void part_text_style_user_pop(::efl::eina::string_view part_) const;

   /// @brief Set the input panel-specific data to deliver to the input panel.
   ///
   /// This API is used by applications to deliver specific data to the input panel.
   /// The data format MUST be negotiated by both application and the input panel.
   /// The size and format of data are defined by the input panel.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param data The specific data to be set to the input panel.
   /// @param len the length of data, in bytes, to send to the input panel
   ///
   void part_text_input_panel_imdata_set(::efl::eina::string_view part_, const void * data_, int len_) const;

   /// @brief Get the specific data of the current active input panel.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param data The specific data to be got from the input panel
   /// @param len The length of data
   ///
   void part_text_input_panel_imdata_get(::efl::eina::string_view part_, void * data_, int * len_) const;

   /// @brief @brief Insert text for an object part.
   ///
   /// This function inserts the text for an object part just before the
   /// cursor position.
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   void part_text_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Removes an object from the box.
   ///
   /// @return Pointer to the object removed, or @c NULL.
   ///
   /// Removes from the box indicated by part, the object in the position
   /// pos.
   ///
   /// @see edje_object_part_box_remove()
   /// @see edje_object_part_box_remove_all()
   ///
   /// @param part The part name
   /// @param pos The position index of the object (starts counting from 0)
   ///
   ::evas::object part_box_remove_at(::efl::eina::string_view part_, unsigned int pos_) const;

   /// @brief @brief Copy the cursor to another cursor.
   ///
   /// @param part The part name
   /// @param src the cursor to copy from
   /// @param dst the cursor to copy to
   ///
   void part_text_cursor_copy(::efl::eina::string_view part_, Edje_Cursor src_, Edje_Cursor dst_) const;

   /// @brief Calculate the geometry of the region, relative to a given Edje
   /// object's area, <b>occupied by all parts in the object</b>
   ///
   /// This function gets the geometry of the rectangle equal to the area
   /// required to group all parts in @p obj's group/collection. The @p x
   /// and @p y coordinates are relative to the top left corner of the
   /// whole @p obj object's area. Parts placed out of the group's
   /// boundaries will also be taken in account, so that @p x and @p y
   /// <b>may be negative</b>.
   ///
   /// @note Use @c NULL pointers on the geometry components you're not
   /// interested in: they'll be ignored by the function.
   ///
   /// @note On failure, this function will make all non-@c NULL geometry
   /// pointers' pointed variables be set to zero.
   ///
   /// @param[out] x A pointer to a variable where to store the parts region's
   /// x coordinate
   /// @param[out] y A pointer to a variable where to store the parts region's
   /// y coordinate
   /// @param[out] w A pointer to a variable where to store the parts region's
   /// width
   /// @param[out] h A pointer to a variable where to store the parts region's
   /// height
   ///
   bool parts_extends_calc(Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const;

   /// @brief @brief Set the dragable object location.
   ///
   /// Places the dragable object at the given location.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1,
   /// representing the relative position to the dragable area on that axis.
   ///
   /// This value means, for the vertical axis, that 0.0 will be at the top if the
   /// first parameter of @c y in the dragable part theme is 1, and at bottom if it
   /// is -1.
   ///
   /// For the horizontal axis, 0.0 means left if the first parameter of @c x in the
   /// dragable part theme is 1, and right if it is -1.
   ///
   /// @see edje_object_part_drag_value_get()
   ///
   /// @param part The part name
   /// @param dx The x value
   /// @param dy The y value
   ///
   bool part_drag_value_set(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Get the dragable object location.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1,
   /// representing the relative position to the dragable area on that axis.
   ///
   /// @see edje_object_part_drag_value_set()
   ///
   /// Gets the drag location values.
   ///
   /// @param part The part name
   /// @param[out] dx The X value pointer
   /// @param[out] dy The Y value pointer
   ///
   bool part_drag_value_get(::efl::eina::string_view part_, double* dx_, double* dy_) const;

   /// @brief @brief Force a Size/Geometry calculation.
   ///
   /// Forces the object @p obj to recalculation layout regardless of
   /// freeze/thaw.
   ///
   void calc_force() const;

   /// @brief @brief Sets the cursor position to the given value
   ///
   /// @since 1.1.0
   ///
   /// @param part The part name
   /// @param cur The cursor to move
   /// @param pos the position of the cursor
   ///
   void part_text_cursor_pos_set(::efl::eina::string_view part_, Edje_Cursor cur_, int pos_) const;

   /// @brief @brief Retrieves the current position of the cursor
   ///
   /// @return The cursor position
   /// @since 1.1.0
   ///
   /// @param part The part name
   /// @param cur The cursor to get the position
   ///
   int part_text_cursor_pos_get(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Freezes the Edje object.
   ///
   /// @return The frozen state or 0 on Error
   ///
   /// This function puts all changes on hold. Successive freezes will
   /// nest, requiring an equal number of thaws.
   ///
   /// @see edje_object_thaw()
   ///
   int freeze() const;

   /// @brief @brief Returns the content (char) at the cursor position.
   /// @see evas_textblock_cursor_content_get
   ///
   /// You must free the return (if not NULL) after you are done with it.
   ///
   /// @return The character string pointed to (may be a multi-byte utf8 sequence) terminated by a nul byte.
   ///
   /// @param part The part name
   /// @param cur The cursor to use
   ///
   char * part_text_cursor_content_get(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Set the layout of the input panel.
   ///
   /// The layout of the input panel or virtual keyboard can make it easier or
   /// harder to enter content. This allows you to hint what kind of input you
   /// are expecting to enter and thus have the input panel automatically
   /// come up with the right mode.
   ///
   /// @since 1.1
   ///
   /// @param part The part name
   /// @param layout layout type
   ///
   void part_text_input_panel_layout_set(::efl::eina::string_view part_, Edje_Input_Panel_Layout layout_) const;

   /// @brief @brief Get the layout of the input panel.
   ///
   /// @return Layout type of the input panel
   ///
   /// @see edje_object_part_text_input_panel_layout_set
   /// @since 1.1
   ///
   /// @param part The part name
   ///
   Edje_Input_Panel_Layout part_text_input_panel_layout_get(::efl::eina::string_view part_) const;

   /// @brief @brief Packs an object into the table.
   ///
   /// @return @c EINA_TRUE object was added, @c EINA_FALSE on failure
   ///
   /// Packs an object into the table indicated by part.
   ///
   /// @param part The part name
   /// @param child_obj The object to pack in
   /// @param col The column to place it in
   /// @param row The row to place it in
   /// @param colspan Columns the child will take
   /// @param rowspan Rows the child will take
   ///
   bool part_table_pack(::efl::eina::string_view part_, ::evas::object child_obj_, unsigned short col_, unsigned short row_, unsigned short colspan_, unsigned short rowspan_) const;

   /// @brief Set the language mode of the input panel.
   ///
   /// This API can be used if you want to show the Alphabet keyboard.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param lang the language to be set to the input panel.
   ///
   void part_text_input_panel_language_set(::efl::eina::string_view part_, Edje_Input_Panel_Lang lang_) const;

   /// @brief Get the language mode of the input panel.
   ///
   /// See @ref edje_object_part_text_input_panel_language_set for more details.
   ///
   /// @return input panel language type
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   Edje_Input_Panel_Lang part_text_input_panel_language_get(::efl::eina::string_view part_) const;

   /// @brief @brief Gets the number of columns and rows the table has.
   ///
   /// @return @c EINA_TRUE get some data, @c EINA_FALSE on failure
   ///
   /// Retrieves the size of the table in number of columns and rows.
   ///
   /// @param part The part name
   /// @param[out] cols Pointer where to store number of columns (can be NULL)
   /// @param[out] rows Pointer where to store number of rows (can be NULL)
   ///
   bool part_table_col_row_size_get(::efl::eina::string_view part_, int* cols_, int* rows_) const;

   /// @brief @brief Get the object created by this external part.
   ///
   /// Parts of type external creates the part object using information
   /// provided by external plugins. It's somehow like "swallow"
   /// (edje_object_part_swallow()), but it's all set automatically.
   ///
   /// This function returns the part created by such external plugins and
   /// being currently managed by this Edje.
   ///
   /// @note Almost all swallow rules apply: you should not move, resize,
   /// hide, show, set the color or clipper of such part. It's a bit
   /// more restrictive as one must @b never delete this object!
   ///
   /// @return The externally created object, or NULL if there is none or
   /// part is not an external.
   ///
   /// @param part The part name
   ///
   ::evas::object part_external_object_get(::efl::eina::string_view part_) const;

   /// @brief @brief Get an object contained in an part of type EXTERNAL
   ///
   /// The @p content string must not be NULL. Its actual value depends on the
   /// code providing the EXTERNAL.
   ///
   /// @param part The name of the part holding the EXTERNAL
   /// @param[out] content A string identifying which content from the EXTERNAL to get
   ///
   ::evas::object part_external_content_get(::efl::eina::string_view part_, const char* content_) const;

   /// @brief @brief Preload the images on the Edje Object in the background.
   ///
   /// @return @c EINA_FASLE if obj was not a valid Edje object
   /// otherwise @c EINA_TRUE
   ///
   /// This function requests the preload of all data images (on the given
   /// object) in the background. The work is queued before being processed
   /// (because there might be other pending requests of this type).
   /// It emits a signal "preload,done" when finished.
   ///
   /// @note Use @c EINA_TRUE on scenarios where you don't need
   /// the image data preloaded anymore.
   ///
   /// @param cancel @c EINA_FALSE will add it the preloading work queue,
   /// @c EINA_TRUE will remove it (if it was issued before).
   ///
   bool preload(bool cancel_) const;

   /// @brief @brief Sets the attribute to show the input panel automatically.
   ///
   /// @since 1.1.0
   ///
   /// @param part The part name
   /// @param enabled If true, the input panel is appeared when entry is clicked or has a focus
   ///
   void part_text_input_panel_enabled_set(::efl::eina::string_view part_, bool enabled_) const;

   /// @brief @brief Retrieve the attribute to show the input panel automatically.
   /// @see edje_object_part_text_input_panel_enabled_set
   ///
   /// @return EINA_TRUE if it supports or EINA_FALSE otherwise
   /// @since 1.1.0
   ///
   /// @param part The part name
   ///
   bool part_text_input_panel_enabled_get(::efl::eina::string_view part_) const;

   /// @brief @brief Extends the current selection to the current cursor position
   ///
   /// @param part The part name
   ///
   void part_text_select_extend(::efl::eina::string_view part_) const;

   /// @brief @brief Inserts an object to the box.
   ///
   /// @return @c EINA_TRUE: Successfully added.\n
   /// @c EINA_FALSE: An error occurred.
   ///
   /// Adds child to the box indicated by part, in the position given by
   /// pos.
   ///
   /// @see edje_object_part_box_append()
   /// @see edje_object_part_box_prepend()
   /// @see edje_object_part_box_insert_before()
   ///
   /// @param part The part name
   /// @param child The object to insert
   /// @param pos The position where to insert child
   ///
   bool part_box_insert_at(::efl::eina::string_view part_, ::evas::object child_, unsigned int pos_) const;

   /// @brief @brief Return a list of Evas_Textblock_Rectangle anchor rectangles.
   ///
   /// @return The list of anchor rects (const Evas_Textblock_Rectangle
   /// *), do not modify! Geometry is relative to entry part.
   ///
   /// This function return a list of Evas_Textblock_Rectangle anchor
   /// rectangles.
   ///
   /// @param part The part name
   /// @param anchor The anchor name
   ///
   ::efl::eina::crange_list< const Evas_Textblock_Rectangle * > part_text_anchor_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view anchor_) const;

   /// @brief @brief Moves the cursor to the char below the current cursor position.
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   bool part_text_cursor_down(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Sets the page step increments.
   ///
   /// Sets the x,y page step increment values.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1,
   /// representing the relative size of the dragable area on that axis by which the
   /// part will be moved.
   ///
   /// @see edje_object_part_drag_page_get()
   ///
   /// @param part The part name
   /// @param dx The x page step increment
   /// @param dy The y page step increment
   ///
   bool part_drag_page_set(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Gets the page step increments.
   ///
   /// Gets the x,y page step increments for the dragable object.
   ///
   /// @see edje_object_part_drag_page_set()
   ///
   /// @param part The part name
   /// @param[out] dx The dx page increment pointer
   /// @param[out] dy The dy page increment pointer
   ///
   bool part_drag_page_get(::efl::eina::string_view part_, double* dx_, double* dy_) const;

   /// @brief @brief Prepends an object to the box.
   ///
   /// @return @c EINA_TRUE: Successfully added.\n
   /// @c EINA_FALSE: An error occurred.
   ///
   /// Prepends child to the box indicated by part.
   ///
   /// @see edje_object_part_box_append()
   /// @see edje_object_part_box_insert_before()
   /// @see edje_object_part_box_insert_at()
   ///
   /// @param part The part name
   /// @param child The object to prepend
   ///
   bool part_box_prepend(::efl::eina::string_view part_, ::evas::object child_) const;

   /// @brief @brief Send/emit an Edje signal to a given Edje object
   ///
   /// This function sends a signal to the object @a obj. An Edje program,
   /// at @p obj's EDC specification level, can respond to a signal by
   /// having declared matching @c 'signal' and @c 'source' fields on its
   /// block (see @ref edcref "the syntax" for EDC files).
   ///
   /// As an example,
   /// @code
   /// edje_object_signal_emit(obj, "a_signal", "");
   /// @endcode
   /// would trigger a program which had an EDC declaration block like
   /// @code
   /// program {
   /// name: "a_program";
   /// signal: "a_signal";
   /// source: "";
   /// action: ...
   /// }
   /// @endcode
   ///
   /// @see edje_object_signal_callback_add() for more on Edje signals.
   ///
   /// @param emission The signal's "emission" string
   /// @param source The signal's "source" string
   ///
   void signal_emit(::efl::eina::string_view emission_, ::efl::eina::string_view source_) const;

   /// @brief @brief Set the layout variation of the input panel.
   ///
   /// The layout variation of the input panel or virtual keyboard can make it easier or
   /// harder to enter content. This allows you to hint what kind of input you
   /// are expecting to enter and thus have the input panel automatically
   /// come up with the right mode.
   ///
   /// @since 1.8
   ///
   /// @param part The part name
   /// @param variation layout variation type
   ///
   void part_text_input_panel_layout_variation_set(::efl::eina::string_view part_, int variation_) const;

   /// @brief @brief Get the layout variation of the input panel.
   ///
   /// @return Layout variation type of the input panel
   ///
   /// @see edje_object_part_text_input_panel_layout_variation_set
   /// @since 1.8
   ///
   /// @param part The part name
   ///
   int part_text_input_panel_layout_variation_get(::efl::eina::string_view part_) const;

   /// @brief @brief Send an (Edje) message to a given Edje object
   ///
   /// This function sends an Edje message to @p obj and to all of its
   /// child objects, if it has any (swallowed objects are one kind of
   /// child object). @p type and @p msg @b must be matched accordingly,
   /// as documented in #Edje_Message_Type.
   ///
   /// The @p id argument as a form of code and theme defining a common
   /// interface on message communication. One should define the same IDs
   /// on both code and EDC declaration (see @ref edcref "the syntax" for
   /// EDC files), to individualize messages (binding them to a given
   /// context).
   ///
   /// The function to handle messages arriving @b from @b obj is set with
   /// edje_object_message_handler_set().
   ///
   /// @param type The type of message to send to @p obj
   /// @param id A identification number for the message to be sent
   /// @param msg The message's body, a struct depending on @p type
   ///
   void message_send(Edje_Message_Type type_, int id_, void * msg_) const;

   /// @brief @brief Set the selection to be none.
   ///
   /// This function sets the selection text to be none.
   ///
   /// @param part The part name
   ///
   void part_text_select_none(::efl::eina::string_view part_) const;

   /// @brief @brief Get a handle to the Evas object implementing a given Edje
   /// part, in an Edje object.
   ///
   /// @return A pointer to the Evas object implementing the given part,
   /// or @c NULL on failure (e.g. the given part doesn't exist)
   ///
   /// This function gets a pointer of the Evas object corresponding to a
   /// given part in the @p obj object's group.
   ///
   /// You should @b never modify the state of the returned object (with
   /// @c evas_object_move() or @c evas_object_hide() for example),
   /// because it's meant to be managed by Edje, solely. You are safe to
   /// query information about its current state (with @c
   /// evas_object_visible_get() or @c evas_object_color_get() for
   /// example), though.
   ///
   /// @param part The Edje part's name
   ///
   const Evas_Object * part_object_get(::efl::eina::string_view part_) const;

   /// @brief @brief Set the dragable object size.
   ///
   /// Values for @p dw and @p dh are real numbers that range from 0 to 1,
   /// representing the relative size of the dragable area on that axis.
   ///
   /// Sets the size of the dragable object.
   ///
   /// @see edje_object_part_drag_size_get()
   ///
   /// @param part The part name
   /// @param dw The drag width
   /// @param dh The drag height
   ///
   bool part_drag_size_set(::efl::eina::string_view part_, double dw_, double dh_) const;

   /// @brief @brief Get the dragable object size.
   ///
   /// Gets the dragable object size.
   ///
   /// @see edje_object_part_drag_size_set()
   ///
   /// @param part The part name
   /// @param[out] dw The drag width pointer
   /// @param[out] dh The drag height pointer
   ///
   bool part_drag_size_get(::efl::eina::string_view part_, double* dw_, double* dh_) const;

   /// @brief Delete a function from the filter list.
   ///
   /// Delete the given @p func filter from the list in @p part. Returns
   /// the user data pointer given when added.
   ///
   /// @see edje_object_text_insert_filter_callback_add
   /// @see edje_object_text_insert_filter_callback_del_full
   ///
   /// @return The user data pointer if successful, or NULL otherwise
   ///
   /// @param part The part name
   /// @param func The function callback to remove
   ///
   void * text_insert_filter_callback_del(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_) const;

   /// @brief @brief Determine dragable directions.
   ///
   /// The dragable directions are defined in the EDC file, inside the @c dragable
   /// section, by the attributes @c x and @c y. See the @ref edcref for more
   /// information.
   ///
   /// @return #EDJE_DRAG_DIR_NONE: Not dragable\n
   /// #EDJE_DRAG_DIR_X: Dragable in X direction\n
   /// #EDJE_DRAG_DIR_Y: Dragable in Y direction\n
   /// #EDJE_DRAG_DIR_XY: Dragable in X & Y directions
   ///
   /// @param part The part name
   ///
   Edje_Drag_Dir part_drag_dir_get(::efl::eina::string_view part_) const;

   /// @brief @brief Sets the raw (non escaped) text for an object part.
   ///
   /// This funciton will not do escape for you if it is a TEXTBLOCK part, that is,
   /// if text contain tags, these tags will not be interpreted/parsed by TEXTBLOCK.
   ///
   /// @see edje_object_part_text_unescaped_get().
   ///
   /// @param part The part name
   /// @param text_to_escape The text string
   ///
   bool part_text_unescaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_to_escape_) const;

   /// @brief @brief Returns the text of the object part, without escaping.
   ///
   /// @return The @b allocated text string without escaping, or NULL on
   /// problems.
   ///
   /// This function is the counterpart of
   /// edje_object_part_text_unescaped_set(). Please notice that the
   /// result is newly allocated memory and should be released with free()
   /// when done.
   ///
   /// @see edje_object_part_text_unescaped_set().
   ///
   /// @param part The part name
   ///
   char * part_text_unescaped_get(::efl::eina::string_view part_) const;

   /// @brief @brief Add a callback for an arriving Edje signal, emitted by
   /// a given Edje object.
   ///
   /// Edje signals are one of the communication interfaces between
   /// @b code and a given Edje object's @b theme. With signals, one can
   /// communicate two string values at a time, which are:
   /// - "emission" value: the name of the signal, in general
   /// - "source" value: a name for the signal's context, in general
   ///
   /// Though there are those common uses for the two strings, one is free
   /// to use them however they like.
   ///
   /// This function adds a callback function to a signal emitted by @a obj, to
   /// be issued every time an EDC program like the following
   /// @code
   /// program {
   /// name: "emit_example";
   /// action: SIGNAL_EMIT "a_signal" "a_source";
   /// }
   /// @endcode
   /// is run, if @p emission and @p source are given those same values,
   /// here.
   ///
   /// Signal callback registration is powerful, in the way that @b blobs
   /// may be used to match <b>multiple signals at once</b>. All the @c
   /// "*?[\" set of @c fnmatch() operators can be used, both for @p
   /// emission and @p source.
   ///
   /// Edje has @b internal signals it will emit, automatically, on
   /// various actions taking place on group parts. For example, the mouse
   /// cursor being moved, pressed, released, etc., over a given part's
   /// area, all generate individual signals.
   ///
   /// By using something like
   /// @code
   /// edje_object_signal_callback_add(obj, "mouse,down,*", "button.*",
   /// signal_cb, NULL);
   /// @endcode
   /// being @c "button.*" the pattern for the names of parts implementing
   /// buttons on an interface, you'd be registering for notifications on
   /// events of mouse buttons being pressed down on either of those parts
   /// (those events all have the @c "mouse,down," common prefix on their
   /// names, with a suffix giving the button number). The actual emission
   /// and source strings of an event will be passed in as the @a emission
   /// and @a source parameters of the callback function (e.g. @c
   /// "mouse,down,2" and @c "button.close"), for each of those events.
   ///
   /// @note See @ref edcref "the syntax" for EDC files
   /// @see edje_object_signal_emit() on how to emits Edje signals from
   /// code to a an object
   /// @see edje_object_signal_callback_del_full()
   ///
   /// @param emission The signal's "emission" string
   /// @param source The signal's "source" string
   /// @param func The callback function to be executed when the signal is
   /// emitted.
   /// @param data A pointer to data to pass in to @p func.
   ///
   template <typename F_func_>
   void signal_callback_add(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_) const;

   /// @brief @brief Set the selection to be everything.
   ///
   /// This function selects all text of the object of the part.
   ///
   /// @param part The part name
   ///
   void part_text_select_all(::efl::eina::string_view part_) const;

   /// @brief Set the return key on the input panel to be disabled.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param disabled The state
   ///
   void part_text_input_panel_return_key_disabled_set(::efl::eina::string_view part_, bool disabled_) const;

   /// @brief Get whether the return key on the input panel should be disabled or not.
   ///
   /// @return EINA_TRUE if it should be disabled
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   bool part_text_input_panel_return_key_disabled_get(::efl::eina::string_view part_) const;

   /// @brief @brief Set the autocapitalization type on the immodule.
   ///
   /// @since 1.1.0
   ///
   /// @param part The part name
   /// @param autocapital_type The type of autocapitalization
   ///
   void part_text_autocapital_type_set(::efl::eina::string_view part_, Edje_Text_Autocapital_Type autocapital_type_) const;

   /// @brief @brief Retrieves the autocapitalization type
   ///
   /// @return The autocapitalization type
   /// @since 1.1.0
   ///
   /// @param part The part name
   ///
   Edje_Text_Autocapital_Type part_text_autocapital_type_get(::efl::eina::string_view part_) const;

   /// @brief @brief Unswallow an object.
   ///
   /// Causes the edje to regurgitate a previously swallowed object. :)
   ///
   /// @note @p obj_swallow will @b not be deleted or hidden.
   /// @note @p obj_swallow may appear shown on the evas depending on its state when
   /// it got unswallowed. Make sure you delete it or hide it if you do not want it to.
   ///
   /// @param obj_swallow The swallowed object
   ///
   void part_unswallow(::evas::object obj_swallow_) const;

   /// @brief @brief Set whether the prediction is allowed or not.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param prediction If true, the prediction feature is allowed.
   ///
   void part_text_prediction_allow_set(::efl::eina::string_view part_, bool prediction_) const;

   /// @brief @brief Get whether the prediction is allowed or not.
   ///
   /// @return EINA_TRUE if prediction feature is allowed.
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   bool part_text_prediction_allow_get(::efl::eina::string_view part_) const;

   /// @brief @brief Retrive an <b>EDC data field's value</b> from a given Edje
   /// object's group.
   ///
   /// @return The data's value string. Must not be freed.
   ///
   /// This function fetches an EDC data field's value, which is declared
   /// on the objects building EDC file, <b>under its group</b>. EDC data
   /// blocks are most commonly used to pass arbitrary parameters from an
   /// application's theme to its code.
   ///
   /// They look like the following:
   ///
   /// @code
   /// collections {
   /// group {
   /// name: "a_group";
   /// data {
   /// item: "key1" "value1";
   /// item: "key2" "value2";
   /// }
   /// }
   /// }
   /// @endcode
   ///
   /// EDC data fields always hold @b strings as values, hence the return
   /// type of this function. Check the complete @ref edcref "syntax reference"
   /// for EDC files.
   ///
   /// @warning Do not confuse this call with edje_file_data_get(), which
   /// queries for a @b global EDC data field on an EDC declaration file.
   ///
   /// @see edje_object_file_set()
   ///
   /// @param key The data field's key string
   ///
   ::efl::eina::string_view data_get(::efl::eina::string_view key_) const;

   /// @brief Add a markup filter function for newly inserted text.
   ///
   /// Whenever text is inserted (not the same as set) into the given @p part,
   /// the list of markup filter functions will be called to decide if and how
   /// the new text will be accepted.
   /// The text parameter in the @p func filter is always markup. It can be
   /// modified by the user and it's up to him to free the one passed if he's to
   /// change the pointer. If doing so, the newly set text should be malloc'ed,
   /// as once all the filters are called Edje will free it.
   /// If the text is to be rejected, freeing it and setting the pointer to NULL
   /// will make Edje break out of the filter cycle and reject the inserted
   /// text.
   /// This function is different from edje_object_text_insert_filter_callback_add()
   /// in that the text parameter in the @p fucn filter is always markup.
   ///
   /// @warning If you use this function with
   /// edje_object_text_insert_filter_callback_add() togehter, all
   /// Edje_Text_Filter_Cb functions and Edje_Markup_Filter_Cb functions
   /// will be executed, and then filtered text will be inserted.
   ///
   /// @see edje_object_text_markup_filter_callback_del
   /// @see edje_object_text_markup_filter_callback_del_full
   /// @see edje_object_text_insert_filter_callback_add
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param func The callback function that will act as markup filter
   /// @param data User provided data to pass to the filter function
   ///
   void text_markup_filter_callback_add(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_) const;

   /// @brief @brief Process an object's message queue.
   ///
   /// This function goes through the object message queue processing the
   /// pending messages for @b this specific Edje object. Normally they'd
   /// be processed only at idle time.
   ///
   void message_signal_process() const;

   /// @brief @brief Removes an object from the box.
   ///
   /// @return Pointer to the object removed, or @c NULL.
   ///
   /// Removes child from the box indicated by part.
   ///
   /// @see edje_object_part_box_remove_at()
   /// @see edje_object_part_box_remove_all()
   ///
   /// @param part The part name
   /// @param child The object to remove
   ///
   ::evas::object part_box_remove(::efl::eina::string_view part_, ::evas::object child_) const;

   /// @brief @brief Thaws the Edje object.
   ///
   /// @return The frozen state or 0 if the object is not frozen or on error.
   ///
   /// This function thaws the given Edje object.
   ///
   /// @note: If sucessives freezes were done, an equal number of
   /// thaws will be required.
   ///
   /// @see edje_object_freeze()
   ///
   int thaw() const;

   /// @brief @brief Get the object currently swallowed by a part.
   ///
   /// @return The swallowed object, or NULL if there is none.
   ///
   /// @param part The part name
   ///
   ::evas::object part_swallow_get(::efl::eina::string_view part_) const;

   /// @brief @brief Reset the input method context if needed.
   ///
   /// This can be necessary in the case where modifying the buffer would confuse on-going input method behavior
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void part_text_imf_context_reset(::efl::eina::string_view part_) const;

   /// @brief Set the "return" key type. This type is used to set string or icon on the "return" key of the input panel.
   ///
   /// An input panel displays the string or icon associated with this type
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param return_key_type The type of "return" key on the input panel
   ///
   void part_text_input_panel_return_key_type_set(::efl::eina::string_view part_, Edje_Input_Panel_Return_Key_Type return_key_type_) const;

   /// @brief Get the "return" key type.
   ///
   /// @see edje_object_part_text_input_panel_return_key_type_set() for more details
   ///
   /// @return The type of "return" key on the input panel
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   Edje_Input_Panel_Return_Key_Type part_text_input_panel_return_key_type_get(::efl::eina::string_view part_) const;

   /// @brief @brief Retrieve a child from a table
   ///
   /// @return The child Evas_Object
   ///
   /// @param part The part name
   /// @param col The column of the child to get
   /// @param row The row of the child to get
   ///
   ::evas::object part_table_child_get(::efl::eina::string_view part_, unsigned int col_, unsigned int row_) const;

   /// @brief @brief Adds an object to the box.
   ///
   /// @return @c EINA_TRUE: Successfully added.\n
   /// @c EINA_FALSE: An error occurred.
   ///
   /// Inserts child in the box given by part, in the position marked by
   /// reference.
   ///
   /// @see edje_object_part_box_append()
   /// @see edje_object_part_box_prepend()
   /// @see edje_object_part_box_insert_at()
   ///
   /// @param part The part name
   /// @param child The object to insert
   /// @param reference The object to be used as reference
   ///
   bool part_box_insert_before(::efl::eina::string_view part_, ::evas::object child_, const Evas_Object * reference_) const;

   /// @brief @brief Set the parameter for the external part.
   ///
   /// Parts of type external may carry extra properties that have
   /// meanings defined by the external plugin. For instance, it may be a
   /// string that defines a button label and setting this property will
   /// change that label on the fly.
   ///
   /// @note external parts have parameters set when they change
   /// states. Those parameters will never be changed by this
   /// function. The interpretation of how state_set parameters and
   /// param_set will interact is up to the external plugin.
   ///
   /// @note this function will not check if parameter value is valid
   /// using #Edje_External_Param_Info minimum, maximum, valid
   /// choices and others. However these should be checked by the
   /// underlying implementation provided by the external
   /// plugin. This is done for performance reasons.
   ///
   /// @return @c EINA_TRUE if everything went fine, @c EINA_FALSE on errors.
   ///
   /// @param part The part name
   /// @param param the parameter details, including its name, type and
   /// actual value. This pointer should be valid, and the
   /// parameter must exist in
   /// #Edje_External_Type.parameters_info, with the exact type,
   /// otherwise the operation will fail and @c EINA_FALSE will be
   /// returned.
   ///
   bool part_external_param_set(::efl::eina::string_view part_, const Edje_External_Param * param_) const;

   /// @brief @brief Get the parameter for the external part.
   ///
   /// Parts of type external may carry extra properties that have
   /// meanings defined by the external plugin. For instance, it may be a
   /// string that defines a button label. This property can be modified by
   /// state parameters, by explicit calls to
   /// edje_object_part_external_param_set() or getting the actual object
   /// with edje_object_part_external_object_get() and calling native
   /// functions.
   ///
   /// This function asks the external plugin what is the current value,
   /// independent on how it was set.
   ///
   /// @return @c EINA_TRUE if everything went fine and @p param members
   /// are filled with information, @c EINA_FALSE on errors and @p
   /// param member values are not set or valid.
   ///
   /// @param part The part name
   /// @param[out] param the parameter details. It is used as both input and
   /// output variable. This pointer should be valid, and the
   /// parameter must exist in
   /// #Edje_External_Type.parameters_info, with the exact type,
   /// otherwise the operation will fail and @c EINA_FALSE will be
   /// returned.
   ///
   bool part_external_param_get(::efl::eina::string_view part_, Edje_External_Param* param_) const;

   /// @brief @brief Calculate the minimum required size for a given Edje object.
   ///
   /// This call works exactly as edje_object_size_min_restricted_calc(),
   /// with the last two arguments set to 0. Please refer to its
   /// documentation, then.
   ///
   /// @param[out] minw Pointer to a variable where to store the minimum
   /// required width
   /// @param[out] minh Pointer to a variable where to store the minimum
   /// required height
   ///
   void size_min_calc(Evas_Coord* minw_, Evas_Coord* minh_) const;

   /// @brief @brief Appends an object to the box.
   ///
   /// @return @c EINA_TRUE: Successfully added.\n
   /// @c EINA_FALSE: An error occurred.
   ///
   /// Appends child to the box indicated by part.
   ///
   /// @see edje_object_part_box_prepend()
   /// @see edje_object_part_box_insert_before()
   /// @see edje_object_part_box_insert_at()
   ///
   /// @param part The part name
   /// @param child The object to append
   ///
   bool part_box_append(::efl::eina::string_view part_, ::evas::object child_) const;

   /// @brief @brief Calculate the minimum required size for a given Edje object.
   ///
   /// This call will trigger an internal recalculation of all parts of
   /// the @p obj object, in order to return its minimum required
   /// dimensions for width and height. The user might choose to @b impose
   /// those minimum sizes, making the resulting calculation to get to values
   /// equal or bigger than @p restrictedw and @p restrictedh, for width and
   /// height, respectively.
   ///
   /// @note At the end of this call, @p obj @b won't be automatically
   /// resized to new dimensions, but just return the calculated
   /// sizes. The caller is the one up to change its geometry or not.
   ///
   /// @warning Be advised that invisible parts in @p obj @b will be taken
   /// into account in this calculation.
   ///
   /// @param[out] minw Pointer to a variable where to store the minimum
   /// required width
   /// @param[out] minh Pointer to a variable where to store the minimum
   /// required height
   /// @param restrictedw Do not allow object's calculated (minimum) width
   /// to be less than this value
   /// @param restrictedh Do not allow object's calculated (minimum)
   /// height to be less than this value
   ///
   void size_min_restricted_calc(Evas_Coord* minw_, Evas_Coord* minh_, Evas_Coord restrictedw_, Evas_Coord restrictedh_) const;

   /// @brief @brief Removes all elements from the box.
   ///
   /// @return 1: Successfully cleared.\n
   /// 0: An error occurred.
   ///
   /// Removes all the external objects from the box indicated by part.
   /// Elements created from the theme will not be removed.
   ///
   /// @see edje_object_part_box_remove()
   /// @see edje_object_part_box_remove_at()
   ///
   /// @param part The part name
   /// @param clear Delete objects on removal
   ///
   bool part_box_remove_all(::efl::eina::string_view part_, bool clear_) const;

   /// @brief @brief Pages x,y steps.
   ///
   /// Pages x,y where the increment is defined by
   /// edje_object_part_drag_page_set.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1.
   ///
   /// @warning Paging is bugged!
   ///
   /// @see edje_object_part_drag_step()
   ///
   /// @param part The part name
   /// @param dx The x step
   /// @param dy The y step
   ///
   bool part_drag_page(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Sets the text for an object part
   ///
   /// @return @c EINA_TRUE on success, @c EINA_FALSE otherwise
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   bool part_text_set(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Return the text of the object part.
   ///
   /// @return The text string
   ///
   /// This function returns the text associated to the object part.
   ///
   /// @see edje_object_part_text_set().
   ///
   /// @param part The part name
   ///
   ::efl::eina::string_view part_text_get(::efl::eina::string_view part_) const;

   /// @brief Set the attribute to show the input panel in case of only an user's explicit Mouse Up event.
   /// It doesn't request to show the input panel even though it has focus.
   ///
   /// @since 1.9.0
   ///
   /// @param part The part name
   /// @param ondemand If true, the input panel will be shown in case of only Mouse up event. (Focus event will be ignored.)
   ///
   void part_text_input_panel_show_on_demand_set(::efl::eina::string_view part_, bool ondemand_) const;

   /// @brief Get the attribute to show the input panel in case of only an user's explicit Mouse Up event.
   ///
   /// @return @c EINA_TRUE if the input panel will be shown in case of only Mouse up event.
   /// @since 1.9.0
   ///
   /// @param part The part name
   ///
   bool part_text_input_panel_show_on_demand_get(::efl::eina::string_view part_) const;

   /// @brief Sets the input hint which allows input methods to fine-tune their behavior.
   ///
   /// @since 1.12.0
   ///
   /// @param part The part name
   /// @param input_hints input hints
   ///
   void part_text_input_hint_set(::efl::eina::string_view part_, Edje_Input_Hints input_hints_) const;

   /// @brief Gets the value of input hint
   ///
   /// @return The value of input hint
   /// @since 1.12.0
   ///
   /// @param part The part name
   ///
   Edje_Input_Hints part_text_input_hint_get(::efl::eina::string_view part_) const;

   /// @brief @brief Return the selection text of the object part.
   ///
   /// @return The text string
   ///
   /// This function returns selection text of the object part.
   ///
   /// @see edje_object_part_text_select_all()
   /// @see edje_object_part_text_select_none()
   ///
   /// @param part The part name
   ///
   ::efl::eina::string_view part_text_selection_get(::efl::eina::string_view part_) const;

   /// @brief @brief Returns whether the cursor points to a format.
   /// @see evas_textblock_cursor_is_format
   ///
   /// @return EINA_TRUE if it's true, EINA_FALSE otherwise.
   ///
   /// @param part The part name
   /// @param cur The cursor to adjust.
   ///
   bool part_text_cursor_is_format_get(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Gets font and font size from edje text class.
   ///
   /// @return @c EINA_TRUE, on success or @c EINA_FALSE, on error
   ///
   /// This function gets the font and the font size from the object
   /// text class. The font string will only be valid until the text
   /// class is changed or the edje object is deleted.
   ///
   /// @param text_class The text class name
   /// @param[out] font Font name
   /// @param[out] size Font Size
   ///
   bool text_class_get(::efl::eina::string_view text_class_, const char ** font_, Evas_Font_Size* size_) const;

   /// @brief @brief Sets the object color class.
   ///
   /// This function sets the color values for an object level color
   /// class. This will cause all edje parts in the specified object that
   /// have the specified color class to have their colors multiplied by
   /// these values.
   ///
   /// The first color is the object, the second is the text outline, and
   /// the third is the text shadow. (Note that the second two only apply
   /// to text parts).
   ///
   /// Setting color emits a signal "color_class,set" with source being
   /// the given color.
   ///
   /// @note unlike Evas, Edje colors are @b not pre-multiplied. That is,
   /// half-transparent white is 255 255 255 128.
   ///
   /// @param color_class 
   /// @param r Object Red value
   /// @param g Object Green value
   /// @param b Object Blue value
   /// @param a Object Alpha value
   /// @param r2 Outline Red value
   /// @param g2 Outline Green value
   /// @param b2 Outline Blue value
   /// @param a2 Outline Alpha value
   /// @param r3 Shadow Red value
   /// @param g3 Shadow Green value
   /// @param b3 Shadow Blue value
   /// @param a3 Shadow Alpha value
   ///
   bool color_class_set(::efl::eina::string_view color_class_, int r_, int g_, int b_, int a_, int r2_, int g2_, int b2_, int a2_, int r3_, int g3_, int b3_, int a3_) const;

   /// @brief @brief Gets the object color class.
   ///
   /// @return EINA_TRUE if found or EINA_FALSE if not found and all
   /// values are zeroed.
   ///
   /// This function gets the color values for an object level color
   /// class. If no explicit object color is set, then global values will
   /// be used.
   ///
   /// The first color is the object, the second is the text outline, and
   /// the third is the text shadow. (Note that the second two only apply
   /// to text parts).
   ///
   /// @note unlike Evas, Edje colors are @b not pre-multiplied. That is,
   /// half-transparent white is 255 255 255 128.
   ///
   /// @param color_class 
   /// @param[out] r Object Red value
   /// @param[out] g Object Green value
   /// @param[out] b Object Blue value
   /// @param[out] a Object Alpha value
   /// @param[out] r2 Outline Red value
   /// @param[out] g2 Outline Green value
   /// @param[out] b2 Outline Blue value
   /// @param[out] a2 Outline Alpha value
   /// @param[out] r3 Shadow Red value
   /// @param[out] g3 Shadow Green value
   /// @param[out] b3 Shadow Blue value
   /// @param[out] a3 Shadow Alpha value
   ///
   bool color_class_get(::efl::eina::string_view color_class_, int* r_, int* g_, int* b_, int* a_, int* r2_, int* g2_, int* b2_, int* a2_, int* r3_, int* g3_, int* b3_, int* a3_) const;

   /// @brief @brief Gets the description of an object color class.
   ///
   /// @return The description of the target color class or @c NULL if not found
   ///
   /// This function gets the description of a color class in use by an object.
   ///
   /// @param color_class 
   ///
   ::efl::eina::string_view color_class_description_get(::efl::eina::string_view color_class_) const;

   /// @brief @brief Steps the dragable x,y steps.
   ///
   /// Steps x,y where the step increment is the amount set by
   /// edje_object_part_drag_step_set.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1.
   ///
   /// @see edje_object_part_drag_page()
   ///
   /// @param part The part name
   /// @param dx The x step
   /// @param dy The y step
   ///
   bool part_drag_step(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Move the cursor to the char above the current cursor position.
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   bool part_text_cursor_up(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Returns the cursor geometry of the part relative to the edje
   /// object.
   ///
   /// @param part The part name
   /// @param[out] x Cursor X position
   /// @param[out] y Cursor Y position
   /// @param[out] w Cursor width
   /// @param[out] h Cursor height
   ///
   void part_text_cursor_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const;

   /// @brief @brief Return a list of char anchor names.
   ///
   /// @return The list of anchors (const char *), do not modify!
   ///
   /// This function returns a list of char anchor names.
   ///
   /// @param part The part name
   ///
   ::efl::eina::crange_list< ::efl::eina::string_view > part_text_anchor_list_get(::efl::eina::string_view part_) const;

   /// @brief Add a filter function for newly inserted text.
   ///
   /// Whenever text is inserted (not the same as set) into the given @p part,
   /// the list of filter functions will be called to decide if and how the new
   /// text will be accepted.
   /// There are three types of filters, EDJE_TEXT_FILTER_TEXT,
   /// EDJE_TEXT_FILTER_FORMAT and EDJE_TEXT_FILTER_MARKUP.
   /// The text parameter in the @p func filter can be modified by the user and
   /// it's up to him to free the one passed if he's to change the pointer. If
   /// doing so, the newly set text should be malloc'ed, as once all the filters
   /// are called Edje will free it.
   /// If the text is to be rejected, freeing it and setting the pointer to NULL
   /// will make Edje break out of the filter cycle and reject the inserted
   /// text.
   ///
   /// @warning This function will be deprecated because of difficulty in use.
   /// The type(format, text, or markup) of text should be always
   /// checked in the filter function for correct filtering.
   /// Please use edje_object_text_markup_filter_callback_add() instead. There
   /// is no need to check the type of text in the filter function
   /// because the text is always markup.
   /// @warning If you use this function with
   /// edje_object_text_markup_filter_callback_add() together, all
   /// Edje_Text_Filter_Cb functions and Edje_Markup_Filter_Cb functions
   /// will be executed, and then filtered text will be inserted.
   ///
   /// @see edje_object_text_insert_filter_callback_del
   /// @see edje_object_text_insert_filter_callback_del_full
   /// @see edje_object_text_markup_filter_callback_add
   ///
   /// @param part The part name
   /// @param func The callback function that will act as filter
   /// @param data User provided data to pass to the filter function
   ///
   void text_insert_filter_callback_add(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_) const;

   /// @brief @brief Show the input panel (virtual keyboard) based on the input panel property such as layout, autocapital types, and so on.
   ///
   /// Note that input panel is shown or hidden automatically according to the focus state.
   /// This API can be used in the case of manually controlling by using edje_object_part_text_input_panel_enabled_set.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void part_text_input_panel_show(::efl::eina::string_view part_) const;

   /// @brief @brief Check if an Edje part exists in a given Edje object's group
   /// definition.
   ///
   /// @return @c EINA_TRUE, if the Edje part exists in @p obj's group or
   /// @c EINA_FALSE, otherwise (and on errors)
   ///
   /// This function returns if a given part exists in the Edje group
   /// bound to object @p obj (with edje_object_file_set()).
   ///
   /// This call is useful, for example, when one could expect or not a
   /// given GUI element, depending on the @b theme applied to @p obj.
   ///
   /// @param part The part's name to check for existence in @p obj's
   /// group
   ///
   bool part_exists(::efl::eina::string_view part_) const;

   /// @brief Delete a function from the markup filter list.
   ///
   /// Delete the given @p func filter from the list in @p part. Returns
   /// the user data pointer given when added.
   ///
   /// @see edje_object_text_markup_filter_callback_add
   /// @see edje_object_text_markup_filter_callback_del_full
   ///
   /// @return The user data pointer if successful, or NULL otherwise
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param func The function callback to remove
   ///
   void * text_markup_filter_callback_del(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_) const;

   /// @brief @brief Return true if the cursor points to a visible format
   /// For example \\t, \\n, item and etc.
   /// @see  evas_textblock_cursor_format_is_visible_get
   ///
   /// @param part The part name
   /// @param cur The cursor to adjust.
   ///
   bool part_text_cursor_is_visible_format_get(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief This function inserts text as if the user has inserted it.
   ///
   /// This means it actually registers as a change and emits signals, triggers
   /// callbacks as appropriate.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   void part_text_user_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Moves the cursor to the previous char
   /// @see evas_textblock_cursor_char_prev
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   bool part_text_cursor_prev(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Return a list of char item names.
   ///
   /// @return The list of items (const char *), do not modify!
   ///
   /// This function returns a list of char item names.
   ///
   /// @param part The part name
   ///
   ::efl::eina::crange_list< ::efl::eina::string_view > part_text_item_list_get(::efl::eina::string_view part_) const;

   /// @brief @brief "Swallows" an object into one of the Edje object @c SWALLOW
   /// parts.
   ///
   /// Swallowing an object into an Edje object is, for a given part of
   /// type @c SWALLOW in the EDC group which gave life to @a obj, to set
   /// an external object to be controlled by @a obj, being displayed
   /// exactly over that part's region inside the whole Edje object's
   /// viewport.
   ///
   /// From this point on, @a obj will have total control over @a
   /// obj_swallow's geometry and visibility. For instance, if @a obj is
   /// visible, as in @c evas_object_show(), the swallowed object will be
   /// visible too -- if the given @c SWALLOW part it's in is also
   /// visible. Other actions on @a obj will also reflect on the swallowed
   /// object as well (e.g. resizing, moving, raising/lowering, etc.).
   ///
   /// Finally, all internal changes to @a part, specifically, will
   /// reflect on the displaying of @a obj_swallow, for example state
   /// changes leading to different visibility states, geometries,
   /// positions, etc.
   ///
   /// If an object has already been swallowed into this part, then it
   /// will first be unswallowed (as in edje_object_part_unswallow())
   /// before the new object is swallowed.
   ///
   /// @note @a obj @b won't delete the swallowed object once it is
   /// deleted -- @a obj_swallow will get to an unparented state again.
   ///
   /// For more details on EDC @c SWALLOW parts, see @ref edcref "syntax
   /// reference".
   ///
   /// @param part The swallow part's name
   /// @param obj_swallow The object to occupy that part
   ///
   bool part_swallow(::efl::eina::string_view part_, ::evas::object obj_swallow_) const;

   /// @brief @brief Whether or not Edje will update size hints on itself.
   ///
   /// @return @c true if does, @c false if it doesn't.
   ///
   /// @param update Whether or not update the size hints.
   ///
   bool update_hints_get() const;

   /// @brief @brief Edje will automatically update the size hints on itself.
   ///
   /// By default edje doesn't set size hints on itself. With this function
   /// call, it will do so if update is true. Be carefully, it cost a lot to
   /// trigger this feature as it will recalc the object every time it make
   /// sense to be sure that's its minimal size hint is always accurate.
   ///
   /// @param update Whether or not update the size hints.
   ///
   void update_hints_set(bool update_) const;

   /// @brief @brief Get the RTL orientation for this object.
   ///
   /// You can RTL orientation explicitly with edje_object_mirrored_set.
   ///
   /// @return @c EINA_TRUE if the flag is set or @c EINA_FALSE if not.
   /// @since 1.1.0
   ///
   /// @param rtl new value of flag EINA_TRUE/EINA_FALSE
   ///
   bool mirrored_get() const;

   /// @brief @brief Set the RTL orientation for this object.
   ///
   /// @since 1.1.0
   ///
   /// @param rtl new value of flag EINA_TRUE/EINA_FALSE
   ///
   void mirrored_set(bool rtl_) const;

   /// @brief @brief Get the Edje object's animation state.
   ///
   /// @return @c EINA_FALSE on error or if object is not animated;
   /// @c EINA_TRUE if animated.
   ///
   /// This function returns if the animation is stopped or not. The
   /// animation state is set by edje_object_animation_set().
   ///
   /// @see edje_object_animation_set().
   ///
   /// @param on The animation state. @c EINA_TRUE to starts or
   /// @c EINA_FALSE to stops.
   ///
   bool animation_get() const;

   /// @brief @brief Set the object's animation state.
   ///
   /// This function starts or stops an Edje object's animation. The
   /// information if it's stopped can be retrieved by
   /// edje_object_animation_get().
   ///
   /// @see edje_object_animation_get()
   ///
   /// @param on The animation state. @c EINA_TRUE to starts or
   /// @c EINA_FALSE to stops.
   ///
   void animation_set(bool on_) const;

   /// @brief @brief Get the Edje object's state.
   ///
   /// @return @c EINA_FALSE if the object is not connected, its @c delete_me flag
   /// is set, or it is at paused state; @c EINA_TRUE if the object is at playing
   /// state.
   ///
   /// This function tells if an Edje object is playing or not. This state
   /// is set by edje_object_play_set().
   ///
   /// @see edje_object_play_set().
   ///
   /// @param play Object state (@c EINA_TRUE to playing,
   /// @c EINA_FALSE to paused).
   ///
   bool play_get() const;

   /// @brief @brief Set the Edje object to playing or paused states.
   ///
   /// This function sets the Edje object @a obj to playing or paused
   /// states, depending on the parameter @a play. This has no effect if
   /// the object was already at that state.
   ///
   /// @see edje_object_play_get().
   ///
   /// @param play Object state (@c EINA_TRUE to playing,
   /// @c EINA_FALSE to paused).
   ///
   void play_set(bool play_) const;

   /// @brief Get the current perspective used on this Edje object.
   ///
   /// @return The perspective object being used on this Edje object. Or @c NULL
   /// if there was none, and on errors.
   ///
   /// @see edje_object_perspective_set()
   ///
   /// @param ps The perspective object that will be used.
   ///
   const Edje_Perspective * perspective_get() const;

   /// @brief Set the given perspective object on this Edje object.
   ///
   /// Make the given perspective object be the default perspective for this Edje
   /// object.
   ///
   /// There can be only one perspective object per Edje object, and if a
   /// previous one was set, it will be removed and the new perspective object
   /// will be used.
   ///
   /// An Edje perspective will only affect a part if it doesn't point to another
   /// part to be used as perspective.
   ///
   /// @see edje_object_perspective_new()
   /// @see edje_object_perspective_get()
   /// @see edje_perspective_set()
   ///
   /// @param ps The perspective object that will be used.
   ///
   void perspective_set(Edje_Perspective * ps_) const;

   /// @brief @brief Get a given Edje object's scaling factor.
   ///
   /// This function returns the @c individual scaling factor set on the
   /// @a obj Edje object.
   ///
   /// @see edje_object_scale_set() for more details
   ///
   /// @param scale The scaling factor (the default value is @c 0.0,
   /// meaning individual scaling @b not set)
   ///
   double scale_get() const;

   /// @brief @brief Set the scaling factor for a given Edje object.
   ///
   /// This function sets an @b individual scaling factor on the @a obj
   /// Edje object. This property (or Edje's global scaling factor, when
   /// applicable), will affect this object's part sizes. If @p scale is
   /// not zero, than the individual scaling will @b override any global
   /// scaling set, for the object @p obj's parts. Put it back to zero to
   /// get the effects of the global scaling again.
   ///
   /// @warning Only parts which, at EDC level, had the @c "scale"
   /// property set to @c 1, will be affected by this function. Check the
   /// complete @ref edcref "syntax reference" for EDC files.
   ///
   /// @see edje_object_scale_get()
   /// @see edje_scale_get() for more details
   ///
   /// @param scale The scaling factor (the default value is @c 0.0,
   /// meaning individual scaling @b not set)
   ///
   bool scale_set(double scale_) const;

   /// @brief @brief Get a given Edje object's base_scale factor.
   ///
   /// This function returns the base_scale factor set on the
   /// @a obj Edje object.
   /// The base_scale can be set in the collection of edc.
   /// If it isn't set, the default value is 1.0
   ///
   /// @param base_scale 
   ///
   double base_scale_get() const;

   /// @brief @brief Set the object text callback.
   ///
   /// This function sets the callback to be called when the text changes.
   ///
   /// @param func The callback function to handle the text change
   /// @param data The data associated to the callback function.
   ///
   void text_change_cb_set(Edje_Text_Change_Cb func_, void * data_) const;

   /// @brief @brief Moves the cursor to the beginning of the text part
   /// @see evas_textblock_cursor_paragraph_first
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   void part_text_cursor_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Move the cursor to the end of the line.
   /// @see evas_textblock_cursor_line_char_last
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   void part_text_cursor_line_end_set(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Sets Edje text class.
   ///
   /// @return @c EINA_TRUE, on success or @c EINA_FALSE, on error
   ///
   /// This function sets the text class for the Edje.
   ///
   /// @param text_class The text class name
   /// @param font Font name
   /// @param size Font Size
   ///
   bool text_class_set(::efl::eina::string_view text_class_, ::efl::eina::string_view font_, Evas_Font_Size size_) const;

   /// @brief Position the given cursor to a X,Y position.
   ///
   /// This is frequently used with the user cursor.
   ///
   /// @return True on success, false on error.
   ///
   /// @param part The part containing the object.
   /// @param cur The cursor to adjust.
   /// @param x X Coordinate.
   /// @param y Y Coordinate.
   ///
   bool part_text_cursor_coord_set(::efl::eina::string_view part_, Edje_Cursor cur_, Evas_Coord x_, Evas_Coord y_) const;

   /// @brief @brief Moves the cursor to the end of the text part.
   /// @see evas_textblock_cursor_paragraph_last
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   void part_text_cursor_end_set(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Sets the text for an object part, but converts HTML escapes to UTF8
   ///
   /// This converts the given string @p text to UTF8 assuming it contains HTML
   /// style escapes like "&amp;" and "&copy;" etc. IF the part is of type TEXT,
   /// as opposed to TEXTBLOCK.
   ///
   /// @return @c EINA_TRUE on success, @c EINA_FALSE otherwise
   ///
   /// @since 1.2
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   bool part_text_escaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Set the function that provides item objects for named items in an edje entry text
   ///
   /// Item objects may be deleted any time by Edje, and will be deleted when the
   /// Edje object is deleted (or file is set to a new file).
   ///
   /// @param func The function to call (or NULL to disable) to get item objects
   /// @param data The data pointer to pass to the @p func callback
   ///
   void item_provider_set(Edje_Item_Provider_Cb func_, void * data_) const;

   /// @brief @brief Move the cursor to the beginning of the line.
   /// @see evas_textblock_cursor_line_char_first
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   void part_text_cursor_line_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Set an Edje message handler function for a given Edje object.
   ///
   /// For scriptable programs on an Edje object's defining EDC file which
   /// send messages with the @c send_message() primitive, one can attach
   /// <b>handler functions</b>, to be called in the code which creates
   /// that object (see @ref edcref "the syntax" for EDC files).
   ///
   /// This function associates a message handler function and the
   /// attached data pointer to the object @p obj.
   ///
   /// @see edje_object_message_send()
   ///
   /// @param func The function to handle messages @b coming from @p obj
   /// @param data Auxiliary data to be passed to @p func
   ///
   void message_handler_set(Edje_Message_Handler_Cb func_, void * data_) const;

   /// @brief @brief Get the minimum size specified -- as an EDC property -- for a
   /// given Edje object
   ///
   /// This function retrieves the @p obj object's minimum size values,
   /// <b>as declared in its EDC group definition</b>. Minimum size of
   /// groups have the following syntax
   /// @code
   /// collections {
   /// group {
   /// name: "a_group";
   /// min: 100 100;
   /// }
   /// }
   /// @endcode
   ///
   /// where one declares a minimum size of 100 pixels both for width and
   /// height. Those are (hint) values which should be respected when the
   /// given object/group is to be controlled by a given container object
   /// (e.g. an Edje object being "swallowed" into a given @c SWALLOW
   /// typed part, as in edje_object_part_swallow()). Check the complete
   /// @ref edcref "syntax reference" for EDC files.
   ///
   /// @note If the @c min EDC property was not declared for @p obj, this
   /// call will return the value 0, for each axis.
   ///
   /// @note On failure, this function will make all non-@c NULL size
   /// pointers' pointed variables be set to zero.
   ///
   /// @see edje_object_size_max_get()
   ///
   /// @param minw Pointer to a variable where to store the minimum width
   /// @param minh Pointer to a variable where to store the minimum height
   ///
   void size_min_get(Evas_Coord* minw_, Evas_Coord* minh_) const;

   /// @brief @brief Retrieve a list all accessibility part names
   ///
   /// @return A list all accessibility part names on @p obj
   /// @since 1.7.0
   ///
   ::efl::eina::range_list< ::efl::eina::string_view > access_part_list_get() const;

   /// @brief @brief Gets the (last) file loading error for a given Edje object
   ///
   /// @return The Edje loading error, one of:
   /// - #EDJE_LOAD_ERROR_NONE
   /// - #EDJE_LOAD_ERROR_GENERIC
   /// - #EDJE_LOAD_ERROR_DOES_NOT_EXIST
   /// - #EDJE_LOAD_ERROR_PERMISSION_DENIED
   /// - #EDJE_LOAD_ERROR_RESOURCE_ALLOCATION_FAILED
   /// - #EDJE_LOAD_ERROR_CORRUPT_FILE
   /// - #EDJE_LOAD_ERROR_UNKNOWN_FORMAT
   /// - #EDJE_LOAD_ERROR_INCOMPATIBLE_FILE
   /// - #EDJE_LOAD_ERROR_UNKNOWN_COLLECTION
   /// - #EDJE_LOAD_ERROR_RECURSIVE_REFERENCE
   ///
   /// This function is meant to be used after an Edje EDJ <b>file
   /// loading</b>, what takes place with the edje_object_file_set()
   /// function. If that function does not return @c EINA_TRUE, one should
   /// check for the reason of failure with this one.
   ///
   /// @see edje_load_error_str()
   ///
   Edje_Load_Error load_error_get() const;

   /// @brief @brief Get the maximum size specified -- as an EDC property -- for a
   /// given Edje object
   ///
   /// This function retrieves the @p obj object's maximum size values,
   /// <b>as declared in its EDC group definition</b>. Maximum size of
   /// groups have the following syntax
   /// @code
   /// collections {
   /// group {
   /// name: "a_group";
   /// max: 100 100;
   /// }
   /// }
   /// @endcode
   ///
   /// where one declares a maximum size of 100 pixels both for width and
   /// height. Those are (hint) values which should be respected when the
   /// given object/group is to be controlled by a given container object
   /// (e.g. an Edje object being "swallowed" into a given @c SWALLOW
   /// typed part, as in edje_object_part_swallow()). Check the complete
   /// @ref edcref "syntax reference" for EDC files.
   ///
   /// @note If the @c max EDC property was not declared for @p obj, this
   /// call will return the maximum size a given Edje object may have, for
   /// each axis.
   ///
   /// @note On failure, this function will make all non-@c NULL size
   /// pointers' pointed variables be set to zero.
   ///
   /// @see edje_object_size_min_get()
   ///
   /// @param maxw Pointer to a variable where to store the maximum width
   /// @param maxh Pointer to a variable where to store the maximum height
   ///
   void size_max_get(Evas_Coord* maxw_, Evas_Coord* maxh_) const;



   static Eo_Class const* _eo_class()
   {
      return(EDJE_OBJECT_CLASS);
   }

   operator ::edje::object() const;
   operator ::edje::object&();
   operator ::edje::object const&() const;

   /// @cond LOCAL
   template <typename D>
   struct address_of
   {
      operator ::edje::object*() const { return static_cast<::edje::object*>(static_cast<D const*>(this)->p); }
      operator ::edje::object const*() const { return static_cast<::edje::object const*>(static_cast<D const*>(this)->p); }
   };

   template <typename D>
   struct address_const_of
   {
      operator ::edje::object const*() const { return static_cast<::edje::object const*>(static_cast<D const*>(this)->p); }
   };
   /// @endcond

private:

   /// @internal
   Eo* _concrete_eo_ptr() const
   {
      return static_cast<::efl::eo::concrete const*>(static_cast<void const*>(this))->_eo_ptr();
   }

};

}

}
/// @endcond

namespace edje {

/// @brief Class object
struct object
      : ::efl::eo::concrete
      , EO_CXX_INHERIT(efl::file)
      , EO_CXX_INHERIT(efl::gfx::base)
      , EO_CXX_INHERIT(efl::gfx::stack)
      , EO_CXX_INHERIT(eo::base)
      , EO_CXX_INHERIT(evas::common_interface)
      , EO_CXX_INHERIT(evas::object)
      , EO_CXX_INHERIT(evas::object_smart)
      , EO_CXX_INHERIT(evas::signal_interface)
      , EO_CXX_INHERIT(evas::smart_clipped)
{
   //@{
   /**
      @brief Constructs a new edje::object object.

      Constructs a new edje::object object. If you want this object to be a child
      of another Eo object, use an @ref efl::eo::parent expression, like the example.

      Example:
      @code
      edje::object my_object(efl::eo::parent = parent_object);
      @endcode

      @see object(Eo* eo)
   */
   explicit object(::efl::eo::parent_type _p)
      : object(_ctors_call(_p))
   {}

   explicit object()
      : object(_ctors_call(::efl::eo::parent = nullptr))
   {}
   //@}

   /// @brief Eo Constructor.
   ///
   /// Constructs the object from an Eo* pointer stealing its ownership.
   ///
   /// @param eo The Eo object pointer.
   ///
   explicit object(Eo* eo)
      : ::efl::eo::concrete(eo)
   {}

   /// @brief nullptr_t Constructor.
   ///
   /// Constructs an empty (null) object.
   ///
   explicit object(std::nullptr_t)
      : ::efl::eo::concrete(nullptr)
   {}

   /// @brief Copy Constructor.
   ///
   object(object const& other)
      : object(eo_ref(other._eo_ptr()))
   {}

   ~object() {}

   /// @brief @brief Removes all object from the table.
   ///
   /// @return @c EINA_TRUE clear the table, @c EINA_FALSE on failure
   ///
   /// Removes all object from the table indicated by part, except the
   /// internal ones set from the theme.
   ///
   /// @param part The part name
   /// @param clear If set, will delete subobjs on remove
   ///
   bool part_table_clear(::efl::eina::string_view part_, bool clear_) const;

   /// @brief Facility to query the type of the given parameter of the given part.
   ///
   /// @return @c EDJE_EXTERNAL_PARAM_TYPE_MAX on errors, or another value
   /// from #Edje_External_Param_Type on success.
   ///
   /// @param part The part name
   /// @param[out] param the parameter name to use.
   ///
   Edje_External_Param_Type part_external_param_type_get(::efl::eina::string_view part_, const char* param_) const;

   /// @brief @brief Enables selection if the entry is an EXPLICIT selection mode
   /// type.
   ///
   /// The default is to @b not allow selection. This function only affects user
   /// selection, functions such as edje_object_part_text_select_all() and
   /// edje_object_part_text_select_none() are not affected.
   ///
   /// @param part The part name
   /// @param allow EINA_TRUE to enable, EINA_FALSE otherwise
   ///
   void part_text_select_allow_set(::efl::eina::string_view part_, bool allow_) const;

   /// @brief @brief Returns the state of the Edje part.
   ///
   /// @return The part state:\n
   /// "default" for the default state\n
   /// "" for other states
   ///
   /// @param part The part name
   /// @param[out] val_ret 
   ///
   ::efl::eina::string_view part_state_get(::efl::eina::string_view part_, double* val_ret_) const;

   /// @brief Delete a function and matching user data from the markup filter list.
   ///
   /// Delete the given @p func filter and @p data user data from the list
   /// in @p part.
   /// Returns the user data pointer given when added.
   ///
   /// @see edje_object_text_markup_filter_callback_add
   /// @see edje_object_text_markup_filter_callback_del
   ///
   /// @return The same data pointer if successful, or NULL otherwise
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param func The function callback to remove
   /// @param data The data passed to the callback function
   ///
   void * text_markup_filter_callback_del_full(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_) const;

   /// @brief @brief Sets the drag step increment.
   ///
   /// Sets the x,y step increments for a dragable object.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1,
   /// representing the relative size of the dragable area on that axis by which the
   /// part will be moved.
   ///
   /// @see edje_object_part_drag_step_get()
   ///
   /// @param part The part name
   /// @param dx The x step amount
   /// @param dy The y step amount
   ///
   bool part_drag_step_set(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Gets the drag step increment values.
   ///
   /// Gets the x and y step increments for the dragable object.
   ///
   ///
   /// @see edje_object_part_drag_step_set()
   ///
   /// @param part The part
   /// @param[out] dx The x step increment pointer
   /// @param[out] dy The y step increment pointer
   ///
   bool part_drag_step_get(::efl::eina::string_view part_, double* dx_, double* dy_) const;

   /// @brief @brief Get the input method context in entry.
   ///
   /// If ecore_imf was not available when edje was compiled, this function returns NULL
   /// otherwise, the returned pointer is an Ecore_IMF
   ///
   /// @return The input method context (Ecore_IMF_Context *) in entry
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void * part_text_imf_context_get(::efl::eina::string_view part_) const;

   /// @brief @brief Starts selecting at current cursor position
   ///
   /// @param part The part name
   ///
   void part_text_select_begin(::efl::eina::string_view part_) const;

   /// @brief @brief Return the text of the object part.
   ///
   /// @return The text string
   ///
   /// This function returns the style associated with the textblock part.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   ::efl::eina::string_view part_text_style_user_peek(::efl::eina::string_view part_) const;

   /// @brief @brief Remove a signal-triggered callback from an object.
   ///
   /// @return The data pointer
   ///
   /// This function removes a callback, previously attached to the
   /// emittion of a signal, from the object @a obj. The parameters @a
   /// emission, @a source and @a func must match exactly those passed to
   /// a previous call to edje_object_signal_callback_add(). The data
   /// pointer that was passed to this call will be returned.
   ///
   /// @see edje_object_signal_callback_add().
   /// @see edje_object_signal_callback_del_full().
   ///
   /// @param emission The emission string.
   /// @param source The source string.
   /// @param func The callback function.
   /// @param data The callback function.
   ///
   template <typename F_func_>
   void * signal_callback_del(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_) const;

   /// @brief @brief Advances the cursor to the next cursor position.
   /// @see evas_textblock_cursor_char_next
   ///
   /// @param part The part name
   /// @param cur The edje cursor to advance
   ///
   bool part_text_cursor_next(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Set the style of the
   ///
   /// This function sets the style associated with the textblock part.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param style The style to set (textblock conventions).
   ///
   void part_text_style_user_push(::efl::eina::string_view part_, ::efl::eina::string_view style_) const;

   /// @brief @brief Insert text for an object part.
   ///
   /// This function inserts the text for an object part at the end; It does not
   /// move the cursor.
   ///
   /// @since 1.1
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   void part_text_append(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Retrieve the geometry of a given Edje part, in a given Edje
   /// object's group definition, <b>relative to the object's area</b>
   ///
   /// This function gets the geometry of an Edje part within its
   /// group. The @p x and @p y coordinates are relative to the top left
   /// corner of the whole @p obj object's area.
   ///
   /// @note Use @c NULL pointers on the geometry components you're not
   /// interested in: they'll be ignored by the function.
   ///
   /// @note On failure, this function will make all non-@c NULL geometry
   /// pointers' pointed variables be set to zero.
   ///
   /// @param part The Edje part's name
   /// @param[out] x A pointer to a variable where to store the part's x
   /// coordinate
   /// @param[out] y A pointer to a variable where to store the part's y
   /// coordinate
   /// @param[out] w A pointer to a variable where to store the part's width
   /// @param[out] h A pointer to a variable where to store the part's height
   ///
   bool part_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const;

   /// @brief @brief Hide the input panel (virtual keyboard).
   /// @see edje_object_part_text_input_panel_show
   ///
   /// Note that input panel is shown or hidden automatically according to the focus state.
   /// This API can be used in the case of manually controlling by using edje_object_part_text_input_panel_enabled_set.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void part_text_input_panel_hide(::efl::eina::string_view part_) const;

   /// @brief @brief Return item geometry.
   ///
   /// @return 1 if item exists, 0 if not
   ///
   /// This function return a list of Evas_Textblock_Rectangle item
   /// rectangles.
   ///
   /// @param part The part name
   /// @param item The item name
   /// @param[out] cx Item x return (relative to entry part)
   /// @param[out] cy Item y return (relative to entry part)
   /// @param[out] cw Item width return
   /// @param[out] ch Item height return
   ///
   bool part_text_item_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view item_, Evas_Coord* cx_, Evas_Coord* cy_, Evas_Coord* cw_, Evas_Coord* ch_) const;

   /// @brief @brief Removes an object from the table.
   ///
   /// @return @c EINA_TRUE object removed, @c EINA_FALSE on failure
   ///
   /// Removes an object from the table indicated by part.
   ///
   /// @param part The part name
   /// @param child_obj The object to pack in
   ///
   bool part_table_unpack(::efl::eina::string_view part_, ::evas::object child_obj_) const;

   /// @brief @brief Aborts any selection action on a part.
   ///
   /// @param part The part name
   ///
   void part_text_select_abort(::efl::eina::string_view part_) const;

   /// @brief Delete a function and matching user data from the filter list.
   ///
   /// Delete the given @p func filter and @p data user data from the list
   /// in @p part.
   /// Returns the user data pointer given when added.
   ///
   /// @see edje_object_text_insert_filter_callback_add
   /// @see edje_object_text_insert_filter_callback_del
   ///
   /// @return The same data pointer if successful, or NULL otherwise
   ///
   /// @param part The part name
   /// @param func The function callback to remove
   /// @param data The data passed to the callback function
   ///
   void * text_insert_filter_callback_del_full(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_) const;

   /// @brief @brief Delete the top style form the user style stack.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void part_text_style_user_pop(::efl::eina::string_view part_) const;

   /// @brief Set the input panel-specific data to deliver to the input panel.
   ///
   /// This API is used by applications to deliver specific data to the input panel.
   /// The data format MUST be negotiated by both application and the input panel.
   /// The size and format of data are defined by the input panel.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param data The specific data to be set to the input panel.
   /// @param len the length of data, in bytes, to send to the input panel
   ///
   void part_text_input_panel_imdata_set(::efl::eina::string_view part_, const void * data_, int len_) const;

   /// @brief Get the specific data of the current active input panel.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param data The specific data to be got from the input panel
   /// @param len The length of data
   ///
   void part_text_input_panel_imdata_get(::efl::eina::string_view part_, void * data_, int * len_) const;

   /// @brief @brief Insert text for an object part.
   ///
   /// This function inserts the text for an object part just before the
   /// cursor position.
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   void part_text_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Removes an object from the box.
   ///
   /// @return Pointer to the object removed, or @c NULL.
   ///
   /// Removes from the box indicated by part, the object in the position
   /// pos.
   ///
   /// @see edje_object_part_box_remove()
   /// @see edje_object_part_box_remove_all()
   ///
   /// @param part The part name
   /// @param pos The position index of the object (starts counting from 0)
   ///
   ::evas::object part_box_remove_at(::efl::eina::string_view part_, unsigned int pos_) const;

   /// @brief @brief Copy the cursor to another cursor.
   ///
   /// @param part The part name
   /// @param src the cursor to copy from
   /// @param dst the cursor to copy to
   ///
   void part_text_cursor_copy(::efl::eina::string_view part_, Edje_Cursor src_, Edje_Cursor dst_) const;

   /// @brief Calculate the geometry of the region, relative to a given Edje
   /// object's area, <b>occupied by all parts in the object</b>
   ///
   /// This function gets the geometry of the rectangle equal to the area
   /// required to group all parts in @p obj's group/collection. The @p x
   /// and @p y coordinates are relative to the top left corner of the
   /// whole @p obj object's area. Parts placed out of the group's
   /// boundaries will also be taken in account, so that @p x and @p y
   /// <b>may be negative</b>.
   ///
   /// @note Use @c NULL pointers on the geometry components you're not
   /// interested in: they'll be ignored by the function.
   ///
   /// @note On failure, this function will make all non-@c NULL geometry
   /// pointers' pointed variables be set to zero.
   ///
   /// @param[out] x A pointer to a variable where to store the parts region's
   /// x coordinate
   /// @param[out] y A pointer to a variable where to store the parts region's
   /// y coordinate
   /// @param[out] w A pointer to a variable where to store the parts region's
   /// width
   /// @param[out] h A pointer to a variable where to store the parts region's
   /// height
   ///
   bool parts_extends_calc(Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const;

   /// @brief @brief Set the dragable object location.
   ///
   /// Places the dragable object at the given location.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1,
   /// representing the relative position to the dragable area on that axis.
   ///
   /// This value means, for the vertical axis, that 0.0 will be at the top if the
   /// first parameter of @c y in the dragable part theme is 1, and at bottom if it
   /// is -1.
   ///
   /// For the horizontal axis, 0.0 means left if the first parameter of @c x in the
   /// dragable part theme is 1, and right if it is -1.
   ///
   /// @see edje_object_part_drag_value_get()
   ///
   /// @param part The part name
   /// @param dx The x value
   /// @param dy The y value
   ///
   bool part_drag_value_set(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Get the dragable object location.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1,
   /// representing the relative position to the dragable area on that axis.
   ///
   /// @see edje_object_part_drag_value_set()
   ///
   /// Gets the drag location values.
   ///
   /// @param part The part name
   /// @param[out] dx The X value pointer
   /// @param[out] dy The Y value pointer
   ///
   bool part_drag_value_get(::efl::eina::string_view part_, double* dx_, double* dy_) const;

   /// @brief @brief Force a Size/Geometry calculation.
   ///
   /// Forces the object @p obj to recalculation layout regardless of
   /// freeze/thaw.
   ///
   void calc_force() const;

   /// @brief @brief Sets the cursor position to the given value
   ///
   /// @since 1.1.0
   ///
   /// @param part The part name
   /// @param cur The cursor to move
   /// @param pos the position of the cursor
   ///
   void part_text_cursor_pos_set(::efl::eina::string_view part_, Edje_Cursor cur_, int pos_) const;

   /// @brief @brief Retrieves the current position of the cursor
   ///
   /// @return The cursor position
   /// @since 1.1.0
   ///
   /// @param part The part name
   /// @param cur The cursor to get the position
   ///
   int part_text_cursor_pos_get(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Freezes the Edje object.
   ///
   /// @return The frozen state or 0 on Error
   ///
   /// This function puts all changes on hold. Successive freezes will
   /// nest, requiring an equal number of thaws.
   ///
   /// @see edje_object_thaw()
   ///
   int freeze() const;

   /// @brief @brief Returns the content (char) at the cursor position.
   /// @see evas_textblock_cursor_content_get
   ///
   /// You must free the return (if not NULL) after you are done with it.
   ///
   /// @return The character string pointed to (may be a multi-byte utf8 sequence) terminated by a nul byte.
   ///
   /// @param part The part name
   /// @param cur The cursor to use
   ///
   char * part_text_cursor_content_get(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Set the layout of the input panel.
   ///
   /// The layout of the input panel or virtual keyboard can make it easier or
   /// harder to enter content. This allows you to hint what kind of input you
   /// are expecting to enter and thus have the input panel automatically
   /// come up with the right mode.
   ///
   /// @since 1.1
   ///
   /// @param part The part name
   /// @param layout layout type
   ///
   void part_text_input_panel_layout_set(::efl::eina::string_view part_, Edje_Input_Panel_Layout layout_) const;

   /// @brief @brief Get the layout of the input panel.
   ///
   /// @return Layout type of the input panel
   ///
   /// @see edje_object_part_text_input_panel_layout_set
   /// @since 1.1
   ///
   /// @param part The part name
   ///
   Edje_Input_Panel_Layout part_text_input_panel_layout_get(::efl::eina::string_view part_) const;

   /// @brief @brief Packs an object into the table.
   ///
   /// @return @c EINA_TRUE object was added, @c EINA_FALSE on failure
   ///
   /// Packs an object into the table indicated by part.
   ///
   /// @param part The part name
   /// @param child_obj The object to pack in
   /// @param col The column to place it in
   /// @param row The row to place it in
   /// @param colspan Columns the child will take
   /// @param rowspan Rows the child will take
   ///
   bool part_table_pack(::efl::eina::string_view part_, ::evas::object child_obj_, unsigned short col_, unsigned short row_, unsigned short colspan_, unsigned short rowspan_) const;

   /// @brief Set the language mode of the input panel.
   ///
   /// This API can be used if you want to show the Alphabet keyboard.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param lang the language to be set to the input panel.
   ///
   void part_text_input_panel_language_set(::efl::eina::string_view part_, Edje_Input_Panel_Lang lang_) const;

   /// @brief Get the language mode of the input panel.
   ///
   /// See @ref edje_object_part_text_input_panel_language_set for more details.
   ///
   /// @return input panel language type
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   Edje_Input_Panel_Lang part_text_input_panel_language_get(::efl::eina::string_view part_) const;

   /// @brief @brief Gets the number of columns and rows the table has.
   ///
   /// @return @c EINA_TRUE get some data, @c EINA_FALSE on failure
   ///
   /// Retrieves the size of the table in number of columns and rows.
   ///
   /// @param part The part name
   /// @param[out] cols Pointer where to store number of columns (can be NULL)
   /// @param[out] rows Pointer where to store number of rows (can be NULL)
   ///
   bool part_table_col_row_size_get(::efl::eina::string_view part_, int* cols_, int* rows_) const;

   /// @brief @brief Get the object created by this external part.
   ///
   /// Parts of type external creates the part object using information
   /// provided by external plugins. It's somehow like "swallow"
   /// (edje_object_part_swallow()), but it's all set automatically.
   ///
   /// This function returns the part created by such external plugins and
   /// being currently managed by this Edje.
   ///
   /// @note Almost all swallow rules apply: you should not move, resize,
   /// hide, show, set the color or clipper of such part. It's a bit
   /// more restrictive as one must @b never delete this object!
   ///
   /// @return The externally created object, or NULL if there is none or
   /// part is not an external.
   ///
   /// @param part The part name
   ///
   ::evas::object part_external_object_get(::efl::eina::string_view part_) const;

   /// @brief @brief Get an object contained in an part of type EXTERNAL
   ///
   /// The @p content string must not be NULL. Its actual value depends on the
   /// code providing the EXTERNAL.
   ///
   /// @param part The name of the part holding the EXTERNAL
   /// @param[out] content A string identifying which content from the EXTERNAL to get
   ///
   ::evas::object part_external_content_get(::efl::eina::string_view part_, const char* content_) const;

   /// @brief @brief Preload the images on the Edje Object in the background.
   ///
   /// @return @c EINA_FASLE if obj was not a valid Edje object
   /// otherwise @c EINA_TRUE
   ///
   /// This function requests the preload of all data images (on the given
   /// object) in the background. The work is queued before being processed
   /// (because there might be other pending requests of this type).
   /// It emits a signal "preload,done" when finished.
   ///
   /// @note Use @c EINA_TRUE on scenarios where you don't need
   /// the image data preloaded anymore.
   ///
   /// @param cancel @c EINA_FALSE will add it the preloading work queue,
   /// @c EINA_TRUE will remove it (if it was issued before).
   ///
   bool preload(bool cancel_) const;

   /// @brief @brief Sets the attribute to show the input panel automatically.
   ///
   /// @since 1.1.0
   ///
   /// @param part The part name
   /// @param enabled If true, the input panel is appeared when entry is clicked or has a focus
   ///
   void part_text_input_panel_enabled_set(::efl::eina::string_view part_, bool enabled_) const;

   /// @brief @brief Retrieve the attribute to show the input panel automatically.
   /// @see edje_object_part_text_input_panel_enabled_set
   ///
   /// @return EINA_TRUE if it supports or EINA_FALSE otherwise
   /// @since 1.1.0
   ///
   /// @param part The part name
   ///
   bool part_text_input_panel_enabled_get(::efl::eina::string_view part_) const;

   /// @brief @brief Extends the current selection to the current cursor position
   ///
   /// @param part The part name
   ///
   void part_text_select_extend(::efl::eina::string_view part_) const;

   /// @brief @brief Inserts an object to the box.
   ///
   /// @return @c EINA_TRUE: Successfully added.\n
   /// @c EINA_FALSE: An error occurred.
   ///
   /// Adds child to the box indicated by part, in the position given by
   /// pos.
   ///
   /// @see edje_object_part_box_append()
   /// @see edje_object_part_box_prepend()
   /// @see edje_object_part_box_insert_before()
   ///
   /// @param part The part name
   /// @param child The object to insert
   /// @param pos The position where to insert child
   ///
   bool part_box_insert_at(::efl::eina::string_view part_, ::evas::object child_, unsigned int pos_) const;

   /// @brief @brief Return a list of Evas_Textblock_Rectangle anchor rectangles.
   ///
   /// @return The list of anchor rects (const Evas_Textblock_Rectangle
   /// *), do not modify! Geometry is relative to entry part.
   ///
   /// This function return a list of Evas_Textblock_Rectangle anchor
   /// rectangles.
   ///
   /// @param part The part name
   /// @param anchor The anchor name
   ///
   ::efl::eina::crange_list< const Evas_Textblock_Rectangle * > part_text_anchor_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view anchor_) const;

   /// @brief @brief Moves the cursor to the char below the current cursor position.
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   bool part_text_cursor_down(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Sets the page step increments.
   ///
   /// Sets the x,y page step increment values.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1,
   /// representing the relative size of the dragable area on that axis by which the
   /// part will be moved.
   ///
   /// @see edje_object_part_drag_page_get()
   ///
   /// @param part The part name
   /// @param dx The x page step increment
   /// @param dy The y page step increment
   ///
   bool part_drag_page_set(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Gets the page step increments.
   ///
   /// Gets the x,y page step increments for the dragable object.
   ///
   /// @see edje_object_part_drag_page_set()
   ///
   /// @param part The part name
   /// @param[out] dx The dx page increment pointer
   /// @param[out] dy The dy page increment pointer
   ///
   bool part_drag_page_get(::efl::eina::string_view part_, double* dx_, double* dy_) const;

   /// @brief @brief Prepends an object to the box.
   ///
   /// @return @c EINA_TRUE: Successfully added.\n
   /// @c EINA_FALSE: An error occurred.
   ///
   /// Prepends child to the box indicated by part.
   ///
   /// @see edje_object_part_box_append()
   /// @see edje_object_part_box_insert_before()
   /// @see edje_object_part_box_insert_at()
   ///
   /// @param part The part name
   /// @param child The object to prepend
   ///
   bool part_box_prepend(::efl::eina::string_view part_, ::evas::object child_) const;

   /// @brief @brief Send/emit an Edje signal to a given Edje object
   ///
   /// This function sends a signal to the object @a obj. An Edje program,
   /// at @p obj's EDC specification level, can respond to a signal by
   /// having declared matching @c 'signal' and @c 'source' fields on its
   /// block (see @ref edcref "the syntax" for EDC files).
   ///
   /// As an example,
   /// @code
   /// edje_object_signal_emit(obj, "a_signal", "");
   /// @endcode
   /// would trigger a program which had an EDC declaration block like
   /// @code
   /// program {
   /// name: "a_program";
   /// signal: "a_signal";
   /// source: "";
   /// action: ...
   /// }
   /// @endcode
   ///
   /// @see edje_object_signal_callback_add() for more on Edje signals.
   ///
   /// @param emission The signal's "emission" string
   /// @param source The signal's "source" string
   ///
   void signal_emit(::efl::eina::string_view emission_, ::efl::eina::string_view source_) const;

   /// @brief @brief Set the layout variation of the input panel.
   ///
   /// The layout variation of the input panel or virtual keyboard can make it easier or
   /// harder to enter content. This allows you to hint what kind of input you
   /// are expecting to enter and thus have the input panel automatically
   /// come up with the right mode.
   ///
   /// @since 1.8
   ///
   /// @param part The part name
   /// @param variation layout variation type
   ///
   void part_text_input_panel_layout_variation_set(::efl::eina::string_view part_, int variation_) const;

   /// @brief @brief Get the layout variation of the input panel.
   ///
   /// @return Layout variation type of the input panel
   ///
   /// @see edje_object_part_text_input_panel_layout_variation_set
   /// @since 1.8
   ///
   /// @param part The part name
   ///
   int part_text_input_panel_layout_variation_get(::efl::eina::string_view part_) const;

   /// @brief @brief Send an (Edje) message to a given Edje object
   ///
   /// This function sends an Edje message to @p obj and to all of its
   /// child objects, if it has any (swallowed objects are one kind of
   /// child object). @p type and @p msg @b must be matched accordingly,
   /// as documented in #Edje_Message_Type.
   ///
   /// The @p id argument as a form of code and theme defining a common
   /// interface on message communication. One should define the same IDs
   /// on both code and EDC declaration (see @ref edcref "the syntax" for
   /// EDC files), to individualize messages (binding them to a given
   /// context).
   ///
   /// The function to handle messages arriving @b from @b obj is set with
   /// edje_object_message_handler_set().
   ///
   /// @param type The type of message to send to @p obj
   /// @param id A identification number for the message to be sent
   /// @param msg The message's body, a struct depending on @p type
   ///
   void message_send(Edje_Message_Type type_, int id_, void * msg_) const;

   /// @brief @brief Set the selection to be none.
   ///
   /// This function sets the selection text to be none.
   ///
   /// @param part The part name
   ///
   void part_text_select_none(::efl::eina::string_view part_) const;

   /// @brief @brief Get a handle to the Evas object implementing a given Edje
   /// part, in an Edje object.
   ///
   /// @return A pointer to the Evas object implementing the given part,
   /// or @c NULL on failure (e.g. the given part doesn't exist)
   ///
   /// This function gets a pointer of the Evas object corresponding to a
   /// given part in the @p obj object's group.
   ///
   /// You should @b never modify the state of the returned object (with
   /// @c evas_object_move() or @c evas_object_hide() for example),
   /// because it's meant to be managed by Edje, solely. You are safe to
   /// query information about its current state (with @c
   /// evas_object_visible_get() or @c evas_object_color_get() for
   /// example), though.
   ///
   /// @param part The Edje part's name
   ///
   const Evas_Object * part_object_get(::efl::eina::string_view part_) const;

   /// @brief @brief Set the dragable object size.
   ///
   /// Values for @p dw and @p dh are real numbers that range from 0 to 1,
   /// representing the relative size of the dragable area on that axis.
   ///
   /// Sets the size of the dragable object.
   ///
   /// @see edje_object_part_drag_size_get()
   ///
   /// @param part The part name
   /// @param dw The drag width
   /// @param dh The drag height
   ///
   bool part_drag_size_set(::efl::eina::string_view part_, double dw_, double dh_) const;

   /// @brief @brief Get the dragable object size.
   ///
   /// Gets the dragable object size.
   ///
   /// @see edje_object_part_drag_size_set()
   ///
   /// @param part The part name
   /// @param[out] dw The drag width pointer
   /// @param[out] dh The drag height pointer
   ///
   bool part_drag_size_get(::efl::eina::string_view part_, double* dw_, double* dh_) const;

   /// @brief Delete a function from the filter list.
   ///
   /// Delete the given @p func filter from the list in @p part. Returns
   /// the user data pointer given when added.
   ///
   /// @see edje_object_text_insert_filter_callback_add
   /// @see edje_object_text_insert_filter_callback_del_full
   ///
   /// @return The user data pointer if successful, or NULL otherwise
   ///
   /// @param part The part name
   /// @param func The function callback to remove
   ///
   void * text_insert_filter_callback_del(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_) const;

   /// @brief @brief Determine dragable directions.
   ///
   /// The dragable directions are defined in the EDC file, inside the @c dragable
   /// section, by the attributes @c x and @c y. See the @ref edcref for more
   /// information.
   ///
   /// @return #EDJE_DRAG_DIR_NONE: Not dragable\n
   /// #EDJE_DRAG_DIR_X: Dragable in X direction\n
   /// #EDJE_DRAG_DIR_Y: Dragable in Y direction\n
   /// #EDJE_DRAG_DIR_XY: Dragable in X & Y directions
   ///
   /// @param part The part name
   ///
   Edje_Drag_Dir part_drag_dir_get(::efl::eina::string_view part_) const;

   /// @brief @brief Sets the raw (non escaped) text for an object part.
   ///
   /// This funciton will not do escape for you if it is a TEXTBLOCK part, that is,
   /// if text contain tags, these tags will not be interpreted/parsed by TEXTBLOCK.
   ///
   /// @see edje_object_part_text_unescaped_get().
   ///
   /// @param part The part name
   /// @param text_to_escape The text string
   ///
   bool part_text_unescaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_to_escape_) const;

   /// @brief @brief Returns the text of the object part, without escaping.
   ///
   /// @return The @b allocated text string without escaping, or NULL on
   /// problems.
   ///
   /// This function is the counterpart of
   /// edje_object_part_text_unescaped_set(). Please notice that the
   /// result is newly allocated memory and should be released with free()
   /// when done.
   ///
   /// @see edje_object_part_text_unescaped_set().
   ///
   /// @param part The part name
   ///
   char * part_text_unescaped_get(::efl::eina::string_view part_) const;

   /// @brief @brief Add a callback for an arriving Edje signal, emitted by
   /// a given Edje object.
   ///
   /// Edje signals are one of the communication interfaces between
   /// @b code and a given Edje object's @b theme. With signals, one can
   /// communicate two string values at a time, which are:
   /// - "emission" value: the name of the signal, in general
   /// - "source" value: a name for the signal's context, in general
   ///
   /// Though there are those common uses for the two strings, one is free
   /// to use them however they like.
   ///
   /// This function adds a callback function to a signal emitted by @a obj, to
   /// be issued every time an EDC program like the following
   /// @code
   /// program {
   /// name: "emit_example";
   /// action: SIGNAL_EMIT "a_signal" "a_source";
   /// }
   /// @endcode
   /// is run, if @p emission and @p source are given those same values,
   /// here.
   ///
   /// Signal callback registration is powerful, in the way that @b blobs
   /// may be used to match <b>multiple signals at once</b>. All the @c
   /// "*?[\" set of @c fnmatch() operators can be used, both for @p
   /// emission and @p source.
   ///
   /// Edje has @b internal signals it will emit, automatically, on
   /// various actions taking place on group parts. For example, the mouse
   /// cursor being moved, pressed, released, etc., over a given part's
   /// area, all generate individual signals.
   ///
   /// By using something like
   /// @code
   /// edje_object_signal_callback_add(obj, "mouse,down,*", "button.*",
   /// signal_cb, NULL);
   /// @endcode
   /// being @c "button.*" the pattern for the names of parts implementing
   /// buttons on an interface, you'd be registering for notifications on
   /// events of mouse buttons being pressed down on either of those parts
   /// (those events all have the @c "mouse,down," common prefix on their
   /// names, with a suffix giving the button number). The actual emission
   /// and source strings of an event will be passed in as the @a emission
   /// and @a source parameters of the callback function (e.g. @c
   /// "mouse,down,2" and @c "button.close"), for each of those events.
   ///
   /// @note See @ref edcref "the syntax" for EDC files
   /// @see edje_object_signal_emit() on how to emits Edje signals from
   /// code to a an object
   /// @see edje_object_signal_callback_del_full()
   ///
   /// @param emission The signal's "emission" string
   /// @param source The signal's "source" string
   /// @param func The callback function to be executed when the signal is
   /// emitted.
   /// @param data A pointer to data to pass in to @p func.
   ///
   template <typename F_func_>
   void signal_callback_add(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_) const;

   /// @brief @brief Set the selection to be everything.
   ///
   /// This function selects all text of the object of the part.
   ///
   /// @param part The part name
   ///
   void part_text_select_all(::efl::eina::string_view part_) const;

   /// @brief Set the return key on the input panel to be disabled.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param disabled The state
   ///
   void part_text_input_panel_return_key_disabled_set(::efl::eina::string_view part_, bool disabled_) const;

   /// @brief Get whether the return key on the input panel should be disabled or not.
   ///
   /// @return EINA_TRUE if it should be disabled
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   bool part_text_input_panel_return_key_disabled_get(::efl::eina::string_view part_) const;

   /// @brief @brief Set the autocapitalization type on the immodule.
   ///
   /// @since 1.1.0
   ///
   /// @param part The part name
   /// @param autocapital_type The type of autocapitalization
   ///
   void part_text_autocapital_type_set(::efl::eina::string_view part_, Edje_Text_Autocapital_Type autocapital_type_) const;

   /// @brief @brief Retrieves the autocapitalization type
   ///
   /// @return The autocapitalization type
   /// @since 1.1.0
   ///
   /// @param part The part name
   ///
   Edje_Text_Autocapital_Type part_text_autocapital_type_get(::efl::eina::string_view part_) const;

   /// @brief @brief Unswallow an object.
   ///
   /// Causes the edje to regurgitate a previously swallowed object. :)
   ///
   /// @note @p obj_swallow will @b not be deleted or hidden.
   /// @note @p obj_swallow may appear shown on the evas depending on its state when
   /// it got unswallowed. Make sure you delete it or hide it if you do not want it to.
   ///
   /// @param obj_swallow The swallowed object
   ///
   void part_unswallow(::evas::object obj_swallow_) const;

   /// @brief @brief Set whether the prediction is allowed or not.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param prediction If true, the prediction feature is allowed.
   ///
   void part_text_prediction_allow_set(::efl::eina::string_view part_, bool prediction_) const;

   /// @brief @brief Get whether the prediction is allowed or not.
   ///
   /// @return EINA_TRUE if prediction feature is allowed.
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   bool part_text_prediction_allow_get(::efl::eina::string_view part_) const;

   /// @brief @brief Retrive an <b>EDC data field's value</b> from a given Edje
   /// object's group.
   ///
   /// @return The data's value string. Must not be freed.
   ///
   /// This function fetches an EDC data field's value, which is declared
   /// on the objects building EDC file, <b>under its group</b>. EDC data
   /// blocks are most commonly used to pass arbitrary parameters from an
   /// application's theme to its code.
   ///
   /// They look like the following:
   ///
   /// @code
   /// collections {
   /// group {
   /// name: "a_group";
   /// data {
   /// item: "key1" "value1";
   /// item: "key2" "value2";
   /// }
   /// }
   /// }
   /// @endcode
   ///
   /// EDC data fields always hold @b strings as values, hence the return
   /// type of this function. Check the complete @ref edcref "syntax reference"
   /// for EDC files.
   ///
   /// @warning Do not confuse this call with edje_file_data_get(), which
   /// queries for a @b global EDC data field on an EDC declaration file.
   ///
   /// @see edje_object_file_set()
   ///
   /// @param key The data field's key string
   ///
   ::efl::eina::string_view data_get(::efl::eina::string_view key_) const;

   /// @brief Add a markup filter function for newly inserted text.
   ///
   /// Whenever text is inserted (not the same as set) into the given @p part,
   /// the list of markup filter functions will be called to decide if and how
   /// the new text will be accepted.
   /// The text parameter in the @p func filter is always markup. It can be
   /// modified by the user and it's up to him to free the one passed if he's to
   /// change the pointer. If doing so, the newly set text should be malloc'ed,
   /// as once all the filters are called Edje will free it.
   /// If the text is to be rejected, freeing it and setting the pointer to NULL
   /// will make Edje break out of the filter cycle and reject the inserted
   /// text.
   /// This function is different from edje_object_text_insert_filter_callback_add()
   /// in that the text parameter in the @p fucn filter is always markup.
   ///
   /// @warning If you use this function with
   /// edje_object_text_insert_filter_callback_add() togehter, all
   /// Edje_Text_Filter_Cb functions and Edje_Markup_Filter_Cb functions
   /// will be executed, and then filtered text will be inserted.
   ///
   /// @see edje_object_text_markup_filter_callback_del
   /// @see edje_object_text_markup_filter_callback_del_full
   /// @see edje_object_text_insert_filter_callback_add
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param func The callback function that will act as markup filter
   /// @param data User provided data to pass to the filter function
   ///
   void text_markup_filter_callback_add(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_) const;

   /// @brief @brief Process an object's message queue.
   ///
   /// This function goes through the object message queue processing the
   /// pending messages for @b this specific Edje object. Normally they'd
   /// be processed only at idle time.
   ///
   void message_signal_process() const;

   /// @brief @brief Removes an object from the box.
   ///
   /// @return Pointer to the object removed, or @c NULL.
   ///
   /// Removes child from the box indicated by part.
   ///
   /// @see edje_object_part_box_remove_at()
   /// @see edje_object_part_box_remove_all()
   ///
   /// @param part The part name
   /// @param child The object to remove
   ///
   ::evas::object part_box_remove(::efl::eina::string_view part_, ::evas::object child_) const;

   /// @brief @brief Thaws the Edje object.
   ///
   /// @return The frozen state or 0 if the object is not frozen or on error.
   ///
   /// This function thaws the given Edje object.
   ///
   /// @note: If sucessives freezes were done, an equal number of
   /// thaws will be required.
   ///
   /// @see edje_object_freeze()
   ///
   int thaw() const;

   /// @brief @brief Get the object currently swallowed by a part.
   ///
   /// @return The swallowed object, or NULL if there is none.
   ///
   /// @param part The part name
   ///
   ::evas::object part_swallow_get(::efl::eina::string_view part_) const;

   /// @brief @brief Reset the input method context if needed.
   ///
   /// This can be necessary in the case where modifying the buffer would confuse on-going input method behavior
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void part_text_imf_context_reset(::efl::eina::string_view part_) const;

   /// @brief Set the "return" key type. This type is used to set string or icon on the "return" key of the input panel.
   ///
   /// An input panel displays the string or icon associated with this type
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param return_key_type The type of "return" key on the input panel
   ///
   void part_text_input_panel_return_key_type_set(::efl::eina::string_view part_, Edje_Input_Panel_Return_Key_Type return_key_type_) const;

   /// @brief Get the "return" key type.
   ///
   /// @see edje_object_part_text_input_panel_return_key_type_set() for more details
   ///
   /// @return The type of "return" key on the input panel
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   Edje_Input_Panel_Return_Key_Type part_text_input_panel_return_key_type_get(::efl::eina::string_view part_) const;

   /// @brief @brief Retrieve a child from a table
   ///
   /// @return The child Evas_Object
   ///
   /// @param part The part name
   /// @param col The column of the child to get
   /// @param row The row of the child to get
   ///
   ::evas::object part_table_child_get(::efl::eina::string_view part_, unsigned int col_, unsigned int row_) const;

   /// @brief @brief Adds an object to the box.
   ///
   /// @return @c EINA_TRUE: Successfully added.\n
   /// @c EINA_FALSE: An error occurred.
   ///
   /// Inserts child in the box given by part, in the position marked by
   /// reference.
   ///
   /// @see edje_object_part_box_append()
   /// @see edje_object_part_box_prepend()
   /// @see edje_object_part_box_insert_at()
   ///
   /// @param part The part name
   /// @param child The object to insert
   /// @param reference The object to be used as reference
   ///
   bool part_box_insert_before(::efl::eina::string_view part_, ::evas::object child_, const Evas_Object * reference_) const;

   /// @brief @brief Set the parameter for the external part.
   ///
   /// Parts of type external may carry extra properties that have
   /// meanings defined by the external plugin. For instance, it may be a
   /// string that defines a button label and setting this property will
   /// change that label on the fly.
   ///
   /// @note external parts have parameters set when they change
   /// states. Those parameters will never be changed by this
   /// function. The interpretation of how state_set parameters and
   /// param_set will interact is up to the external plugin.
   ///
   /// @note this function will not check if parameter value is valid
   /// using #Edje_External_Param_Info minimum, maximum, valid
   /// choices and others. However these should be checked by the
   /// underlying implementation provided by the external
   /// plugin. This is done for performance reasons.
   ///
   /// @return @c EINA_TRUE if everything went fine, @c EINA_FALSE on errors.
   ///
   /// @param part The part name
   /// @param param the parameter details, including its name, type and
   /// actual value. This pointer should be valid, and the
   /// parameter must exist in
   /// #Edje_External_Type.parameters_info, with the exact type,
   /// otherwise the operation will fail and @c EINA_FALSE will be
   /// returned.
   ///
   bool part_external_param_set(::efl::eina::string_view part_, const Edje_External_Param * param_) const;

   /// @brief @brief Get the parameter for the external part.
   ///
   /// Parts of type external may carry extra properties that have
   /// meanings defined by the external plugin. For instance, it may be a
   /// string that defines a button label. This property can be modified by
   /// state parameters, by explicit calls to
   /// edje_object_part_external_param_set() or getting the actual object
   /// with edje_object_part_external_object_get() and calling native
   /// functions.
   ///
   /// This function asks the external plugin what is the current value,
   /// independent on how it was set.
   ///
   /// @return @c EINA_TRUE if everything went fine and @p param members
   /// are filled with information, @c EINA_FALSE on errors and @p
   /// param member values are not set or valid.
   ///
   /// @param part The part name
   /// @param[out] param the parameter details. It is used as both input and
   /// output variable. This pointer should be valid, and the
   /// parameter must exist in
   /// #Edje_External_Type.parameters_info, with the exact type,
   /// otherwise the operation will fail and @c EINA_FALSE will be
   /// returned.
   ///
   bool part_external_param_get(::efl::eina::string_view part_, Edje_External_Param* param_) const;

   /// @brief @brief Calculate the minimum required size for a given Edje object.
   ///
   /// This call works exactly as edje_object_size_min_restricted_calc(),
   /// with the last two arguments set to 0. Please refer to its
   /// documentation, then.
   ///
   /// @param[out] minw Pointer to a variable where to store the minimum
   /// required width
   /// @param[out] minh Pointer to a variable where to store the minimum
   /// required height
   ///
   void size_min_calc(Evas_Coord* minw_, Evas_Coord* minh_) const;

   /// @brief @brief Appends an object to the box.
   ///
   /// @return @c EINA_TRUE: Successfully added.\n
   /// @c EINA_FALSE: An error occurred.
   ///
   /// Appends child to the box indicated by part.
   ///
   /// @see edje_object_part_box_prepend()
   /// @see edje_object_part_box_insert_before()
   /// @see edje_object_part_box_insert_at()
   ///
   /// @param part The part name
   /// @param child The object to append
   ///
   bool part_box_append(::efl::eina::string_view part_, ::evas::object child_) const;

   /// @brief @brief Calculate the minimum required size for a given Edje object.
   ///
   /// This call will trigger an internal recalculation of all parts of
   /// the @p obj object, in order to return its minimum required
   /// dimensions for width and height. The user might choose to @b impose
   /// those minimum sizes, making the resulting calculation to get to values
   /// equal or bigger than @p restrictedw and @p restrictedh, for width and
   /// height, respectively.
   ///
   /// @note At the end of this call, @p obj @b won't be automatically
   /// resized to new dimensions, but just return the calculated
   /// sizes. The caller is the one up to change its geometry or not.
   ///
   /// @warning Be advised that invisible parts in @p obj @b will be taken
   /// into account in this calculation.
   ///
   /// @param[out] minw Pointer to a variable where to store the minimum
   /// required width
   /// @param[out] minh Pointer to a variable where to store the minimum
   /// required height
   /// @param restrictedw Do not allow object's calculated (minimum) width
   /// to be less than this value
   /// @param restrictedh Do not allow object's calculated (minimum)
   /// height to be less than this value
   ///
   void size_min_restricted_calc(Evas_Coord* minw_, Evas_Coord* minh_, Evas_Coord restrictedw_, Evas_Coord restrictedh_) const;

   /// @brief @brief Removes all elements from the box.
   ///
   /// @return 1: Successfully cleared.\n
   /// 0: An error occurred.
   ///
   /// Removes all the external objects from the box indicated by part.
   /// Elements created from the theme will not be removed.
   ///
   /// @see edje_object_part_box_remove()
   /// @see edje_object_part_box_remove_at()
   ///
   /// @param part The part name
   /// @param clear Delete objects on removal
   ///
   bool part_box_remove_all(::efl::eina::string_view part_, bool clear_) const;

   /// @brief @brief Pages x,y steps.
   ///
   /// Pages x,y where the increment is defined by
   /// edje_object_part_drag_page_set.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1.
   ///
   /// @warning Paging is bugged!
   ///
   /// @see edje_object_part_drag_step()
   ///
   /// @param part The part name
   /// @param dx The x step
   /// @param dy The y step
   ///
   bool part_drag_page(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Sets the text for an object part
   ///
   /// @return @c EINA_TRUE on success, @c EINA_FALSE otherwise
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   bool part_text_set(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Return the text of the object part.
   ///
   /// @return The text string
   ///
   /// This function returns the text associated to the object part.
   ///
   /// @see edje_object_part_text_set().
   ///
   /// @param part The part name
   ///
   ::efl::eina::string_view part_text_get(::efl::eina::string_view part_) const;

   /// @brief Set the attribute to show the input panel in case of only an user's explicit Mouse Up event.
   /// It doesn't request to show the input panel even though it has focus.
   ///
   /// @since 1.9.0
   ///
   /// @param part The part name
   /// @param ondemand If true, the input panel will be shown in case of only Mouse up event. (Focus event will be ignored.)
   ///
   void part_text_input_panel_show_on_demand_set(::efl::eina::string_view part_, bool ondemand_) const;

   /// @brief Get the attribute to show the input panel in case of only an user's explicit Mouse Up event.
   ///
   /// @return @c EINA_TRUE if the input panel will be shown in case of only Mouse up event.
   /// @since 1.9.0
   ///
   /// @param part The part name
   ///
   bool part_text_input_panel_show_on_demand_get(::efl::eina::string_view part_) const;

   /// @brief Sets the input hint which allows input methods to fine-tune their behavior.
   ///
   /// @since 1.12.0
   ///
   /// @param part The part name
   /// @param input_hints input hints
   ///
   void part_text_input_hint_set(::efl::eina::string_view part_, Edje_Input_Hints input_hints_) const;

   /// @brief Gets the value of input hint
   ///
   /// @return The value of input hint
   /// @since 1.12.0
   ///
   /// @param part The part name
   ///
   Edje_Input_Hints part_text_input_hint_get(::efl::eina::string_view part_) const;

   /// @brief @brief Return the selection text of the object part.
   ///
   /// @return The text string
   ///
   /// This function returns selection text of the object part.
   ///
   /// @see edje_object_part_text_select_all()
   /// @see edje_object_part_text_select_none()
   ///
   /// @param part The part name
   ///
   ::efl::eina::string_view part_text_selection_get(::efl::eina::string_view part_) const;

   /// @brief @brief Returns whether the cursor points to a format.
   /// @see evas_textblock_cursor_is_format
   ///
   /// @return EINA_TRUE if it's true, EINA_FALSE otherwise.
   ///
   /// @param part The part name
   /// @param cur The cursor to adjust.
   ///
   bool part_text_cursor_is_format_get(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Gets font and font size from edje text class.
   ///
   /// @return @c EINA_TRUE, on success or @c EINA_FALSE, on error
   ///
   /// This function gets the font and the font size from the object
   /// text class. The font string will only be valid until the text
   /// class is changed or the edje object is deleted.
   ///
   /// @param text_class The text class name
   /// @param[out] font Font name
   /// @param[out] size Font Size
   ///
   bool text_class_get(::efl::eina::string_view text_class_, const char ** font_, Evas_Font_Size* size_) const;

   /// @brief @brief Sets the object color class.
   ///
   /// This function sets the color values for an object level color
   /// class. This will cause all edje parts in the specified object that
   /// have the specified color class to have their colors multiplied by
   /// these values.
   ///
   /// The first color is the object, the second is the text outline, and
   /// the third is the text shadow. (Note that the second two only apply
   /// to text parts).
   ///
   /// Setting color emits a signal "color_class,set" with source being
   /// the given color.
   ///
   /// @note unlike Evas, Edje colors are @b not pre-multiplied. That is,
   /// half-transparent white is 255 255 255 128.
   ///
   /// @param color_class 
   /// @param r Object Red value
   /// @param g Object Green value
   /// @param b Object Blue value
   /// @param a Object Alpha value
   /// @param r2 Outline Red value
   /// @param g2 Outline Green value
   /// @param b2 Outline Blue value
   /// @param a2 Outline Alpha value
   /// @param r3 Shadow Red value
   /// @param g3 Shadow Green value
   /// @param b3 Shadow Blue value
   /// @param a3 Shadow Alpha value
   ///
   bool color_class_set(::efl::eina::string_view color_class_, int r_, int g_, int b_, int a_, int r2_, int g2_, int b2_, int a2_, int r3_, int g3_, int b3_, int a3_) const;

   /// @brief @brief Gets the object color class.
   ///
   /// @return EINA_TRUE if found or EINA_FALSE if not found and all
   /// values are zeroed.
   ///
   /// This function gets the color values for an object level color
   /// class. If no explicit object color is set, then global values will
   /// be used.
   ///
   /// The first color is the object, the second is the text outline, and
   /// the third is the text shadow. (Note that the second two only apply
   /// to text parts).
   ///
   /// @note unlike Evas, Edje colors are @b not pre-multiplied. That is,
   /// half-transparent white is 255 255 255 128.
   ///
   /// @param color_class 
   /// @param[out] r Object Red value
   /// @param[out] g Object Green value
   /// @param[out] b Object Blue value
   /// @param[out] a Object Alpha value
   /// @param[out] r2 Outline Red value
   /// @param[out] g2 Outline Green value
   /// @param[out] b2 Outline Blue value
   /// @param[out] a2 Outline Alpha value
   /// @param[out] r3 Shadow Red value
   /// @param[out] g3 Shadow Green value
   /// @param[out] b3 Shadow Blue value
   /// @param[out] a3 Shadow Alpha value
   ///
   bool color_class_get(::efl::eina::string_view color_class_, int* r_, int* g_, int* b_, int* a_, int* r2_, int* g2_, int* b2_, int* a2_, int* r3_, int* g3_, int* b3_, int* a3_) const;

   /// @brief @brief Gets the description of an object color class.
   ///
   /// @return The description of the target color class or @c NULL if not found
   ///
   /// This function gets the description of a color class in use by an object.
   ///
   /// @param color_class 
   ///
   ::efl::eina::string_view color_class_description_get(::efl::eina::string_view color_class_) const;

   /// @brief @brief Steps the dragable x,y steps.
   ///
   /// Steps x,y where the step increment is the amount set by
   /// edje_object_part_drag_step_set.
   ///
   /// Values for @p dx and @p dy are real numbers that range from 0 to 1.
   ///
   /// @see edje_object_part_drag_page()
   ///
   /// @param part The part name
   /// @param dx The x step
   /// @param dy The y step
   ///
   bool part_drag_step(::efl::eina::string_view part_, double dx_, double dy_) const;

   /// @brief @brief Move the cursor to the char above the current cursor position.
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   bool part_text_cursor_up(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Returns the cursor geometry of the part relative to the edje
   /// object.
   ///
   /// @param part The part name
   /// @param[out] x Cursor X position
   /// @param[out] y Cursor Y position
   /// @param[out] w Cursor width
   /// @param[out] h Cursor height
   ///
   void part_text_cursor_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const;

   /// @brief @brief Return a list of char anchor names.
   ///
   /// @return The list of anchors (const char *), do not modify!
   ///
   /// This function returns a list of char anchor names.
   ///
   /// @param part The part name
   ///
   ::efl::eina::crange_list< ::efl::eina::string_view > part_text_anchor_list_get(::efl::eina::string_view part_) const;

   /// @brief Add a filter function for newly inserted text.
   ///
   /// Whenever text is inserted (not the same as set) into the given @p part,
   /// the list of filter functions will be called to decide if and how the new
   /// text will be accepted.
   /// There are three types of filters, EDJE_TEXT_FILTER_TEXT,
   /// EDJE_TEXT_FILTER_FORMAT and EDJE_TEXT_FILTER_MARKUP.
   /// The text parameter in the @p func filter can be modified by the user and
   /// it's up to him to free the one passed if he's to change the pointer. If
   /// doing so, the newly set text should be malloc'ed, as once all the filters
   /// are called Edje will free it.
   /// If the text is to be rejected, freeing it and setting the pointer to NULL
   /// will make Edje break out of the filter cycle and reject the inserted
   /// text.
   ///
   /// @warning This function will be deprecated because of difficulty in use.
   /// The type(format, text, or markup) of text should be always
   /// checked in the filter function for correct filtering.
   /// Please use edje_object_text_markup_filter_callback_add() instead. There
   /// is no need to check the type of text in the filter function
   /// because the text is always markup.
   /// @warning If you use this function with
   /// edje_object_text_markup_filter_callback_add() together, all
   /// Edje_Text_Filter_Cb functions and Edje_Markup_Filter_Cb functions
   /// will be executed, and then filtered text will be inserted.
   ///
   /// @see edje_object_text_insert_filter_callback_del
   /// @see edje_object_text_insert_filter_callback_del_full
   /// @see edje_object_text_markup_filter_callback_add
   ///
   /// @param part The part name
   /// @param func The callback function that will act as filter
   /// @param data User provided data to pass to the filter function
   ///
   void text_insert_filter_callback_add(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_) const;

   /// @brief @brief Show the input panel (virtual keyboard) based on the input panel property such as layout, autocapital types, and so on.
   ///
   /// Note that input panel is shown or hidden automatically according to the focus state.
   /// This API can be used in the case of manually controlling by using edje_object_part_text_input_panel_enabled_set.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   ///
   void part_text_input_panel_show(::efl::eina::string_view part_) const;

   /// @brief @brief Check if an Edje part exists in a given Edje object's group
   /// definition.
   ///
   /// @return @c EINA_TRUE, if the Edje part exists in @p obj's group or
   /// @c EINA_FALSE, otherwise (and on errors)
   ///
   /// This function returns if a given part exists in the Edje group
   /// bound to object @p obj (with edje_object_file_set()).
   ///
   /// This call is useful, for example, when one could expect or not a
   /// given GUI element, depending on the @b theme applied to @p obj.
   ///
   /// @param part The part's name to check for existence in @p obj's
   /// group
   ///
   bool part_exists(::efl::eina::string_view part_) const;

   /// @brief Delete a function from the markup filter list.
   ///
   /// Delete the given @p func filter from the list in @p part. Returns
   /// the user data pointer given when added.
   ///
   /// @see edje_object_text_markup_filter_callback_add
   /// @see edje_object_text_markup_filter_callback_del_full
   ///
   /// @return The user data pointer if successful, or NULL otherwise
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param func The function callback to remove
   ///
   void * text_markup_filter_callback_del(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_) const;

   /// @brief @brief Return true if the cursor points to a visible format
   /// For example \\t, \\n, item and etc.
   /// @see  evas_textblock_cursor_format_is_visible_get
   ///
   /// @param part The part name
   /// @param cur The cursor to adjust.
   ///
   bool part_text_cursor_is_visible_format_get(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief This function inserts text as if the user has inserted it.
   ///
   /// This means it actually registers as a change and emits signals, triggers
   /// callbacks as appropriate.
   ///
   /// @since 1.2.0
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   void part_text_user_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Moves the cursor to the previous char
   /// @see evas_textblock_cursor_char_prev
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   bool part_text_cursor_prev(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Return a list of char item names.
   ///
   /// @return The list of items (const char *), do not modify!
   ///
   /// This function returns a list of char item names.
   ///
   /// @param part The part name
   ///
   ::efl::eina::crange_list< ::efl::eina::string_view > part_text_item_list_get(::efl::eina::string_view part_) const;

   /// @brief @brief "Swallows" an object into one of the Edje object @c SWALLOW
   /// parts.
   ///
   /// Swallowing an object into an Edje object is, for a given part of
   /// type @c SWALLOW in the EDC group which gave life to @a obj, to set
   /// an external object to be controlled by @a obj, being displayed
   /// exactly over that part's region inside the whole Edje object's
   /// viewport.
   ///
   /// From this point on, @a obj will have total control over @a
   /// obj_swallow's geometry and visibility. For instance, if @a obj is
   /// visible, as in @c evas_object_show(), the swallowed object will be
   /// visible too -- if the given @c SWALLOW part it's in is also
   /// visible. Other actions on @a obj will also reflect on the swallowed
   /// object as well (e.g. resizing, moving, raising/lowering, etc.).
   ///
   /// Finally, all internal changes to @a part, specifically, will
   /// reflect on the displaying of @a obj_swallow, for example state
   /// changes leading to different visibility states, geometries,
   /// positions, etc.
   ///
   /// If an object has already been swallowed into this part, then it
   /// will first be unswallowed (as in edje_object_part_unswallow())
   /// before the new object is swallowed.
   ///
   /// @note @a obj @b won't delete the swallowed object once it is
   /// deleted -- @a obj_swallow will get to an unparented state again.
   ///
   /// For more details on EDC @c SWALLOW parts, see @ref edcref "syntax
   /// reference".
   ///
   /// @param part The swallow part's name
   /// @param obj_swallow The object to occupy that part
   ///
   bool part_swallow(::efl::eina::string_view part_, ::evas::object obj_swallow_) const;

   /// @brief @brief Whether or not Edje will update size hints on itself.
   ///
   /// @return @c true if does, @c false if it doesn't.
   ///
   /// @param update Whether or not update the size hints.
   ///
   bool update_hints_get() const;

   /// @brief @brief Edje will automatically update the size hints on itself.
   ///
   /// By default edje doesn't set size hints on itself. With this function
   /// call, it will do so if update is true. Be carefully, it cost a lot to
   /// trigger this feature as it will recalc the object every time it make
   /// sense to be sure that's its minimal size hint is always accurate.
   ///
   /// @param update Whether or not update the size hints.
   ///
   void update_hints_set(bool update_) const;

   /// @brief @brief Get the RTL orientation for this object.
   ///
   /// You can RTL orientation explicitly with edje_object_mirrored_set.
   ///
   /// @return @c EINA_TRUE if the flag is set or @c EINA_FALSE if not.
   /// @since 1.1.0
   ///
   /// @param rtl new value of flag EINA_TRUE/EINA_FALSE
   ///
   bool mirrored_get() const;

   /// @brief @brief Set the RTL orientation for this object.
   ///
   /// @since 1.1.0
   ///
   /// @param rtl new value of flag EINA_TRUE/EINA_FALSE
   ///
   void mirrored_set(bool rtl_) const;

   /// @brief @brief Get the Edje object's animation state.
   ///
   /// @return @c EINA_FALSE on error or if object is not animated;
   /// @c EINA_TRUE if animated.
   ///
   /// This function returns if the animation is stopped or not. The
   /// animation state is set by edje_object_animation_set().
   ///
   /// @see edje_object_animation_set().
   ///
   /// @param on The animation state. @c EINA_TRUE to starts or
   /// @c EINA_FALSE to stops.
   ///
   bool animation_get() const;

   /// @brief @brief Set the object's animation state.
   ///
   /// This function starts or stops an Edje object's animation. The
   /// information if it's stopped can be retrieved by
   /// edje_object_animation_get().
   ///
   /// @see edje_object_animation_get()
   ///
   /// @param on The animation state. @c EINA_TRUE to starts or
   /// @c EINA_FALSE to stops.
   ///
   void animation_set(bool on_) const;

   /// @brief @brief Get the Edje object's state.
   ///
   /// @return @c EINA_FALSE if the object is not connected, its @c delete_me flag
   /// is set, or it is at paused state; @c EINA_TRUE if the object is at playing
   /// state.
   ///
   /// This function tells if an Edje object is playing or not. This state
   /// is set by edje_object_play_set().
   ///
   /// @see edje_object_play_set().
   ///
   /// @param play Object state (@c EINA_TRUE to playing,
   /// @c EINA_FALSE to paused).
   ///
   bool play_get() const;

   /// @brief @brief Set the Edje object to playing or paused states.
   ///
   /// This function sets the Edje object @a obj to playing or paused
   /// states, depending on the parameter @a play. This has no effect if
   /// the object was already at that state.
   ///
   /// @see edje_object_play_get().
   ///
   /// @param play Object state (@c EINA_TRUE to playing,
   /// @c EINA_FALSE to paused).
   ///
   void play_set(bool play_) const;

   /// @brief Get the current perspective used on this Edje object.
   ///
   /// @return The perspective object being used on this Edje object. Or @c NULL
   /// if there was none, and on errors.
   ///
   /// @see edje_object_perspective_set()
   ///
   /// @param ps The perspective object that will be used.
   ///
   const Edje_Perspective * perspective_get() const;

   /// @brief Set the given perspective object on this Edje object.
   ///
   /// Make the given perspective object be the default perspective for this Edje
   /// object.
   ///
   /// There can be only one perspective object per Edje object, and if a
   /// previous one was set, it will be removed and the new perspective object
   /// will be used.
   ///
   /// An Edje perspective will only affect a part if it doesn't point to another
   /// part to be used as perspective.
   ///
   /// @see edje_object_perspective_new()
   /// @see edje_object_perspective_get()
   /// @see edje_perspective_set()
   ///
   /// @param ps The perspective object that will be used.
   ///
   void perspective_set(Edje_Perspective * ps_) const;

   /// @brief @brief Get a given Edje object's scaling factor.
   ///
   /// This function returns the @c individual scaling factor set on the
   /// @a obj Edje object.
   ///
   /// @see edje_object_scale_set() for more details
   ///
   /// @param scale The scaling factor (the default value is @c 0.0,
   /// meaning individual scaling @b not set)
   ///
   double scale_get() const;

   /// @brief @brief Set the scaling factor for a given Edje object.
   ///
   /// This function sets an @b individual scaling factor on the @a obj
   /// Edje object. This property (or Edje's global scaling factor, when
   /// applicable), will affect this object's part sizes. If @p scale is
   /// not zero, than the individual scaling will @b override any global
   /// scaling set, for the object @p obj's parts. Put it back to zero to
   /// get the effects of the global scaling again.
   ///
   /// @warning Only parts which, at EDC level, had the @c "scale"
   /// property set to @c 1, will be affected by this function. Check the
   /// complete @ref edcref "syntax reference" for EDC files.
   ///
   /// @see edje_object_scale_get()
   /// @see edje_scale_get() for more details
   ///
   /// @param scale The scaling factor (the default value is @c 0.0,
   /// meaning individual scaling @b not set)
   ///
   bool scale_set(double scale_) const;

   /// @brief @brief Get a given Edje object's base_scale factor.
   ///
   /// This function returns the base_scale factor set on the
   /// @a obj Edje object.
   /// The base_scale can be set in the collection of edc.
   /// If it isn't set, the default value is 1.0
   ///
   /// @param base_scale 
   ///
   double base_scale_get() const;

   /// @brief @brief Set the object text callback.
   ///
   /// This function sets the callback to be called when the text changes.
   ///
   /// @param func The callback function to handle the text change
   /// @param data The data associated to the callback function.
   ///
   void text_change_cb_set(Edje_Text_Change_Cb func_, void * data_) const;

   /// @brief @brief Moves the cursor to the beginning of the text part
   /// @see evas_textblock_cursor_paragraph_first
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   void part_text_cursor_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Move the cursor to the end of the line.
   /// @see evas_textblock_cursor_line_char_last
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   void part_text_cursor_line_end_set(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Sets Edje text class.
   ///
   /// @return @c EINA_TRUE, on success or @c EINA_FALSE, on error
   ///
   /// This function sets the text class for the Edje.
   ///
   /// @param text_class The text class name
   /// @param font Font name
   /// @param size Font Size
   ///
   bool text_class_set(::efl::eina::string_view text_class_, ::efl::eina::string_view font_, Evas_Font_Size size_) const;

   /// @brief Position the given cursor to a X,Y position.
   ///
   /// This is frequently used with the user cursor.
   ///
   /// @return True on success, false on error.
   ///
   /// @param part The part containing the object.
   /// @param cur The cursor to adjust.
   /// @param x X Coordinate.
   /// @param y Y Coordinate.
   ///
   bool part_text_cursor_coord_set(::efl::eina::string_view part_, Edje_Cursor cur_, Evas_Coord x_, Evas_Coord y_) const;

   /// @brief @brief Moves the cursor to the end of the text part.
   /// @see evas_textblock_cursor_paragraph_last
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   void part_text_cursor_end_set(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Sets the text for an object part, but converts HTML escapes to UTF8
   ///
   /// This converts the given string @p text to UTF8 assuming it contains HTML
   /// style escapes like "&amp;" and "&copy;" etc. IF the part is of type TEXT,
   /// as opposed to TEXTBLOCK.
   ///
   /// @return @c EINA_TRUE on success, @c EINA_FALSE otherwise
   ///
   /// @since 1.2
   ///
   /// @param part The part name
   /// @param text The text string
   ///
   bool part_text_escaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_) const;

   /// @brief @brief Set the function that provides item objects for named items in an edje entry text
   ///
   /// Item objects may be deleted any time by Edje, and will be deleted when the
   /// Edje object is deleted (or file is set to a new file).
   ///
   /// @param func The function to call (or NULL to disable) to get item objects
   /// @param data The data pointer to pass to the @p func callback
   ///
   void item_provider_set(Edje_Item_Provider_Cb func_, void * data_) const;

   /// @brief @brief Move the cursor to the beginning of the line.
   /// @see evas_textblock_cursor_line_char_first
   ///
   /// @param part The part name
   /// @param cur the edje cursor to work on
   ///
   void part_text_cursor_line_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_) const;

   /// @brief @brief Set an Edje message handler function for a given Edje object.
   ///
   /// For scriptable programs on an Edje object's defining EDC file which
   /// send messages with the @c send_message() primitive, one can attach
   /// <b>handler functions</b>, to be called in the code which creates
   /// that object (see @ref edcref "the syntax" for EDC files).
   ///
   /// This function associates a message handler function and the
   /// attached data pointer to the object @p obj.
   ///
   /// @see edje_object_message_send()
   ///
   /// @param func The function to handle messages @b coming from @p obj
   /// @param data Auxiliary data to be passed to @p func
   ///
   void message_handler_set(Edje_Message_Handler_Cb func_, void * data_) const;

   /// @brief @brief Get the minimum size specified -- as an EDC property -- for a
   /// given Edje object
   ///
   /// This function retrieves the @p obj object's minimum size values,
   /// <b>as declared in its EDC group definition</b>. Minimum size of
   /// groups have the following syntax
   /// @code
   /// collections {
   /// group {
   /// name: "a_group";
   /// min: 100 100;
   /// }
   /// }
   /// @endcode
   ///
   /// where one declares a minimum size of 100 pixels both for width and
   /// height. Those are (hint) values which should be respected when the
   /// given object/group is to be controlled by a given container object
   /// (e.g. an Edje object being "swallowed" into a given @c SWALLOW
   /// typed part, as in edje_object_part_swallow()). Check the complete
   /// @ref edcref "syntax reference" for EDC files.
   ///
   /// @note If the @c min EDC property was not declared for @p obj, this
   /// call will return the value 0, for each axis.
   ///
   /// @note On failure, this function will make all non-@c NULL size
   /// pointers' pointed variables be set to zero.
   ///
   /// @see edje_object_size_max_get()
   ///
   /// @param minw Pointer to a variable where to store the minimum width
   /// @param minh Pointer to a variable where to store the minimum height
   ///
   void size_min_get(Evas_Coord* minw_, Evas_Coord* minh_) const;

   /// @brief @brief Retrieve a list all accessibility part names
   ///
   /// @return A list all accessibility part names on @p obj
   /// @since 1.7.0
   ///
   ::efl::eina::range_list< ::efl::eina::string_view > access_part_list_get() const;

   /// @brief @brief Gets the (last) file loading error for a given Edje object
   ///
   /// @return The Edje loading error, one of:
   /// - #EDJE_LOAD_ERROR_NONE
   /// - #EDJE_LOAD_ERROR_GENERIC
   /// - #EDJE_LOAD_ERROR_DOES_NOT_EXIST
   /// - #EDJE_LOAD_ERROR_PERMISSION_DENIED
   /// - #EDJE_LOAD_ERROR_RESOURCE_ALLOCATION_FAILED
   /// - #EDJE_LOAD_ERROR_CORRUPT_FILE
   /// - #EDJE_LOAD_ERROR_UNKNOWN_FORMAT
   /// - #EDJE_LOAD_ERROR_INCOMPATIBLE_FILE
   /// - #EDJE_LOAD_ERROR_UNKNOWN_COLLECTION
   /// - #EDJE_LOAD_ERROR_RECURSIVE_REFERENCE
   ///
   /// This function is meant to be used after an Edje EDJ <b>file
   /// loading</b>, what takes place with the edje_object_file_set()
   /// function. If that function does not return @c EINA_TRUE, one should
   /// check for the reason of failure with this one.
   ///
   /// @see edje_load_error_str()
   ///
   Edje_Load_Error load_error_get() const;

   /// @brief @brief Get the maximum size specified -- as an EDC property -- for a
   /// given Edje object
   ///
   /// This function retrieves the @p obj object's maximum size values,
   /// <b>as declared in its EDC group definition</b>. Maximum size of
   /// groups have the following syntax
   /// @code
   /// collections {
   /// group {
   /// name: "a_group";
   /// max: 100 100;
   /// }
   /// }
   /// @endcode
   ///
   /// where one declares a maximum size of 100 pixels both for width and
   /// height. Those are (hint) values which should be respected when the
   /// given object/group is to be controlled by a given container object
   /// (e.g. an Edje object being "swallowed" into a given @c SWALLOW
   /// typed part, as in edje_object_part_swallow()). Check the complete
   /// @ref edcref "syntax reference" for EDC files.
   ///
   /// @note If the @c max EDC property was not declared for @p obj, this
   /// call will return the maximum size a given Edje object may have, for
   /// each axis.
   ///
   /// @note On failure, this function will make all non-@c NULL size
   /// pointers' pointed variables be set to zero.
   ///
   /// @see edje_object_size_min_get()
   ///
   /// @param maxw Pointer to a variable where to store the maximum width
   /// @param maxh Pointer to a variable where to store the maximum height
   ///
   void size_max_get(Evas_Coord* maxw_, Evas_Coord* maxh_) const;

   /// Error occured in asynchronous file operation
   template <typename F>
   ::efl::eo::signal_connection
   callback_async_error_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_FILE_EVENT_ASYNC_ERROR, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EFL_FILE_EVENT_ASYNC_ERROR );
   }

   /// Error occured in asynchronous file operation
   template <typename T>
   void
   callback_async_error_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_FILE_EVENT_ASYNC_ERROR, info));
   }

   /// The file was successfully opened asynchronously
   template <typename F>
   ::efl::eo::signal_connection
   callback_async_opened_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_FILE_EVENT_ASYNC_OPENED, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EFL_FILE_EVENT_ASYNC_OPENED );
   }

   /// The file was successfully opened asynchronously
   template <typename T>
   void
   callback_async_opened_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_FILE_EVENT_ASYNC_OPENED, info));
   }

   /// A callback was added.
   template <typename F>
   ::efl::eo::signal_connection
   callback_callback_add_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EO_BASE_EVENT_CALLBACK_ADD, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EO_BASE_EVENT_CALLBACK_ADD );
   }

   /// A callback was added.
   template <typename T>
   void
   callback_callback_add_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EO_BASE_EVENT_CALLBACK_ADD, info));
   }

   /// A callback was deleted.
   template <typename F>
   ::efl::eo::signal_connection
   callback_callback_del_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EO_BASE_EVENT_CALLBACK_DEL, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EO_BASE_EVENT_CALLBACK_DEL );
   }

   /// A callback was deleted.
   template <typename T>
   void
   callback_callback_del_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EO_BASE_EVENT_CALLBACK_DEL, info));
   }

   /// Size hints changed event
   template <typename F>
   ::efl::eo::signal_connection
   callback_changed_size_hints_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_CHANGED_SIZE_HINTS, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_CHANGED_SIZE_HINTS );
   }

   /// Size hints changed event
   template <typename T>
   void
   callback_changed_size_hints_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_CHANGED_SIZE_HINTS, info));
   }

   /// Focus In Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_focus_in_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_FOCUS_IN, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_FOCUS_IN );
   }

   /// Focus In Event
   template <typename T>
   void
   callback_focus_in_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_FOCUS_IN, info));
   }

   /// Focus Out Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_focus_out_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_FOCUS_OUT, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_FOCUS_OUT );
   }

   /// Focus Out Event
   template <typename T>
   void
   callback_focus_out_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_FOCUS_OUT, info));
   }

   /// Object Being Freed (Called after Del)
   template <typename F>
   ::efl::eo::signal_connection
   callback_free_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_FREE, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_FREE );
   }

   /// Object Being Freed (Called after Del)
   template <typename T>
   void
   callback_free_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_FREE, info));
   }

   /// Hide Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_hide_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_HIDE, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_HIDE );
   }

   /// Hide Event
   template <typename T>
   void
   callback_hide_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_HIDE, info));
   }

   /// Events go on/off hold
   template <typename F>
   ::efl::eo::signal_connection
   callback_hold_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_HOLD, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_HOLD );
   }

   /// Events go on/off hold
   template <typename T>
   void
   callback_hold_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_HOLD, info));
   }

   /// Image has been preloaded
   template <typename F>
   ::efl::eo::signal_connection
   callback_image_preloaded_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_IMAGE_PRELOADED, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_IMAGE_PRELOADED );
   }

   /// Image has been preloaded
   template <typename T>
   void
   callback_image_preloaded_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_IMAGE_PRELOADED, info));
   }

   /// Image resize
   template <typename F>
   ::efl::eo::signal_connection
   callback_image_resize_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_IMAGE_RESIZE, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_IMAGE_RESIZE );
   }

   /// Image resize
   template <typename T>
   void
   callback_image_resize_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_IMAGE_RESIZE, info));
   }

   /// Image data has been unloaded (by some mechanism in Evas that throw out original image data)
   template <typename F>
   ::efl::eo::signal_connection
   callback_image_unloaded_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_IMAGE_UNLOADED, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_IMAGE_UNLOADED );
   }

   /// Image data has been unloaded (by some mechanism in Evas that throw out original image data)
   template <typename T>
   void
   callback_image_unloaded_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_IMAGE_UNLOADED, info));
   }

   /// Key Press Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_key_down_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_KEY_DOWN, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_KEY_DOWN );
   }

   /// Key Press Event
   template <typename T>
   void
   callback_key_down_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_KEY_DOWN, info));
   }

   /// Key Release Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_key_up_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_KEY_UP, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_KEY_UP );
   }

   /// Key Release Event
   template <typename T>
   void
   callback_key_up_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_KEY_UP, info));
   }

   /// Mouse Button Down Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_mouse_down_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MOUSE_DOWN, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MOUSE_DOWN );
   }

   /// Mouse Button Down Event
   template <typename T>
   void
   callback_mouse_down_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MOUSE_DOWN, info));
   }

   /// Mouse In Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_mouse_in_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MOUSE_IN, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MOUSE_IN );
   }

   /// Mouse In Event
   template <typename T>
   void
   callback_mouse_in_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MOUSE_IN, info));
   }

   /// Mouse Move Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_mouse_move_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MOUSE_MOVE, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MOUSE_MOVE );
   }

   /// Mouse Move Event
   template <typename T>
   void
   callback_mouse_move_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MOUSE_MOVE, info));
   }

   /// Mouse Out Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_mouse_out_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MOUSE_OUT, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MOUSE_OUT );
   }

   /// Mouse Out Event
   template <typename T>
   void
   callback_mouse_out_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MOUSE_OUT, info));
   }

   /// Mouse Button Up Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_mouse_up_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MOUSE_UP, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MOUSE_UP );
   }

   /// Mouse Button Up Event
   template <typename T>
   void
   callback_mouse_up_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MOUSE_UP, info));
   }

   /// Mouse Wheel Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_mouse_wheel_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MOUSE_WHEEL, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MOUSE_WHEEL );
   }

   /// Mouse Wheel Event
   template <typename T>
   void
   callback_mouse_wheel_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MOUSE_WHEEL, info));
   }

   /// Move Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_move_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MOVE, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MOVE );
   }

   /// Move Event
   template <typename T>
   void
   callback_move_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MOVE, info));
   }

   /// Mouse-touch Down Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_multi_down_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MULTI_DOWN, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MULTI_DOWN );
   }

   /// Mouse-touch Down Event
   template <typename T>
   void
   callback_multi_down_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MULTI_DOWN, info));
   }

   /// Multi-touch Move Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_multi_move_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MULTI_MOVE, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MULTI_MOVE );
   }

   /// Multi-touch Move Event
   template <typename T>
   void
   callback_multi_move_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MULTI_MOVE, info));
   }

   /// Mouse-touch Up Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_multi_up_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_MULTI_UP, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_MULTI_UP );
   }

   /// Mouse-touch Up Event
   template <typename T>
   void
   callback_multi_up_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_MULTI_UP, info));
   }

   /// Resize Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_resize_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_RESIZE, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_RESIZE );
   }

   /// Resize Event
   template <typename T>
   void
   callback_resize_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_RESIZE, info));
   }

   /// Restack Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_restack_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_RESTACK, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_RESTACK );
   }

   /// Restack Event
   template <typename T>
   void
   callback_restack_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_RESTACK, info));
   }

   /// Show Event
   template <typename F>
   ::efl::eo::signal_connection
   callback_show_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EVAS_OBJECT_EVENT_SHOW, priority_,
            &::efl::eo::_detail::event_callback<::edje::object, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::edje::object, function_type>,
         EVAS_OBJECT_EVENT_SHOW );
   }

   /// Show Event
   template <typename T>
   void
   callback_show_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EVAS_OBJECT_EVENT_SHOW, info));
   }



   static Eo_Class const* _eo_class()
   {
      return(EDJE_OBJECT_CLASS);
   }

   /// @cond LOCAL
   struct address_of
      : ::eo_cxx::edje::object::address_of<address_of>
      , ::eo_cxx::efl::file::address_of<address_of>
      , ::eo_cxx::efl::gfx::base::address_of<address_of>
      , ::eo_cxx::efl::gfx::stack::address_of<address_of>
      , ::eo_cxx::eo::base::address_of<address_of>
      , ::eo_cxx::evas::common_interface::address_of<address_of>
      , ::eo_cxx::evas::object::address_of<address_of>
      , ::eo_cxx::evas::object_smart::address_of<address_of>
      , ::eo_cxx::evas::signal_interface::address_of<address_of>
      , ::eo_cxx::evas::smart_clipped::address_of<address_of>
      , ::efl::eo::detail::concrete_address_of
   {
      explicit address_of(::edje::object* p)
         : ::efl::eo::detail::concrete_address_of(p)
      {}
   };
   address_of operator&() { return address_of(this); }

   struct address_const_of
      : ::eo_cxx::edje::object::address_const_of<address_const_of>
      , ::eo_cxx::efl::file::address_const_of<address_const_of>
      , ::eo_cxx::efl::gfx::base::address_const_of<address_const_of>
      , ::eo_cxx::efl::gfx::stack::address_const_of<address_const_of>
      , ::eo_cxx::eo::base::address_const_of<address_const_of>
      , ::eo_cxx::evas::common_interface::address_const_of<address_const_of>
      , ::eo_cxx::evas::object::address_const_of<address_const_of>
      , ::eo_cxx::evas::object_smart::address_const_of<address_const_of>
      , ::eo_cxx::evas::signal_interface::address_const_of<address_const_of>
      , ::eo_cxx::evas::smart_clipped::address_const_of<address_const_of>
      , ::efl::eo::detail::concrete_address_const_of
   {
      explicit address_const_of(::edje::object const* p)
         : ::efl::eo::detail::concrete_address_const_of(p)
      {}
   };
   address_const_of operator&() const { return address_const_of(this); }

   /// @endcond

private:

   /// @internal
   static Eo* _ctors_call(::efl::eo::parent_type _p)
   {
      Eo* _ret_eo = eo_add_ref(EDJE_OBJECT_CLASS, _p._eo_raw);

      return _ret_eo;
   }

   /// @internal
   Eo* _concrete_eo_ptr() const { return _eo_ptr(); }
};

static_assert(sizeof(::edje::object) == sizeof(Eo*), "");
static_assert(std::is_standard_layout<::edje::object>::value, "");

}


#include "edje_object.eo.impl.hh"

#endif // EFL_GENERATED_EDJE_OBJECT_HH

