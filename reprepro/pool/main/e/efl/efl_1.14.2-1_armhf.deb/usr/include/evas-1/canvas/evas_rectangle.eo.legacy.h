#ifndef _EVAS_RECTANGLE_EO_LEGACY_H_
#define _EVAS_RECTANGLE_EO_LEGACY_H_

#ifndef _EVAS_RECTANGLE_EO_CLASS_TYPE
#define _EVAS_RECTANGLE_EO_CLASS_TYPE

typedef Eo Evas_Rectangle;

#endif

#ifndef _EVAS_RECTANGLE_EO_TYPES
#define _EVAS_RECTANGLE_EO_TYPES


#endif

#endif
