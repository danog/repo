/// @cond EO_CXX_EO_IMPL

inline void efl::model::base::load() const
{
   eo_do(_concrete_eo_ptr(), ::efl_model_load());
}

inline void efl::model::base::unload() const
{
   eo_do(_concrete_eo_ptr(), ::efl_model_unload());
}

inline void efl::model::base::properties_load() const
{
   eo_do(_concrete_eo_ptr(), ::efl_model_properties_load());
}

inline void efl::model::base::children_load() const
{
   eo_do(_concrete_eo_ptr(), ::efl_model_children_load());
}

inline ::efl::eo::concrete efl::model::base::child_add() const
{
   Eo * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_child_add());
   return ::efl::eolian::to_cxx<::efl::eo::concrete>(_tmp_ret, std::tuple<std::false_type>());
}

inline Efl_Model_Load_Status efl::model::base::child_del(::efl::eo::concrete child_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_child_del(::efl::eolian::to_c(child_)));
   return _tmp_ret;
}

inline Efl_Model_Load_Status efl::model::base::load_status_get() const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_load_status_get());
   return _tmp_ret;
}

inline Efl_Model_Load_Status efl::model::base::properties_get(Eina_Array * const* properties_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_properties_get(properties_));
   return _tmp_ret;
}

inline Efl_Model_Load_Status efl::model::base::property_get(::efl::eina::string_view property_, const Eina_Value ** value_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_property_get(::efl::eolian::to_c(property_), value_));
   return _tmp_ret;
}

inline Efl_Model_Load_Status efl::model::base::property_set(::efl::eina::string_view property_, const Eina_Value * value_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_property_set(::efl::eolian::to_c(property_), value_));
   return _tmp_ret;
}

inline Efl_Model_Load_Status efl::model::base::children_slice_get(unsigned start_, unsigned count_, Eina_Accessor ** children_accessor_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_children_slice_get(start_, count_, children_accessor_));
   return _tmp_ret;
}

inline Efl_Model_Load_Status efl::model::base::children_count_get(unsigned* children_count_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_children_count_get(children_count_));
   return _tmp_ret;
}

inline void eo_cxx::efl::model::base::load() const
{
   eo_do(_concrete_eo_ptr(), ::efl_model_load());
}

inline void eo_cxx::efl::model::base::unload() const
{
   eo_do(_concrete_eo_ptr(), ::efl_model_unload());
}

inline void eo_cxx::efl::model::base::properties_load() const
{
   eo_do(_concrete_eo_ptr(), ::efl_model_properties_load());
}

inline void eo_cxx::efl::model::base::children_load() const
{
   eo_do(_concrete_eo_ptr(), ::efl_model_children_load());
}

inline ::efl::eo::concrete eo_cxx::efl::model::base::child_add() const
{
   Eo * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_child_add());
   return ::efl::eolian::to_cxx<::efl::eo::concrete>(_tmp_ret, std::tuple<std::false_type>());
}

inline Efl_Model_Load_Status eo_cxx::efl::model::base::child_del(::efl::eo::concrete child_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_child_del(::efl::eolian::to_c(child_)));
   return _tmp_ret;
}

inline Efl_Model_Load_Status eo_cxx::efl::model::base::load_status_get() const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_load_status_get());
   return _tmp_ret;
}

inline Efl_Model_Load_Status eo_cxx::efl::model::base::properties_get(Eina_Array * const* properties_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_properties_get(properties_));
   return _tmp_ret;
}

inline Efl_Model_Load_Status eo_cxx::efl::model::base::property_get(::efl::eina::string_view property_, const Eina_Value ** value_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_property_get(::efl::eolian::to_c(property_), value_));
   return _tmp_ret;
}

inline Efl_Model_Load_Status eo_cxx::efl::model::base::property_set(::efl::eina::string_view property_, const Eina_Value * value_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_property_set(::efl::eolian::to_c(property_), value_));
   return _tmp_ret;
}

inline Efl_Model_Load_Status eo_cxx::efl::model::base::children_slice_get(unsigned start_, unsigned count_, Eina_Accessor ** children_accessor_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_children_slice_get(start_, count_, children_accessor_));
   return _tmp_ret;
}

inline Efl_Model_Load_Status eo_cxx::efl::model::base::children_count_get(unsigned* children_count_) const
{
   Efl_Model_Load_Status _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::efl_model_children_count_get(children_count_));
   return _tmp_ret;
}

inline ::eo_cxx::efl::model::base::operator ::efl::model::base() const
{
   return *static_cast<::efl::model::base const*>(static_cast<void const*>(this));
}

inline ::eo_cxx::efl::model::base::operator ::efl::model::base&()
{
   return *static_cast<::efl::model::base*>(static_cast<void*>(this));
}

inline ::eo_cxx::efl::model::base::operator ::efl::model::base const&() const
{
   return *static_cast<::efl::model::base const*>(static_cast<void const*>(this));
}

template <typename T>
void efl_model_base_load_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   try
      {
         static_cast<T*>(self->this_)->load();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void efl_model_base_unload_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   try
      {
         static_cast<T*>(self->this_)->unload();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void efl_model_base_properties_load_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   try
      {
         static_cast<T*>(self->this_)->properties_load();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void efl_model_base_children_load_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   try
      {
         static_cast<T*>(self->this_)->children_load();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
::efl::eo::concrete efl_model_base_child_add_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   ::efl::eo::concrete _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->child_add();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Efl_Model_Load_Status efl_model_base_child_del_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Eo * child_)
{
   Efl_Model_Load_Status _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->child_del(::efl::eolian::to_cxx<::efl::eo::concrete>(child_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Efl_Model_Load_Status efl_model_base_load_status_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   Efl_Model_Load_Status _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->load_status_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Efl_Model_Load_Status efl_model_base_properties_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Eina_Array * const* properties_)
{
   Efl_Model_Load_Status _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->properties_get(properties_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Efl_Model_Load_Status efl_model_base_property_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * property_, const Eina_Value ** value_)
{
   Efl_Model_Load_Status _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->property_get(::efl::eolian::to_cxx<::efl::eina::string_view>(property_, std::tuple<std::false_type>()), value_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Efl_Model_Load_Status efl_model_base_property_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * property_, const Eina_Value * value_)
{
   Efl_Model_Load_Status _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->property_set(::efl::eolian::to_cxx<::efl::eina::string_view>(property_, std::tuple<std::false_type>()), value_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Efl_Model_Load_Status efl_model_base_children_slice_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, unsigned start_, unsigned count_, Eina_Accessor ** children_accessor_)
{
   Efl_Model_Load_Status _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->children_slice_get(start_, count_, children_accessor_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Efl_Model_Load_Status efl_model_base_children_count_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, unsigned* children_count_)
{
   Efl_Model_Load_Status _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->children_count_get(children_count_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

namespace efl { namespace eo { namespace detail {

template<>
struct operations< ::efl::model::base >
{
   template <typename T>
   struct type
   {
      virtual void load()
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::efl_model_load());
      }

      virtual void unload()
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::efl_model_unload());
      }

      virtual void properties_load()
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::efl_model_properties_load());
      }

      virtual void children_load()
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::efl_model_children_load());
      }

      virtual ::efl::eo::concrete child_add()
      {
         Eo * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::efl_model_child_add());
            return ::efl::eolian::to_cxx<::efl::eo::concrete>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual Efl_Model_Load_Status child_del(::efl::eo::concrete child_)
      {
         Efl_Model_Load_Status _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::efl_model_child_del(::efl::eolian::to_c(child_)));
            return _tmp_ret;
      }

      virtual Efl_Model_Load_Status load_status_get()
      {
         Efl_Model_Load_Status _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::efl_model_load_status_get());
            return _tmp_ret;
      }

      virtual Efl_Model_Load_Status properties_get(Eina_Array * const* properties_)
      {
         Efl_Model_Load_Status _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::efl_model_properties_get(properties_));
            return _tmp_ret;
      }

      virtual Efl_Model_Load_Status property_get(::efl::eina::string_view property_, const Eina_Value ** value_)
      {
         Efl_Model_Load_Status _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::efl_model_property_get(::efl::eolian::to_c(property_), value_));
            return _tmp_ret;
      }

      virtual Efl_Model_Load_Status property_set(::efl::eina::string_view property_, const Eina_Value * value_)
      {
         Efl_Model_Load_Status _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::efl_model_property_set(::efl::eolian::to_c(property_), value_));
            return _tmp_ret;
      }

      virtual Efl_Model_Load_Status children_slice_get(unsigned start_, unsigned count_, Eina_Accessor ** children_accessor_)
      {
         Efl_Model_Load_Status _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::efl_model_children_slice_get(start_, count_, children_accessor_));
            return _tmp_ret;
      }

      virtual Efl_Model_Load_Status children_count_get(unsigned* children_count_)
      {
         Efl_Model_Load_Status _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::efl_model_children_count_get(children_count_));
            return _tmp_ret;
      }

   };
};


#ifdef BASE_PROTECTED
template<>
struct operation_description_class_size< ::efl::model::base >
{
   static constexpr int value = 12;
};

#else
template<>
struct operation_description_class_size< ::efl::model::base >
{
   static constexpr int value = 12;
};

#endif

template <typename T>
int initialize_operation_description(::efl::eo::detail::tag<::efl::model::base>
                                 , Eo_Op_Description* ops)
{
   (void)ops;
   ops[0].func = reinterpret_cast<void*>(& ::efl_model_base_load_wrapper<T>);
   ops[0].api_func = reinterpret_cast<void*>(& ::efl_model_load);
   ops[0].op = EO_OP_OVERRIDE;
   ops[0].op_type = EO_OP_TYPE_REGULAR;
   ops[0].doc = NULL;

   ops[1].func = reinterpret_cast<void*>(& ::efl_model_base_unload_wrapper<T>);
   ops[1].api_func = reinterpret_cast<void*>(& ::efl_model_unload);
   ops[1].op = EO_OP_OVERRIDE;
   ops[1].op_type = EO_OP_TYPE_REGULAR;
   ops[1].doc = NULL;

   ops[2].func = reinterpret_cast<void*>(& ::efl_model_base_properties_load_wrapper<T>);
   ops[2].api_func = reinterpret_cast<void*>(& ::efl_model_properties_load);
   ops[2].op = EO_OP_OVERRIDE;
   ops[2].op_type = EO_OP_TYPE_REGULAR;
   ops[2].doc = NULL;

   ops[3].func = reinterpret_cast<void*>(& ::efl_model_base_children_load_wrapper<T>);
   ops[3].api_func = reinterpret_cast<void*>(& ::efl_model_children_load);
   ops[3].op = EO_OP_OVERRIDE;
   ops[3].op_type = EO_OP_TYPE_REGULAR;
   ops[3].doc = NULL;

   ops[4].func = reinterpret_cast<void*>(& ::efl_model_base_child_add_wrapper<T>);
   ops[4].api_func = reinterpret_cast<void*>(& ::efl_model_child_add);
   ops[4].op = EO_OP_OVERRIDE;
   ops[4].op_type = EO_OP_TYPE_REGULAR;
   ops[4].doc = NULL;

   ops[5].func = reinterpret_cast<void*>(& ::efl_model_base_child_del_wrapper<T>);
   ops[5].api_func = reinterpret_cast<void*>(& ::efl_model_child_del);
   ops[5].op = EO_OP_OVERRIDE;
   ops[5].op_type = EO_OP_TYPE_REGULAR;
   ops[5].doc = NULL;

   ops[6].func = reinterpret_cast<void*>(& ::efl_model_base_load_status_get_wrapper<T>);
   ops[6].api_func = reinterpret_cast<void*>(& ::efl_model_load_status_get);
   ops[6].op = EO_OP_OVERRIDE;
   ops[6].op_type = EO_OP_TYPE_REGULAR;
   ops[6].doc = NULL;

   ops[7].func = reinterpret_cast<void*>(& ::efl_model_base_properties_get_wrapper<T>);
   ops[7].api_func = reinterpret_cast<void*>(& ::efl_model_properties_get);
   ops[7].op = EO_OP_OVERRIDE;
   ops[7].op_type = EO_OP_TYPE_REGULAR;
   ops[7].doc = NULL;

   ops[8].func = reinterpret_cast<void*>(& ::efl_model_base_property_get_wrapper<T>);
   ops[8].api_func = reinterpret_cast<void*>(& ::efl_model_property_get);
   ops[8].op = EO_OP_OVERRIDE;
   ops[8].op_type = EO_OP_TYPE_REGULAR;
   ops[8].doc = NULL;

   ops[9].func = reinterpret_cast<void*>(& ::efl_model_base_property_set_wrapper<T>);
   ops[9].api_func = reinterpret_cast<void*>(& ::efl_model_property_set);
   ops[9].op = EO_OP_OVERRIDE;
   ops[9].op_type = EO_OP_TYPE_REGULAR;
   ops[9].doc = NULL;

   ops[10].func = reinterpret_cast<void*>(& ::efl_model_base_children_slice_get_wrapper<T>);
   ops[10].api_func = reinterpret_cast<void*>(& ::efl_model_children_slice_get);
   ops[10].op = EO_OP_OVERRIDE;
   ops[10].op_type = EO_OP_TYPE_REGULAR;
   ops[10].doc = NULL;

   ops[11].func = reinterpret_cast<void*>(& ::efl_model_base_children_count_get_wrapper<T>);
   ops[11].api_func = reinterpret_cast<void*>(& ::efl_model_children_count_get);
   ops[11].op = EO_OP_OVERRIDE;
   ops[11].op_type = EO_OP_TYPE_REGULAR;
   ops[11].doc = NULL;

   return 0;
}
inline Eo_Class const* get_eo_class(tag<::efl::model::base>)
{
   return (EFL_MODEL_BASE_INTERFACE);
}

} } }

/// @endcond

