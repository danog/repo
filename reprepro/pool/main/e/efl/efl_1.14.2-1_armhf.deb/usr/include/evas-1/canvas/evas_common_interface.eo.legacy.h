#ifndef _EVAS_COMMON_INTERFACE_EO_LEGACY_H_
#define _EVAS_COMMON_INTERFACE_EO_LEGACY_H_

#ifndef _EVAS_COMMON_INTERFACE_EO_CLASS_TYPE
#define _EVAS_COMMON_INTERFACE_EO_CLASS_TYPE

typedef Eo Evas_Common_Interface;

#endif

#ifndef _EVAS_COMMON_INTERFACE_EO_TYPES
#define _EVAS_COMMON_INTERFACE_EO_TYPES


#endif

/**
 *
 * No description supplied by the EAPI.
 *
 */
EAPI Evas *evas_object_evas_get(const Evas_Common_Interface *obj);

#endif
