/// @cond EO_CXX_EO_IMPL

template <typename F_func_>
inline ::ecore::timer::_c_constructor<F_func_> ecore::timer::constructor(double in_, F_func_ && func_)
{
   return _c_constructor<F_func_>(in_, std::forward<F_func_>(func_));
}

template <typename F_func_>
inline ::ecore::timer::_c_loop_constructor<F_func_> ecore::timer::loop_constructor(double in_, F_func_ && func_)
{
   return _c_loop_constructor<F_func_>(in_, std::forward<F_func_>(func_));
}

inline void ecore::timer::reset() const
{
   eo_do(_concrete_eo_ptr(), ::ecore_obj_timer_reset());
}

inline void ecore::timer::delay(double add_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_obj_timer_delay(add_));
}

inline double ecore::timer::interval_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_obj_timer_interval_get());
   return _tmp_ret;
}

inline void ecore::timer::interval_set(double in_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_obj_timer_interval_set(in_));
}

inline double ecore::timer::pending_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_obj_timer_pending_get());
   return _tmp_ret;
}

inline void eo_cxx::ecore::timer::reset() const
{
   eo_do(_concrete_eo_ptr(), ::ecore_obj_timer_reset());
}

inline void eo_cxx::ecore::timer::delay(double add_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_obj_timer_delay(add_));
}

inline double eo_cxx::ecore::timer::interval_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_obj_timer_interval_get());
   return _tmp_ret;
}

inline void eo_cxx::ecore::timer::interval_set(double in_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_obj_timer_interval_set(in_));
}

inline double eo_cxx::ecore::timer::pending_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_obj_timer_pending_get());
   return _tmp_ret;
}

inline ::eo_cxx::ecore::timer::operator ::ecore::timer() const
{
   return *static_cast<::ecore::timer const*>(static_cast<void const*>(this));
}

inline ::eo_cxx::ecore::timer::operator ::ecore::timer&()
{
   return *static_cast<::ecore::timer*>(static_cast<void*>(this));
}

inline ::eo_cxx::ecore::timer::operator ::ecore::timer const&() const
{
   return *static_cast<::ecore::timer const*>(static_cast<void const*>(this));
}

template <typename T>
void ecore_timer_reset_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   try
      {
         static_cast<T*>(self->this_)->reset();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void ecore_timer_delay_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, double add_)
{
   try
      {
         static_cast<T*>(self->this_)->delay(add_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
double ecore_timer_interval_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   double _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->interval_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void ecore_timer_interval_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, double in_)
{
   try
      {
         static_cast<T*>(self->this_)->interval_set(in_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
double ecore_timer_pending_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   double _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->pending_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

namespace efl { namespace eo { namespace detail {

template<>
struct operations< ::ecore::timer >
{
   template <typename T>
   struct type
         : virtual operations< ::eo::base >::template type<T>
   {
      virtual void reset()
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::ecore_obj_timer_reset());
      }

      virtual void delay(double add_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::ecore_obj_timer_delay(add_));
      }

      virtual double interval_get()
      {
         double _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_obj_timer_interval_get());
            return _tmp_ret;
      }

      virtual void interval_set(double in_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::ecore_obj_timer_interval_set(in_));
      }

      virtual double pending_get()
      {
         double _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_obj_timer_pending_get());
            return _tmp_ret;
      }

   };
};


#ifdef TIMER_PROTECTED
template<>
struct operation_description_class_size< ::ecore::timer >
{
   static constexpr int value = 5 + operation_description_class_size<::eo::base >::value;
};

#else
template<>
struct operation_description_class_size< ::ecore::timer >
{
   static constexpr int value = 5 + operation_description_class_size<::eo::base >::value;
};

#endif

template <typename T>
int initialize_operation_description(::efl::eo::detail::tag<::ecore::timer>
                                 , Eo_Op_Description* ops)
{
   (void)ops;
   ops[0].func = reinterpret_cast<void*>(& ::ecore_timer_reset_wrapper<T>);
   ops[0].api_func = reinterpret_cast<void*>(& ::ecore_obj_timer_reset);
   ops[0].op = EO_OP_OVERRIDE;
   ops[0].op_type = EO_OP_TYPE_REGULAR;
   ops[0].doc = NULL;

   ops[1].func = reinterpret_cast<void*>(& ::ecore_timer_delay_wrapper<T>);
   ops[1].api_func = reinterpret_cast<void*>(& ::ecore_obj_timer_delay);
   ops[1].op = EO_OP_OVERRIDE;
   ops[1].op_type = EO_OP_TYPE_REGULAR;
   ops[1].doc = NULL;

   ops[2].func = reinterpret_cast<void*>(& ::ecore_timer_interval_get_wrapper<T>);
   ops[2].api_func = reinterpret_cast<void*>(& ::ecore_obj_timer_interval_get);
   ops[2].op = EO_OP_OVERRIDE;
   ops[2].op_type = EO_OP_TYPE_REGULAR;
   ops[2].doc = NULL;

   ops[3].func = reinterpret_cast<void*>(& ::ecore_timer_interval_set_wrapper<T>);
   ops[3].api_func = reinterpret_cast<void*>(& ::ecore_obj_timer_interval_set);
   ops[3].op = EO_OP_OVERRIDE;
   ops[3].op_type = EO_OP_TYPE_REGULAR;
   ops[3].doc = NULL;

   ops[4].func = reinterpret_cast<void*>(& ::ecore_timer_pending_get_wrapper<T>);
   ops[4].api_func = reinterpret_cast<void*>(& ::ecore_obj_timer_pending_get);
   ops[4].op = EO_OP_OVERRIDE;
   ops[4].op_type = EO_OP_TYPE_REGULAR;
   ops[4].doc = NULL;

   initialize_operation_description<T>(::efl::eo::detail::tag<::eo::base>(), &ops[operation_description_class_size< ::ecore::timer >::value]);
   return 0;
}
inline Eo_Class const* get_eo_class(tag<::ecore::timer>)
{
   return (ECORE_TIMER_CLASS);
}

} } }

/// @endcond

