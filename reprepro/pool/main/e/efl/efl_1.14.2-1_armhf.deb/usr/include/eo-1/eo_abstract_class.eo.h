#ifndef _EO_ABSTRACT_CLASS_EO_H_
#define _EO_ABSTRACT_CLASS_EO_H_

#ifndef _EO_ABSTRACT_CLASS_EO_CLASS_TYPE
#define _EO_ABSTRACT_CLASS_EO_CLASS_TYPE

typedef Eo Eo_Abstract_Class;

#endif

#ifndef _EO_ABSTRACT_CLASS_EO_TYPES
#define _EO_ABSTRACT_CLASS_EO_TYPES


#endif
#define EO_ABSTRACT_CLASS_CLASS eo_abstract_class_class_get()

EAPI const Eo_Class *eo_abstract_class_class_get(void) EINA_CONST;


#endif
