#ifndef EFL_GENERATED_EFL_GFX_SHAPE_HH
#define EFL_GENERATED_EFL_GFX_SHAPE_HH

extern "C"
{
#include <Efl.h>
}
#include <Eo.hh>

#include <eo_cxx_interop.hh>

extern "C"
{
#include "efl_gfx_shape.eo.h"
}

#include <eo_concrete.hh>
#include <string>

namespace efl { namespace gfx {

struct shape;

} }

/// @cond EO_CXX_ABSTRACT
namespace eo_cxx {

namespace efl { namespace gfx {

struct shape
{
   /// @brief Copy the shape data from the object specified .
   ///
   /// @since 1.14
   ///
   /// @param dup_from Shape object from where data will be copied.
   ///
   void dup(::efl::eo::concrete dup_from_) const;

   /// @brief Compute and return the bounding box of the currently set path
   ///
   /// @since 1.14
   ///
   /// @param[out] r Contain the bounding box of the currently set path
   ///
   void bounds_get(Eina_Rectangle* r_) const;

   /// @brief Reset the shape data of the shape object.
   ///
   /// @since 1.14
   ///
   void reset() const;

   /// @brief Moves the current point to the given point, 
   /// implicitly starting a new subpath and closing the previous one.
   ///
   /// @see efl_gfx_path_append_close()
   /// @since 1.14
   ///
   /// @param x X co-ordinate of the current point.
   /// @param y Y co-ordinate of the current point.
   ///
   void append_move_to(double x_, double y_) const;

   /// @brief Adds a straight line from the current position to the given endPoint.
   /// After the line is drawn, the current position is updated to be at the end
   /// point of the line.
   ///
   /// @note if no current position present, it draws a line to itself, basically
   /// a point.
   ///
   /// @see efl_gfx_path_append_move_to()
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   ///
   void append_line_to(double x_, double y_) const;

   /// @brief Adds a quadratic Bezier curve between the current position and the
   /// given end point (x,y) using the control points specified by (ctrl_x, ctrl_y).
   /// After the path is drawn, the current position is updated to be at the end
   /// point of the path.
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   /// @param ctrl_x X co-ordinate of control point.
   /// @param ctrl_y Y co-ordinate of control point.
   ///
   void append_quadratic_to(double x_, double y_, double ctrl_x_, double ctrl_y_) const;

   /// @brief Same as efl_gfx_path_append_quadratic_to() api only difference is that it
   /// uses the current control point to draw the bezier.
   ///
   /// @see efl_gfx_path_append_quadratic_to()
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   ///
   void append_squadratic_to(double x_, double y_) const;

   /// @brief Adds a cubic Bezier curve between the current position and the
   /// given end point (x,y) using the control points specified by
   /// (ctrl_x0, ctrl_y0), and (ctrl_x1, ctrl_y1). After the path is drawn,
   /// the current position is updated to be at the end point of the path.
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   /// @param ctrl_x0 X co-ordinate of 1st control point.
   /// @param ctrl_y0 Y co-ordinate of 1st control point.
   /// @param ctrl_x1 X co-ordinate of 2nd control point.
   /// @param ctrl_y1 Y co-ordinate of 2nd control point.
   ///
   void append_cubic_to(double x_, double y_, double ctrl_x0_, double ctrl_y0_, double ctrl_x1_, double ctrl_y1_) const;

   /// @brief Same as efl_gfx_path_append_cubic_to() api only difference is that it uses
   /// the current control point to draw the bezier.
   ///
   /// @see efl_gfx_path_append_cubic_to()
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   /// @param ctrl_x X co-ordinate of 2nd control point.
   /// @param ctrl_y Y co-ordinate of 2nd control point.
   ///
   void append_scubic_to(double x_, double y_, double ctrl_x_, double ctrl_y_) const;

   /// @brief Append an arc that connects from the current point int the point list
   /// to the given point (x,y). The arc is defined by the given radius in 
   /// x-direction (rx) and radius in y direction (ry) .
   ///
   /// @note Use this api if you know the end point's of the arc otherwise
   /// use more convenient function efl_gfx_path_append_arc_to()
   ///
   /// @see efl_gfx_path_append_arc_to()
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the arc.
   /// @param y Y co-ordinate of end point of the arc.
   /// @param rx radius of arc in x direction.
   /// @param ry radius of arc in y direction.
   /// @param angle x-axis rotation , normally 0.
   /// @param large_arc Defines whether to draw the larger arc or smaller arc joining two point.
   /// @param sweep Defines whether the arc will be drawn counter-clockwise or clockwise from current point to the end point taking into account the large_arc property.
   ///
   void append_arc_to(double x_, double y_, double rx_, double ry_, double angle_, bool large_arc_, bool sweep_) const;

   /// @brief Closes the current subpath by drawing a line to the beginning of the subpath,
   /// automatically starting a new path. The current point of the new path is
   /// (0, 0).
   ///
   /// @note If the subpath does not contain any points, this function does nothing.
   ///
   /// @since 1.14
   ///
   void append_close() const;

   /// @brief Append a circle with given center and radius.
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of the center of the circle.
   /// @param y Y co-ordinate of the center of the circle.
   /// @param radius radius of the circle.
   ///
   void append_circle(double x_, double y_, double radius_) const;

   /// @brief Append the given rectangle with rounded corner to the path.
   ///
   /// The xr and yr arguments specify the radii of the ellipses defining the
   /// corners of the rounded rectangle.
   ///
   /// @note xr and yr are specified in terms of width and height respectively.
   ///
   /// @note if xr and yr are 0, then it will draw a rectangle without rounded corner.
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of the rectangle.
   /// @param y Y co-ordinate of the rectangle.
   /// @param w Width of the rectangle.
   /// @param h Height of the rectangle.
   /// @param rx The x radius of the rounded corner and should be in range [ 0 to w/2 ]
   /// @param ry The y radius of the rounded corner and should be in range [ 0 to h/2 ]
   ///
   void append_rect(double x_, double y_, double w_, double h_, double rx_, double ry_) const;

   /// @param svg_path_data 
   ///
   void append_svg_path(::efl::eina::string_view svg_path_data_) const;

   /// @param from 
   /// @param to 
   /// @param pos_map 
   ///
   bool interpolate(const Eo * from_, const Eo * to_, double pos_map_) const;

   /// @param with 
   ///
   bool equal_commands(const Eo * with_) const;

   /// @brief Get the stroke scaling factor used for stroking this path.
   /// @since 1.14
   ///
   /// @param s stroke scale value
   ///
   double stroke_scale_get() const;

   /// @brief Sets the stroke scale to be used for stroking the path.
   /// the scale property will be used along with stroke width property.
   /// @since 1.14
   ///
   /// @param s stroke scale value
   ///
   void stroke_scale_set(double s_) const;

   /// @brief Gets the color used for stroking the path.
   /// @since 1.14
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   void stroke_color_get(int* r_, int* g_, int* b_, int* a_) const;

   /// @brief Sets the color to be used for stroking the path.
   /// @since 1.14
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   void stroke_color_set(int r_, int g_, int b_, int a_) const;

   /// @brief Gets the stroke width to be used for stroking the path.
   /// @since 1.14
   ///
   /// @param w stroke width to be used
   ///
   double stroke_width_get() const;

   /// @brief Sets the stroke width to be used for stroking the path.
   /// @since 1.14
   ///
   /// @param w stroke width to be used
   ///
   void stroke_width_set(double w_) const;

   /// @brief Not Implemented
   ///
   /// @param centered 
   ///
   double stroke_location_get() const;

   /// @brief Not Implemented
   ///
   /// @param centered 
   ///
   void stroke_location_set(double centered_) const;

   /// @brief Not Implemented
   ///
   /// @param dash 
   /// @param length 
   ///
   void stroke_dash_get(const Efl_Gfx_Dash ** dash_, unsigned int* length_) const;

   /// @brief Not Implemented
   ///
   /// @param dash 
   /// @param length 
   ///
   void stroke_dash_set(const Efl_Gfx_Dash * dash_, unsigned int length_) const;

   /// @brief Gets the cap style used for stroking path.
   /// @since 1.14
   ///
   /// @param c cap style to use , default is EFL_GFX_CAP_BUTT
   ///
   Efl_Gfx_Cap stroke_cap_get() const;

   /// @brief Sets the cap style to be used for stroking the path.
   /// The cap will be used for capping the end point of a 
   /// open subpath.
   ///
   /// @see Efl_Gfx_Cap
   /// @since 1.14
   ///
   /// @param c cap style to use , default is EFL_GFX_CAP_BUTT
   ///
   void stroke_cap_set(Efl_Gfx_Cap c_) const;

   /// @brief Gets the join style used for stroking path.
   /// @since 1.14
   ///
   /// @param j join style to use , default is
   /// EFL_GFX_JOIN_MITER
   ///
   Efl_Gfx_Join stroke_join_get() const;

   /// @brief Sets the join style to be used for stroking the path.
   /// The join style will be used for joining the two line segment
   /// while stroking teh path.
   ///
   /// @see Efl_Gfx_Join
   /// @since 1.14
   ///
   /// @param j join style to use , default is
   /// EFL_GFX_JOIN_MITER
   ///
   void stroke_join_set(Efl_Gfx_Join j_) const;

   /// @brief Gets the command and points list
   /// @since 1.14
   ///
   /// @param op command list
   /// @param points point list
   ///
   void path_get(const Efl_Gfx_Path_Command ** op_, const double ** points_) const;

   /// @brief Set the list of commands and points to be used to create the
   /// content of shape.
   ///
   /// @note see efl_gfx_path interface for how to create a command list.
   /// @see Efl_Gfx_Path_Command
   /// @since 1.14
   ///
   /// @param op command list
   /// @param points point list
   ///
   void path_set(const Efl_Gfx_Path_Command * op_, const double * points_) const;

   /// @param commands 
   /// @param points 
   ///
   void path_length_get(unsigned int* commands_, unsigned int* points_) const;

   /// @param x 
   /// @param y 
   ///
   void current_get(double* x_, double* y_) const;

   /// @param x 
   /// @param y 
   ///
   void current_ctrl_get(double* x_, double* y_) const;



   static Eo_Class const* _eo_class()
   {
      return(EFL_GFX_SHAPE_MIXIN);
   }

   operator ::efl::gfx::shape() const;
   operator ::efl::gfx::shape&();
   operator ::efl::gfx::shape const&() const;

   /// @cond LOCAL
   template <typename D>
   struct address_of
   {
      operator ::efl::gfx::shape*() const { return static_cast<::efl::gfx::shape*>(static_cast<D const*>(this)->p); }
      operator ::efl::gfx::shape const*() const { return static_cast<::efl::gfx::shape const*>(static_cast<D const*>(this)->p); }
   };

   template <typename D>
   struct address_const_of
   {
      operator ::efl::gfx::shape const*() const { return static_cast<::efl::gfx::shape const*>(static_cast<D const*>(this)->p); }
   };
   /// @endcond

private:

   /// @internal
   Eo* _concrete_eo_ptr() const
   {
      return static_cast<::efl::eo::concrete const*>(static_cast<void const*>(this))->_eo_ptr();
   }

};

} }

}
/// @endcond

namespace efl { namespace gfx {

/// @brief Class shape
struct shape
      : ::efl::eo::concrete
{
   //@{
   /**
      @brief Constructs a new efl::gfx::shape object.

      Constructs a new efl::gfx::shape object. If you want this object to be a child
      of another Eo object, use an @ref efl::eo::parent expression, like the example.

      Example:
      @code
      efl::gfx::shape my_shape(efl::eo::parent = parent_object);
      @endcode

      @see shape(Eo* eo)
   */
   explicit shape(::efl::eo::parent_type _p)
      : shape(_ctors_call(_p))
   {}

   explicit shape()
      : shape(_ctors_call(::efl::eo::parent = nullptr))
   {}
   //@}

   /// @brief Eo Constructor.
   ///
   /// Constructs the object from an Eo* pointer stealing its ownership.
   ///
   /// @param eo The Eo object pointer.
   ///
   explicit shape(Eo* eo)
      : ::efl::eo::concrete(eo)
   {}

   /// @brief nullptr_t Constructor.
   ///
   /// Constructs an empty (null) object.
   ///
   explicit shape(std::nullptr_t)
      : ::efl::eo::concrete(nullptr)
   {}

   /// @brief Copy Constructor.
   ///
   shape(shape const& other)
      : shape(eo_ref(other._eo_ptr()))
   {}

   ~shape() {}

   /// @brief Copy the shape data from the object specified .
   ///
   /// @since 1.14
   ///
   /// @param dup_from Shape object from where data will be copied.
   ///
   void dup(::efl::eo::concrete dup_from_) const;

   /// @brief Compute and return the bounding box of the currently set path
   ///
   /// @since 1.14
   ///
   /// @param[out] r Contain the bounding box of the currently set path
   ///
   void bounds_get(Eina_Rectangle* r_) const;

   /// @brief Reset the shape data of the shape object.
   ///
   /// @since 1.14
   ///
   void reset() const;

   /// @brief Moves the current point to the given point, 
   /// implicitly starting a new subpath and closing the previous one.
   ///
   /// @see efl_gfx_path_append_close()
   /// @since 1.14
   ///
   /// @param x X co-ordinate of the current point.
   /// @param y Y co-ordinate of the current point.
   ///
   void append_move_to(double x_, double y_) const;

   /// @brief Adds a straight line from the current position to the given endPoint.
   /// After the line is drawn, the current position is updated to be at the end
   /// point of the line.
   ///
   /// @note if no current position present, it draws a line to itself, basically
   /// a point.
   ///
   /// @see efl_gfx_path_append_move_to()
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   ///
   void append_line_to(double x_, double y_) const;

   /// @brief Adds a quadratic Bezier curve between the current position and the
   /// given end point (x,y) using the control points specified by (ctrl_x, ctrl_y).
   /// After the path is drawn, the current position is updated to be at the end
   /// point of the path.
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   /// @param ctrl_x X co-ordinate of control point.
   /// @param ctrl_y Y co-ordinate of control point.
   ///
   void append_quadratic_to(double x_, double y_, double ctrl_x_, double ctrl_y_) const;

   /// @brief Same as efl_gfx_path_append_quadratic_to() api only difference is that it
   /// uses the current control point to draw the bezier.
   ///
   /// @see efl_gfx_path_append_quadratic_to()
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   ///
   void append_squadratic_to(double x_, double y_) const;

   /// @brief Adds a cubic Bezier curve between the current position and the
   /// given end point (x,y) using the control points specified by
   /// (ctrl_x0, ctrl_y0), and (ctrl_x1, ctrl_y1). After the path is drawn,
   /// the current position is updated to be at the end point of the path.
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   /// @param ctrl_x0 X co-ordinate of 1st control point.
   /// @param ctrl_y0 Y co-ordinate of 1st control point.
   /// @param ctrl_x1 X co-ordinate of 2nd control point.
   /// @param ctrl_y1 Y co-ordinate of 2nd control point.
   ///
   void append_cubic_to(double x_, double y_, double ctrl_x0_, double ctrl_y0_, double ctrl_x1_, double ctrl_y1_) const;

   /// @brief Same as efl_gfx_path_append_cubic_to() api only difference is that it uses
   /// the current control point to draw the bezier.
   ///
   /// @see efl_gfx_path_append_cubic_to()
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the line.
   /// @param y Y co-ordinate of end point of the line.
   /// @param ctrl_x X co-ordinate of 2nd control point.
   /// @param ctrl_y Y co-ordinate of 2nd control point.
   ///
   void append_scubic_to(double x_, double y_, double ctrl_x_, double ctrl_y_) const;

   /// @brief Append an arc that connects from the current point int the point list
   /// to the given point (x,y). The arc is defined by the given radius in 
   /// x-direction (rx) and radius in y direction (ry) .
   ///
   /// @note Use this api if you know the end point's of the arc otherwise
   /// use more convenient function efl_gfx_path_append_arc_to()
   ///
   /// @see efl_gfx_path_append_arc_to()
   /// @since 1.14
   ///
   /// @param x X co-ordinate of end point of the arc.
   /// @param y Y co-ordinate of end point of the arc.
   /// @param rx radius of arc in x direction.
   /// @param ry radius of arc in y direction.
   /// @param angle x-axis rotation , normally 0.
   /// @param large_arc Defines whether to draw the larger arc or smaller arc joining two point.
   /// @param sweep Defines whether the arc will be drawn counter-clockwise or clockwise from current point to the end point taking into account the large_arc property.
   ///
   void append_arc_to(double x_, double y_, double rx_, double ry_, double angle_, bool large_arc_, bool sweep_) const;

   /// @brief Closes the current subpath by drawing a line to the beginning of the subpath,
   /// automatically starting a new path. The current point of the new path is
   /// (0, 0).
   ///
   /// @note If the subpath does not contain any points, this function does nothing.
   ///
   /// @since 1.14
   ///
   void append_close() const;

   /// @brief Append a circle with given center and radius.
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of the center of the circle.
   /// @param y Y co-ordinate of the center of the circle.
   /// @param radius radius of the circle.
   ///
   void append_circle(double x_, double y_, double radius_) const;

   /// @brief Append the given rectangle with rounded corner to the path.
   ///
   /// The xr and yr arguments specify the radii of the ellipses defining the
   /// corners of the rounded rectangle.
   ///
   /// @note xr and yr are specified in terms of width and height respectively.
   ///
   /// @note if xr and yr are 0, then it will draw a rectangle without rounded corner.
   ///
   /// @since 1.14
   ///
   /// @param x X co-ordinate of the rectangle.
   /// @param y Y co-ordinate of the rectangle.
   /// @param w Width of the rectangle.
   /// @param h Height of the rectangle.
   /// @param rx The x radius of the rounded corner and should be in range [ 0 to w/2 ]
   /// @param ry The y radius of the rounded corner and should be in range [ 0 to h/2 ]
   ///
   void append_rect(double x_, double y_, double w_, double h_, double rx_, double ry_) const;

   /// @param svg_path_data 
   ///
   void append_svg_path(::efl::eina::string_view svg_path_data_) const;

   /// @param from 
   /// @param to 
   /// @param pos_map 
   ///
   bool interpolate(const Eo * from_, const Eo * to_, double pos_map_) const;

   /// @param with 
   ///
   bool equal_commands(const Eo * with_) const;

   /// @brief Get the stroke scaling factor used for stroking this path.
   /// @since 1.14
   ///
   /// @param s stroke scale value
   ///
   double stroke_scale_get() const;

   /// @brief Sets the stroke scale to be used for stroking the path.
   /// the scale property will be used along with stroke width property.
   /// @since 1.14
   ///
   /// @param s stroke scale value
   ///
   void stroke_scale_set(double s_) const;

   /// @brief Gets the color used for stroking the path.
   /// @since 1.14
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   void stroke_color_get(int* r_, int* g_, int* b_, int* a_) const;

   /// @brief Sets the color to be used for stroking the path.
   /// @since 1.14
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   void stroke_color_set(int r_, int g_, int b_, int a_) const;

   /// @brief Gets the stroke width to be used for stroking the path.
   /// @since 1.14
   ///
   /// @param w stroke width to be used
   ///
   double stroke_width_get() const;

   /// @brief Sets the stroke width to be used for stroking the path.
   /// @since 1.14
   ///
   /// @param w stroke width to be used
   ///
   void stroke_width_set(double w_) const;

   /// @brief Not Implemented
   ///
   /// @param centered 
   ///
   double stroke_location_get() const;

   /// @brief Not Implemented
   ///
   /// @param centered 
   ///
   void stroke_location_set(double centered_) const;

   /// @brief Not Implemented
   ///
   /// @param dash 
   /// @param length 
   ///
   void stroke_dash_get(const Efl_Gfx_Dash ** dash_, unsigned int* length_) const;

   /// @brief Not Implemented
   ///
   /// @param dash 
   /// @param length 
   ///
   void stroke_dash_set(const Efl_Gfx_Dash * dash_, unsigned int length_) const;

   /// @brief Gets the cap style used for stroking path.
   /// @since 1.14
   ///
   /// @param c cap style to use , default is EFL_GFX_CAP_BUTT
   ///
   Efl_Gfx_Cap stroke_cap_get() const;

   /// @brief Sets the cap style to be used for stroking the path.
   /// The cap will be used for capping the end point of a 
   /// open subpath.
   ///
   /// @see Efl_Gfx_Cap
   /// @since 1.14
   ///
   /// @param c cap style to use , default is EFL_GFX_CAP_BUTT
   ///
   void stroke_cap_set(Efl_Gfx_Cap c_) const;

   /// @brief Gets the join style used for stroking path.
   /// @since 1.14
   ///
   /// @param j join style to use , default is
   /// EFL_GFX_JOIN_MITER
   ///
   Efl_Gfx_Join stroke_join_get() const;

   /// @brief Sets the join style to be used for stroking the path.
   /// The join style will be used for joining the two line segment
   /// while stroking teh path.
   ///
   /// @see Efl_Gfx_Join
   /// @since 1.14
   ///
   /// @param j join style to use , default is
   /// EFL_GFX_JOIN_MITER
   ///
   void stroke_join_set(Efl_Gfx_Join j_) const;

   /// @brief Gets the command and points list
   /// @since 1.14
   ///
   /// @param op command list
   /// @param points point list
   ///
   void path_get(const Efl_Gfx_Path_Command ** op_, const double ** points_) const;

   /// @brief Set the list of commands and points to be used to create the
   /// content of shape.
   ///
   /// @note see efl_gfx_path interface for how to create a command list.
   /// @see Efl_Gfx_Path_Command
   /// @since 1.14
   ///
   /// @param op command list
   /// @param points point list
   ///
   void path_set(const Efl_Gfx_Path_Command * op_, const double * points_) const;

   /// @param commands 
   /// @param points 
   ///
   void path_length_get(unsigned int* commands_, unsigned int* points_) const;

   /// @param x 
   /// @param y 
   ///
   void current_get(double* x_, double* y_) const;

   /// @param x 
   /// @param y 
   ///
   void current_ctrl_get(double* x_, double* y_) const;



   static Eo_Class const* _eo_class()
   {
      return(EFL_GFX_SHAPE_MIXIN);
   }

   /// @cond LOCAL
   struct address_of
      : ::eo_cxx::efl::gfx::shape::address_of<address_of>
      , ::efl::eo::detail::concrete_address_of
   {
      explicit address_of(::efl::gfx::shape* p)
         : ::efl::eo::detail::concrete_address_of(p)
      {}
   };
   address_of operator&() { return address_of(this); }

   struct address_const_of
      : ::eo_cxx::efl::gfx::shape::address_const_of<address_const_of>
      , ::efl::eo::detail::concrete_address_const_of
   {
      explicit address_const_of(::efl::gfx::shape const* p)
         : ::efl::eo::detail::concrete_address_const_of(p)
      {}
   };
   address_const_of operator&() const { return address_const_of(this); }

   /// @endcond

private:

   /// @internal
   static Eo* _ctors_call(::efl::eo::parent_type _p)
   {
      Eo* _ret_eo = eo_add_ref(EFL_GFX_SHAPE_MIXIN, _p._eo_raw);

      return _ret_eo;
   }

   /// @internal
   Eo* _concrete_eo_ptr() const { return _eo_ptr(); }
};

static_assert(sizeof(::efl::gfx::shape) == sizeof(Eo*), "");
static_assert(std::is_standard_layout<::efl::gfx::shape>::value, "");

} }


#include "efl_gfx_shape.eo.impl.hh"

#endif // EFL_GENERATED_EFL_GFX_SHAPE_HH

