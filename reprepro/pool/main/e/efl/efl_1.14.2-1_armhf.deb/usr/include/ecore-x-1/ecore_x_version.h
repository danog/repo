#ifndef _ECORE_X_VERSION_H_
#define _ECORE_X_VERSION_H_ 1

#ifndef HAVE_ECORE_X_XLIB
#define HAVE_ECORE_X_XLIB 1
#endif

#endif
