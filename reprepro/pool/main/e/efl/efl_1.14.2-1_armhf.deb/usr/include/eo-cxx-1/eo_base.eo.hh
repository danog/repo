#ifndef EFL_GENERATED_EO_BASE_HH
#define EFL_GENERATED_EO_BASE_HH

extern "C"
{
#include <Efl.h>
}
#include <Eo.hh>

#include <eo_cxx_interop.hh>

extern "C"
{
#include "eo_base.eo.h"
}

#include <eo_concrete.hh>
#include <string>

namespace eo {

struct base;

}

/// @cond EO_CXX_ABSTRACT
namespace eo_cxx {

namespace eo {

struct base
{
   /// @brief Remove an event callback forwarder for an event and an object.
   ///
   /// @param desc The description of the event to listen to
   /// @param new_obj The object to emit events from
   ///
   void event_callback_forwarder_del(const Eo_Event_Description * desc_, ::efl::eo::concrete new_obj_) const;

   /// @brief thaw events of object.
   /// Lets event callbacks be called for the object.
   ///
   void event_thaw() const;

   /// @brief freeze events of object.
   /// Prevents event callbacks from being called for the object.
   ///
   void event_freeze() const;

   /// @brief freeze events of object.
   /// Prevents event callbacks from being called for the object.
   ///
   static void event_global_freeze();

   /// @brief Del a callback array with a specific data associated to it for an event.
   ///
   /// @param array an #Eo_Callback_Array_Item of events to listen to
   /// @param user_data The data to compare
   ///
   void event_callback_array_del(const Eo_Callback_Array_Item * array_, const void * user_data_) const;

   /// @brief Delete the weak reference passed.
   ///
   /// @param wref 
   ///
   void wref_del(Eo ** wref_) const;

   /// @brief Call the object's destructor.
   /// Should not be used with #eo_do. Only use it with #eo_do_super.
   ///
   void destructor() const;

   /// @brief Called at the end of #eo_add. Should not be called, just overridden.
   ///
   /// @return The new object created, can be NULL if the finalize func decided to abort (though it should free the created object on it's own).
   ::efl::eo::concrete finalize() const;

   /// @brief Set generic data to object.
   ///
   /// @param key the key associated with the data
   /// @param data the data to set
   /// @param free_func the func to free data with (NULL means
   ///
   void key_data_set(::efl::eina::string_view key_, const void * data_, eo_key_data_free_func free_func_) const;

   /// @brief Get generic data from object.
   ///
   /// @param key the key associated with the data
   ///
   void * key_data_get(::efl::eina::string_view key_) const;

   /// @brief Del a callback with a specific data associated to it for an event.
   ///
   /// @param desc The description of the event to listen to
   /// @param func the callback to delete
   /// @param user_data The data to compare
   ///
   void event_callback_del(const Eo_Event_Description * desc_, Eo_Event_Cb func_, const void * user_data_) const;

   /// @brief thaw events of object.
   /// Lets event callbacks be called for the object.
   ///
   static void event_global_thaw();

   /// @brief Del generic data from object.
   ///
   /// @param key the key associated with the data
   ///
   void key_data_del(::efl::eina::string_view key_) const;

   /// @brief Add a callback array for an event with a specific priority.
   /// callbacks of the same priority are called in reverse order of creation.
   ///
   /// @param array an #Eo_Callback_Array_Item of events to listen to
   /// @param priority The priority of the callback
   /// @param data additional data to pass to the callback
   ///
   void event_callback_array_priority_add(const Eo_Callback_Array_Item * array_, Eo_Callback_Priority priority_, const void * data_) const;

   /// @brief Add a new weak reference to obj.
   /// This function registers the object handle pointed by wref to obj so when obj is deleted it'll be updated to NULL. This functions should be used when you want to keep track of an object in a safe way, but you don't want to prevent it from being freed.
   ///
   /// @param[out] wref 
   ///
   void wref_add(::efl::eo::concrete* wref_) const;

   /// @brief Get dbg information from the object.
   ///
   /// @param root_node node of the tree
   ///
   void dbg_info_get(Eo_Dbg_Info * root_node_) const;

   /// @brief Add an event callback forwarder for an event and an object.
   ///
   /// @param desc The description of the event to listen to
   /// @param new_obj The object to emit events from
   ///
   void event_callback_forwarder_add(const Eo_Event_Description * desc_, ::efl::eo::concrete new_obj_) const;

   /// @brief Call the callbacks for an event of an object.
   ///
   /// @param desc The description of the event to call
   /// @param event_info Extra event info to pass to the callbacks
   ///
   bool event_callback_call(const Eo_Event_Description * desc_, void * event_info_) const;

   /// @brief Add a callback for an event with a specific priority.
   /// callbacks of the same priority are called in reverse order of creation.
   ///
   /// @param desc The description of the event to listen to
   /// @param priority The priority of the callback
   /// @param cb the callback to call
   /// @param data additional data to pass to the callback
   ///
   void event_callback_priority_add(const Eo_Event_Description * desc_, Eo_Callback_Priority priority_, Eo_Event_Cb cb_, const void * data_) const;

   /// @brief Get an iterator on all childrens
   ///
   Eina_Iterator * children_iterator_new() const;

   /// @param comp_obj the object that will be used to composite the parent.
   ///
   /// @return EINA_TRUE if successfull. EINA_FALSE otherwise.
   bool composite_attach(::efl::eo::concrete comp_obj_) const;

   /// @param comp_obj the object that will be removed from the parent.
   ///
   /// @return EINA_TRUE if successfull. EINA_FALSE otherwise.
   bool composite_detach(::efl::eo::concrete comp_obj_) const;

   /// @return EINA_TRUE if it is. EINA_FALSE otherwise.
   bool composite_part_is() const;

   /// @brief Get the parent of an object
   ///
   /// @param parent the new parent
   ///
   ::efl::eo::concrete parent_get() const;

   /// @brief Set the parent of an object
   /// Parents keep references to their children so in order to delete objects that have parents you need to set parent to NULL or use eo_del() that does that for you (and also unrefs the object).
   ///
   /// @param parent the new parent
   ///
   void parent_set(::efl::eo::concrete parent_) const;

   /// @brief return freeze events of object.
   /// Return event freeze count.
   ///
   /// @param fcount The event freeze count of the object
   ///
   int event_global_freeze_count_get() const;

   /// @brief return freeze events of object.
   /// Return event freeze count.
   ///
   /// @param fcount The event freeze count of the object
   ///
   int event_freeze_count_get() const;

   /// @param finalized 
   ///
   bool finalized_get() const;

   /// A callback was added.
   template <typename F>
   ::efl::eo::signal_connection
   callback_callback_add_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EO_BASE_EVENT_CALLBACK_ADD, priority_,
            &::efl::eo::_detail::event_callback<::eo::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::eo::base, function_type>,
         EO_BASE_EVENT_CALLBACK_ADD );
   }

   /// A callback was added.
   template <typename T>
   void
   callback_callback_add_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EO_BASE_EVENT_CALLBACK_ADD, info));
   }

   /// A callback was deleted.
   template <typename F>
   ::efl::eo::signal_connection
   callback_callback_del_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EO_BASE_EVENT_CALLBACK_DEL, priority_,
            &::efl::eo::_detail::event_callback<::eo::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::eo::base, function_type>,
         EO_BASE_EVENT_CALLBACK_DEL );
   }

   /// A callback was deleted.
   template <typename T>
   void
   callback_callback_del_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EO_BASE_EVENT_CALLBACK_DEL, info));
   }

   /// Obj is being deleted.
   template <typename F>
   ::efl::eo::signal_connection
   callback_del_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EO_BASE_EVENT_DEL, priority_,
            &::efl::eo::_detail::event_callback<::eo::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::eo::base, function_type>,
         EO_BASE_EVENT_DEL );
   }

   /// Obj is being deleted.
   template <typename T>
   void
   callback_del_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EO_BASE_EVENT_DEL, info));
   }



   static Eo_Class const* _eo_class()
   {
      return(EO_BASE_CLASS);
   }

   operator ::eo::base() const;
   operator ::eo::base&();
   operator ::eo::base const&() const;

   /// @cond LOCAL
   template <typename D>
   struct address_of
   {
      operator ::eo::base*() const { return static_cast<::eo::base*>(static_cast<D const*>(this)->p); }
      operator ::eo::base const*() const { return static_cast<::eo::base const*>(static_cast<D const*>(this)->p); }
   };

   template <typename D>
   struct address_const_of
   {
      operator ::eo::base const*() const { return static_cast<::eo::base const*>(static_cast<D const*>(this)->p); }
   };
   /// @endcond

private:

   /// @internal
   Eo* _concrete_eo_ptr() const
   {
      return static_cast<::efl::eo::concrete const*>(static_cast<void const*>(this))->_eo_ptr();
   }

};

}

}
/// @endcond

namespace eo {

/// @brief Class base
struct base
      : ::efl::eo::concrete
{
   //@{
   /**
      @brief Constructs a new eo::base object.

      Constructs a new eo::base object. If you want this object to be a child
      of another Eo object, use an @ref efl::eo::parent expression, like the example.

      Example:
      @code
      eo::base my_base(efl::eo::parent = parent_object);
      @endcode

      @see base(Eo* eo)
   */
   explicit base(::efl::eo::parent_type _p)
      : base(_ctors_call(_p))
   {}

   explicit base()
      : base(_ctors_call(::efl::eo::parent = nullptr))
   {}
   //@}

   /// @brief Eo Constructor.
   ///
   /// Constructs the object from an Eo* pointer stealing its ownership.
   ///
   /// @param eo The Eo object pointer.
   ///
   explicit base(Eo* eo)
      : ::efl::eo::concrete(eo)
   {}

   /// @brief nullptr_t Constructor.
   ///
   /// Constructs an empty (null) object.
   ///
   explicit base(std::nullptr_t)
      : ::efl::eo::concrete(nullptr)
   {}

   /// @brief Copy Constructor.
   ///
   base(base const& other)
      : base(eo_ref(other._eo_ptr()))
   {}

   ~base() {}

   /// @brief Remove an event callback forwarder for an event and an object.
   ///
   /// @param desc The description of the event to listen to
   /// @param new_obj The object to emit events from
   ///
   void event_callback_forwarder_del(const Eo_Event_Description * desc_, ::efl::eo::concrete new_obj_) const;

   /// @brief thaw events of object.
   /// Lets event callbacks be called for the object.
   ///
   void event_thaw() const;

   /// @brief freeze events of object.
   /// Prevents event callbacks from being called for the object.
   ///
   void event_freeze() const;

   /// @brief freeze events of object.
   /// Prevents event callbacks from being called for the object.
   ///
   static void event_global_freeze();

   /// @brief Del a callback array with a specific data associated to it for an event.
   ///
   /// @param array an #Eo_Callback_Array_Item of events to listen to
   /// @param user_data The data to compare
   ///
   void event_callback_array_del(const Eo_Callback_Array_Item * array_, const void * user_data_) const;

   /// @brief Delete the weak reference passed.
   ///
   /// @param wref 
   ///
   void wref_del(Eo ** wref_) const;

   /// @brief Call the object's destructor.
   /// Should not be used with #eo_do. Only use it with #eo_do_super.
   ///
   void destructor() const;

   /// @brief Called at the end of #eo_add. Should not be called, just overridden.
   ///
   /// @return The new object created, can be NULL if the finalize func decided to abort (though it should free the created object on it's own).
   ::efl::eo::concrete finalize() const;

   /// @brief Set generic data to object.
   ///
   /// @param key the key associated with the data
   /// @param data the data to set
   /// @param free_func the func to free data with (NULL means
   ///
   void key_data_set(::efl::eina::string_view key_, const void * data_, eo_key_data_free_func free_func_) const;

   /// @brief Get generic data from object.
   ///
   /// @param key the key associated with the data
   ///
   void * key_data_get(::efl::eina::string_view key_) const;

   /// @brief Del a callback with a specific data associated to it for an event.
   ///
   /// @param desc The description of the event to listen to
   /// @param func the callback to delete
   /// @param user_data The data to compare
   ///
   void event_callback_del(const Eo_Event_Description * desc_, Eo_Event_Cb func_, const void * user_data_) const;

   /// @brief thaw events of object.
   /// Lets event callbacks be called for the object.
   ///
   static void event_global_thaw();

   /// @brief Del generic data from object.
   ///
   /// @param key the key associated with the data
   ///
   void key_data_del(::efl::eina::string_view key_) const;

   /// @brief Add a callback array for an event with a specific priority.
   /// callbacks of the same priority are called in reverse order of creation.
   ///
   /// @param array an #Eo_Callback_Array_Item of events to listen to
   /// @param priority The priority of the callback
   /// @param data additional data to pass to the callback
   ///
   void event_callback_array_priority_add(const Eo_Callback_Array_Item * array_, Eo_Callback_Priority priority_, const void * data_) const;

   /// @brief Add a new weak reference to obj.
   /// This function registers the object handle pointed by wref to obj so when obj is deleted it'll be updated to NULL. This functions should be used when you want to keep track of an object in a safe way, but you don't want to prevent it from being freed.
   ///
   /// @param[out] wref 
   ///
   void wref_add(::efl::eo::concrete* wref_) const;

   /// @brief Get dbg information from the object.
   ///
   /// @param root_node node of the tree
   ///
   void dbg_info_get(Eo_Dbg_Info * root_node_) const;

   /// @brief Add an event callback forwarder for an event and an object.
   ///
   /// @param desc The description of the event to listen to
   /// @param new_obj The object to emit events from
   ///
   void event_callback_forwarder_add(const Eo_Event_Description * desc_, ::efl::eo::concrete new_obj_) const;

   /// @brief Call the callbacks for an event of an object.
   ///
   /// @param desc The description of the event to call
   /// @param event_info Extra event info to pass to the callbacks
   ///
   bool event_callback_call(const Eo_Event_Description * desc_, void * event_info_) const;

   /// @brief Add a callback for an event with a specific priority.
   /// callbacks of the same priority are called in reverse order of creation.
   ///
   /// @param desc The description of the event to listen to
   /// @param priority The priority of the callback
   /// @param cb the callback to call
   /// @param data additional data to pass to the callback
   ///
   void event_callback_priority_add(const Eo_Event_Description * desc_, Eo_Callback_Priority priority_, Eo_Event_Cb cb_, const void * data_) const;

   /// @brief Get an iterator on all childrens
   ///
   Eina_Iterator * children_iterator_new() const;

   /// @param comp_obj the object that will be used to composite the parent.
   ///
   /// @return EINA_TRUE if successfull. EINA_FALSE otherwise.
   bool composite_attach(::efl::eo::concrete comp_obj_) const;

   /// @param comp_obj the object that will be removed from the parent.
   ///
   /// @return EINA_TRUE if successfull. EINA_FALSE otherwise.
   bool composite_detach(::efl::eo::concrete comp_obj_) const;

   /// @return EINA_TRUE if it is. EINA_FALSE otherwise.
   bool composite_part_is() const;

   /// @brief Get the parent of an object
   ///
   /// @param parent the new parent
   ///
   ::efl::eo::concrete parent_get() const;

   /// @brief Set the parent of an object
   /// Parents keep references to their children so in order to delete objects that have parents you need to set parent to NULL or use eo_del() that does that for you (and also unrefs the object).
   ///
   /// @param parent the new parent
   ///
   void parent_set(::efl::eo::concrete parent_) const;

   /// @brief return freeze events of object.
   /// Return event freeze count.
   ///
   /// @param fcount The event freeze count of the object
   ///
   int event_global_freeze_count_get() const;

   /// @brief return freeze events of object.
   /// Return event freeze count.
   ///
   /// @param fcount The event freeze count of the object
   ///
   int event_freeze_count_get() const;

   /// @param finalized 
   ///
   bool finalized_get() const;

   /// A callback was added.
   template <typename F>
   ::efl::eo::signal_connection
   callback_callback_add_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EO_BASE_EVENT_CALLBACK_ADD, priority_,
            &::efl::eo::_detail::event_callback<::eo::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::eo::base, function_type>,
         EO_BASE_EVENT_CALLBACK_ADD );
   }

   /// A callback was added.
   template <typename T>
   void
   callback_callback_add_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EO_BASE_EVENT_CALLBACK_ADD, info));
   }

   /// A callback was deleted.
   template <typename F>
   ::efl::eo::signal_connection
   callback_callback_del_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EO_BASE_EVENT_CALLBACK_DEL, priority_,
            &::efl::eo::_detail::event_callback<::eo::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::eo::base, function_type>,
         EO_BASE_EVENT_CALLBACK_DEL );
   }

   /// A callback was deleted.
   template <typename T>
   void
   callback_callback_del_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EO_BASE_EVENT_CALLBACK_DEL, info));
   }

   /// Obj is being deleted.
   template <typename F>
   ::efl::eo::signal_connection
   callback_del_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EO_BASE_EVENT_DEL, priority_,
            &::efl::eo::_detail::event_callback<::eo::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::eo::base, function_type>,
         EO_BASE_EVENT_DEL );
   }

   /// Obj is being deleted.
   template <typename T>
   void
   callback_del_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EO_BASE_EVENT_DEL, info));
   }



   static Eo_Class const* _eo_class()
   {
      return(EO_BASE_CLASS);
   }

   /// @cond LOCAL
   struct address_of
      : ::eo_cxx::eo::base::address_of<address_of>
      , ::efl::eo::detail::concrete_address_of
   {
      explicit address_of(::eo::base* p)
         : ::efl::eo::detail::concrete_address_of(p)
      {}
   };
   address_of operator&() { return address_of(this); }

   struct address_const_of
      : ::eo_cxx::eo::base::address_const_of<address_const_of>
      , ::efl::eo::detail::concrete_address_const_of
   {
      explicit address_const_of(::eo::base const* p)
         : ::efl::eo::detail::concrete_address_const_of(p)
      {}
   };
   address_const_of operator&() const { return address_const_of(this); }

   /// @endcond

private:

   /// @internal
   static Eo* _ctors_call(::efl::eo::parent_type _p)
   {
      Eo* _ret_eo = eo_add_ref(EO_BASE_CLASS, _p._eo_raw);

      return _ret_eo;
   }

   /// @internal
   Eo* _concrete_eo_ptr() const { return _eo_ptr(); }
};

static_assert(sizeof(::eo::base) == sizeof(Eo*), "");
static_assert(std::is_standard_layout<::eo::base>::value, "");

}


#include "eo_base.eo.impl.hh"

#endif // EFL_GENERATED_EO_BASE_HH

