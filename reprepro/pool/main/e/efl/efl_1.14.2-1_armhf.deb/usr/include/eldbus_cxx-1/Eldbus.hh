#ifndef EFL_ELDBUS_HH_
#define EFL_ELDBUS_HH_

#include <Eina.hh>
#include <Eldbus.h>

#include <eldbus_basic.hh>
#include <eldbus_proxy_call.hh>
#include <eldbus_message.hh>
#include <eldbus_service.hh>
#include <eina_integer_sequence.hh>

#endif
