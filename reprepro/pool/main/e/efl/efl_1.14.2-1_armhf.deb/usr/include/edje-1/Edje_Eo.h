#include <Efl.h>

#include "edje_object.eo.h"
#include "edje_edit.eo.h"
