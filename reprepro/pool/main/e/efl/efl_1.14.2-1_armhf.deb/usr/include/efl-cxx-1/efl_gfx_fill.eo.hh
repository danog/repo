#ifndef EFL_GENERATED_EFL_GFX_FILL_HH
#define EFL_GENERATED_EFL_GFX_FILL_HH

extern "C"
{
#include <Efl.h>
}
#include <Eo.hh>

#include <eo_cxx_interop.hh>

extern "C"
{
#include "efl_gfx_fill.eo.h"
}


namespace efl { namespace gfx {

struct fill;

} }

/// @cond EO_CXX_ABSTRACT
namespace eo_cxx {

namespace efl { namespace gfx {

struct fill
{
   /// @brief Retrieves the spread (tiling mode) for the given image object's
   /// fill.
   ///
   /// @return  The current spread mode of the image object.
   ///
   /// @param spread One of EVAS_TEXTURE_REFLECT, EVAS_TEXTURE_REPEAT,
   ///
   Efl_Gfx_Fill_Spread fill_spread_get() const;

   /// @brief Sets the tiling mode for the given evas image object's fill.
   /// EFL_GFX_FILL_RESTRICT, or EFL_GFX_FILL_PAD.
   ///
   /// @param spread One of EVAS_TEXTURE_REFLECT, EVAS_TEXTURE_REPEAT,
   ///
   void fill_spread_set(Efl_Gfx_Fill_Spread spread_) const;

   /// @brief Retrieve how an image object is to fill its drawing rectangle,
   /// given the (real) image bound to it.
   ///
   /// @note Use @c NULL pointers on the fill components you're not
   /// interested in: they'll be ignored by the function.
   ///
   /// See @ref evas_object_image_fill_set() for more details.
   ///
   /// @param x The x coordinate (from the top left corner of the bound
   /// image) to start drawing from.
   /// @param y The y coordinate (from the top left corner of the bound
   /// image) to start drawing from.
   /// @param w The width the bound image will be displayed at.
   /// @param h The height the bound image will be displayed at.
   ///
   void fill_get(int* x_, int* y_, int* w_, int* h_) const;

   /// @brief Set how to fill an image object's drawing rectangle given the
   /// (real) image bound to it.
   ///
   /// Note that if @p w or @p h are smaller than the dimensions of
   /// @p obj, the displayed image will be @b tiled around the object's
   /// area. To have only one copy of the bound image drawn, @p x and @p y
   /// must be 0 and @p w and @p h need to be the exact width and height
   /// of the image object itself, respectively.
   ///
   /// See the following image to better understand the effects of this
   /// call. On this diagram, both image object and original image source
   /// have @c a x @c a dimensions and the image itself is a circle, with
   /// empty space around it:
   ///
   /// @image html image-fill.png
   /// @image rtf image-fill.png
   /// @image latex image-fill.eps
   ///
   /// @warning The default values for the fill parameters are @p x = 0,
   /// @p y = 0, @p w = 0 and @p h = 0. Thus, if you're not using the
   /// evas_object_image_filled_add() helper and want your image
   /// displayed, you'll have to set valid values with this function on
   /// your object.
   ///
   /// @note evas_object_image_filled_set() is a helper function which
   /// will @b override the values set here automatically, for you, in a
   /// given way.
   ///
   /// @param x The x coordinate (from the top left corner of the bound
   /// image) to start drawing from.
   /// @param y The y coordinate (from the top left corner of the bound
   /// image) to start drawing from.
   /// @param w The width the bound image will be displayed at.
   /// @param h The height the bound image will be displayed at.
   ///
   void fill_set(int x_, int y_, int w_, int h_) const;



   static Eo_Class const* _eo_class()
   {
      return(EFL_GFX_FILL_INTERFACE);
   }

   operator ::efl::gfx::fill() const;
   operator ::efl::gfx::fill&();
   operator ::efl::gfx::fill const&() const;

   /// @cond LOCAL
   template <typename D>
   struct address_of
   {
      operator ::efl::gfx::fill*() const { return static_cast<::efl::gfx::fill*>(static_cast<D const*>(this)->p); }
      operator ::efl::gfx::fill const*() const { return static_cast<::efl::gfx::fill const*>(static_cast<D const*>(this)->p); }
   };

   template <typename D>
   struct address_const_of
   {
      operator ::efl::gfx::fill const*() const { return static_cast<::efl::gfx::fill const*>(static_cast<D const*>(this)->p); }
   };
   /// @endcond

private:

   /// @internal
   Eo* _concrete_eo_ptr() const
   {
      return static_cast<::efl::eo::concrete const*>(static_cast<void const*>(this))->_eo_ptr();
   }

};

} }

}
/// @endcond

namespace efl { namespace gfx {

/// @brief Class fill
struct fill
      : ::efl::eo::concrete
{
   //@{
   /**
      @brief Constructs a new efl::gfx::fill object.

      Constructs a new efl::gfx::fill object. If you want this object to be a child
      of another Eo object, use an @ref efl::eo::parent expression, like the example.

      Example:
      @code
      efl::gfx::fill my_fill(efl::eo::parent = parent_object);
      @endcode

      @see fill(Eo* eo)
   */
   explicit fill(::efl::eo::parent_type _p)
      : fill(_ctors_call(_p))
   {}

   explicit fill()
      : fill(_ctors_call(::efl::eo::parent = nullptr))
   {}
   //@}

   /// @brief Eo Constructor.
   ///
   /// Constructs the object from an Eo* pointer stealing its ownership.
   ///
   /// @param eo The Eo object pointer.
   ///
   explicit fill(Eo* eo)
      : ::efl::eo::concrete(eo)
   {}

   /// @brief nullptr_t Constructor.
   ///
   /// Constructs an empty (null) object.
   ///
   explicit fill(std::nullptr_t)
      : ::efl::eo::concrete(nullptr)
   {}

   /// @brief Copy Constructor.
   ///
   fill(fill const& other)
      : fill(eo_ref(other._eo_ptr()))
   {}

   ~fill() {}

   /// @brief Retrieves the spread (tiling mode) for the given image object's
   /// fill.
   ///
   /// @return  The current spread mode of the image object.
   ///
   /// @param spread One of EVAS_TEXTURE_REFLECT, EVAS_TEXTURE_REPEAT,
   ///
   Efl_Gfx_Fill_Spread fill_spread_get() const;

   /// @brief Sets the tiling mode for the given evas image object's fill.
   /// EFL_GFX_FILL_RESTRICT, or EFL_GFX_FILL_PAD.
   ///
   /// @param spread One of EVAS_TEXTURE_REFLECT, EVAS_TEXTURE_REPEAT,
   ///
   void fill_spread_set(Efl_Gfx_Fill_Spread spread_) const;

   /// @brief Retrieve how an image object is to fill its drawing rectangle,
   /// given the (real) image bound to it.
   ///
   /// @note Use @c NULL pointers on the fill components you're not
   /// interested in: they'll be ignored by the function.
   ///
   /// See @ref evas_object_image_fill_set() for more details.
   ///
   /// @param x The x coordinate (from the top left corner of the bound
   /// image) to start drawing from.
   /// @param y The y coordinate (from the top left corner of the bound
   /// image) to start drawing from.
   /// @param w The width the bound image will be displayed at.
   /// @param h The height the bound image will be displayed at.
   ///
   void fill_get(int* x_, int* y_, int* w_, int* h_) const;

   /// @brief Set how to fill an image object's drawing rectangle given the
   /// (real) image bound to it.
   ///
   /// Note that if @p w or @p h are smaller than the dimensions of
   /// @p obj, the displayed image will be @b tiled around the object's
   /// area. To have only one copy of the bound image drawn, @p x and @p y
   /// must be 0 and @p w and @p h need to be the exact width and height
   /// of the image object itself, respectively.
   ///
   /// See the following image to better understand the effects of this
   /// call. On this diagram, both image object and original image source
   /// have @c a x @c a dimensions and the image itself is a circle, with
   /// empty space around it:
   ///
   /// @image html image-fill.png
   /// @image rtf image-fill.png
   /// @image latex image-fill.eps
   ///
   /// @warning The default values for the fill parameters are @p x = 0,
   /// @p y = 0, @p w = 0 and @p h = 0. Thus, if you're not using the
   /// evas_object_image_filled_add() helper and want your image
   /// displayed, you'll have to set valid values with this function on
   /// your object.
   ///
   /// @note evas_object_image_filled_set() is a helper function which
   /// will @b override the values set here automatically, for you, in a
   /// given way.
   ///
   /// @param x The x coordinate (from the top left corner of the bound
   /// image) to start drawing from.
   /// @param y The y coordinate (from the top left corner of the bound
   /// image) to start drawing from.
   /// @param w The width the bound image will be displayed at.
   /// @param h The height the bound image will be displayed at.
   ///
   void fill_set(int x_, int y_, int w_, int h_) const;



   static Eo_Class const* _eo_class()
   {
      return(EFL_GFX_FILL_INTERFACE);
   }

   /// @cond LOCAL
   struct address_of
      : ::eo_cxx::efl::gfx::fill::address_of<address_of>
      , ::efl::eo::detail::concrete_address_of
   {
      explicit address_of(::efl::gfx::fill* p)
         : ::efl::eo::detail::concrete_address_of(p)
      {}
   };
   address_of operator&() { return address_of(this); }

   struct address_const_of
      : ::eo_cxx::efl::gfx::fill::address_const_of<address_const_of>
      , ::efl::eo::detail::concrete_address_const_of
   {
      explicit address_const_of(::efl::gfx::fill const* p)
         : ::efl::eo::detail::concrete_address_const_of(p)
      {}
   };
   address_const_of operator&() const { return address_const_of(this); }

   /// @endcond

private:

   /// @internal
   static Eo* _ctors_call(::efl::eo::parent_type _p)
   {
      Eo* _ret_eo = eo_add_ref(EFL_GFX_FILL_INTERFACE, _p._eo_raw);

      return _ret_eo;
   }

   /// @internal
   Eo* _concrete_eo_ptr() const { return _eo_ptr(); }
};

static_assert(sizeof(::efl::gfx::fill) == sizeof(Eo*), "");
static_assert(std::is_standard_layout<::efl::gfx::fill>::value, "");

} }


#include "efl_gfx_fill.eo.impl.hh"

#endif // EFL_GENERATED_EFL_GFX_FILL_HH

