/// @cond EO_CXX_EO_IMPL

inline bool edje::object::part_table_clear(::efl::eina::string_view part_, bool clear_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_clear(::efl::eolian::to_c(part_), ::efl::eolian::to_c(clear_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline Edje_External_Param_Type edje::object::part_external_param_type_get(::efl::eina::string_view part_, const char* param_) const
{
   Edje_External_Param_Type _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_param_type_get(::efl::eolian::to_c(part_), param_));
   return _tmp_ret;
}

inline void edje::object::part_text_select_allow_set(::efl::eina::string_view part_, bool allow_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_allow_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(allow_)));
}

inline ::efl::eina::string_view edje::object::part_state_get(::efl::eina::string_view part_, double* val_ret_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_state_get(::efl::eolian::to_c(part_), val_ret_));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline void * edje::object::text_markup_filter_callback_del_full(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_markup_filter_callback_del_full(::efl::eolian::to_c(part_), func_, data_));
   return _tmp_ret;
}

inline bool edje::object::part_drag_step_set(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_step_set(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_drag_step_get(::efl::eina::string_view part_, double* dx_, double* dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_step_get(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void * edje::object::part_text_imf_context_get(::efl::eina::string_view part_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_imf_context_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline void edje::object::part_text_select_begin(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_begin(::efl::eolian::to_c(part_)));
}

inline ::efl::eina::string_view edje::object::part_text_style_user_peek(::efl::eina::string_view part_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_style_user_peek(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

template <typename F_func_>
inline void * edje::object::signal_callback_del(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_) const
{
   void * _tmp_ret;
   typedef typename std::remove_reference<F_func_>::type _no_ref_F_func_;
   _no_ref_F_func_* _tmp_func_ = new _no_ref_F_func_(std::forward< F_func_ >(func_));
   eo_do(_concrete_eo_ptr(), eo_event_callback_add(EO_EV_DEL, &::efl::eolian::free_callback_calback<_no_ref_F_func_>, _tmp_func_));

   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_signal_callback_del(::efl::eolian::to_c(emission_), ::efl::eolian::to_c(source_), ::efl::eolian::get_callback<Edje_Signal_Cb, _no_ref_F_func_ >(), _tmp_func_));
   return _tmp_ret;
}

inline bool edje::object::part_text_cursor_next(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_next(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_style_user_push(::efl::eina::string_view part_, ::efl::eina::string_view style_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_style_user_push(::efl::eolian::to_c(part_), ::efl::eolian::to_c(style_)));
}

inline void edje::object::part_text_append(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_append(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
}

inline bool edje::object::part_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_geometry_get(::efl::eolian::to_c(part_), x_, y_, w_, h_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_input_panel_hide(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_hide(::efl::eolian::to_c(part_)));
}

inline bool edje::object::part_text_item_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view item_, Evas_Coord* cx_, Evas_Coord* cy_, Evas_Coord* cw_, Evas_Coord* ch_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_item_geometry_get(::efl::eolian::to_c(part_), ::efl::eolian::to_c(item_), cx_, cy_, cw_, ch_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_table_unpack(::efl::eina::string_view part_, ::evas::object child_obj_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_unpack(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_obj_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_select_abort(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_abort(::efl::eolian::to_c(part_)));
}

inline void * edje::object::text_insert_filter_callback_del_full(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_insert_filter_callback_del_full(::efl::eolian::to_c(part_), func_, data_));
   return _tmp_ret;
}

inline void edje::object::part_text_style_user_pop(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_style_user_pop(::efl::eolian::to_c(part_)));
}

inline void edje::object::part_text_input_panel_imdata_set(::efl::eina::string_view part_, const void * data_, int len_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_imdata_set(::efl::eolian::to_c(part_), data_, len_));
}

inline void edje::object::part_text_input_panel_imdata_get(::efl::eina::string_view part_, void * data_, int * len_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_imdata_get(::efl::eolian::to_c(part_), data_, len_));
}

inline void edje::object::part_text_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_insert(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
}

inline ::evas::object edje::object::part_box_remove_at(::efl::eina::string_view part_, unsigned int pos_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_remove_at(::efl::eolian::to_c(part_), pos_));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_cursor_copy(::efl::eina::string_view part_, Edje_Cursor src_, Edje_Cursor dst_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_copy(::efl::eolian::to_c(part_), src_, dst_));
}

inline bool edje::object::parts_extends_calc(Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_parts_extends_calc(x_, y_, w_, h_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_drag_value_set(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_value_set(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_drag_value_get(::efl::eina::string_view part_, double* dx_, double* dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_value_get(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::calc_force() const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_calc_force());
}

inline void edje::object::part_text_cursor_pos_set(::efl::eina::string_view part_, Edje_Cursor cur_, int pos_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_pos_set(::efl::eolian::to_c(part_), cur_, pos_));
}

inline int edje::object::part_text_cursor_pos_get(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_pos_get(::efl::eolian::to_c(part_), cur_));
   return _tmp_ret;
}

inline int edje::object::freeze() const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_freeze());
   return _tmp_ret;
}

inline char * edje::object::part_text_cursor_content_get(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_content_get(::efl::eolian::to_c(part_), cur_));
   return _tmp_ret;
}

inline void edje::object::part_text_input_panel_layout_set(::efl::eina::string_view part_, Edje_Input_Panel_Layout layout_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_layout_set(::efl::eolian::to_c(part_), layout_));
}

inline Edje_Input_Panel_Layout edje::object::part_text_input_panel_layout_get(::efl::eina::string_view part_) const
{
   Edje_Input_Panel_Layout _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_layout_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline bool edje::object::part_table_pack(::efl::eina::string_view part_, ::evas::object child_obj_, unsigned short col_, unsigned short row_, unsigned short colspan_, unsigned short rowspan_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_pack(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_obj_), col_, row_, colspan_, rowspan_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_input_panel_language_set(::efl::eina::string_view part_, Edje_Input_Panel_Lang lang_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_language_set(::efl::eolian::to_c(part_), lang_));
}

inline Edje_Input_Panel_Lang edje::object::part_text_input_panel_language_get(::efl::eina::string_view part_) const
{
   Edje_Input_Panel_Lang _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_language_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline bool edje::object::part_table_col_row_size_get(::efl::eina::string_view part_, int* cols_, int* rows_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_col_row_size_get(::efl::eolian::to_c(part_), cols_, rows_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::evas::object edje::object::part_external_object_get(::efl::eina::string_view part_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_object_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::evas::object edje::object::part_external_content_get(::efl::eina::string_view part_, const char* content_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_content_get(::efl::eolian::to_c(part_), content_));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::preload(bool cancel_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_preload(::efl::eolian::to_c(cancel_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_input_panel_enabled_set(::efl::eina::string_view part_, bool enabled_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_enabled_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(enabled_)));
}

inline bool edje::object::part_text_input_panel_enabled_get(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_enabled_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_select_extend(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_extend(::efl::eolian::to_c(part_)));
}

inline bool edje::object::part_box_insert_at(::efl::eina::string_view part_, ::evas::object child_, unsigned int pos_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_insert_at(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_), pos_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::crange_list< const Evas_Textblock_Rectangle * > edje::object::part_text_anchor_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view anchor_) const
{
   const Eina_List * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_anchor_geometry_get(::efl::eolian::to_c(part_), ::efl::eolian::to_c(anchor_)));
   return ::efl::eolian::to_cxx<::efl::eina::crange_list< const Evas_Textblock_Rectangle * >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
}

inline bool edje::object::part_text_cursor_down(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_down(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_drag_page_set(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_page_set(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_drag_page_get(::efl::eina::string_view part_, double* dx_, double* dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_page_get(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_box_prepend(::efl::eina::string_view part_, ::evas::object child_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_prepend(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::signal_emit(::efl::eina::string_view emission_, ::efl::eina::string_view source_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_signal_emit(::efl::eolian::to_c(emission_), ::efl::eolian::to_c(source_)));
}

inline void edje::object::part_text_input_panel_layout_variation_set(::efl::eina::string_view part_, int variation_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_layout_variation_set(::efl::eolian::to_c(part_), variation_));
}

inline int edje::object::part_text_input_panel_layout_variation_get(::efl::eina::string_view part_) const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_layout_variation_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline void edje::object::message_send(Edje_Message_Type type_, int id_, void * msg_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_message_send(type_, id_, msg_));
}

inline void edje::object::part_text_select_none(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_none(::efl::eolian::to_c(part_)));
}

inline const Evas_Object * edje::object::part_object_get(::efl::eina::string_view part_) const
{
   const Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_object_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline bool edje::object::part_drag_size_set(::efl::eina::string_view part_, double dw_, double dh_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_size_set(::efl::eolian::to_c(part_), dw_, dh_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_drag_size_get(::efl::eina::string_view part_, double* dw_, double* dh_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_size_get(::efl::eolian::to_c(part_), dw_, dh_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void * edje::object::text_insert_filter_callback_del(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_insert_filter_callback_del(::efl::eolian::to_c(part_), func_));
   return _tmp_ret;
}

inline Edje_Drag_Dir edje::object::part_drag_dir_get(::efl::eina::string_view part_) const
{
   Edje_Drag_Dir _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_dir_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline bool edje::object::part_text_unescaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_to_escape_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_unescaped_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_to_escape_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline char * edje::object::part_text_unescaped_get(::efl::eina::string_view part_) const
{
   char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_unescaped_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

template <typename F_func_>
inline void edje::object::signal_callback_add(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_) const
{
   typedef typename std::remove_reference<F_func_>::type _no_ref_F_func_;
   _no_ref_F_func_* _tmp_func_ = new _no_ref_F_func_(std::forward< F_func_ >(func_));
   eo_do(_concrete_eo_ptr(), eo_event_callback_add(EO_EV_DEL, &::efl::eolian::free_callback_calback<_no_ref_F_func_>, _tmp_func_));

   eo_do(_concrete_eo_ptr(), ::edje_obj_signal_callback_add(::efl::eolian::to_c(emission_), ::efl::eolian::to_c(source_), ::efl::eolian::get_callback<Edje_Signal_Cb, _no_ref_F_func_ >(), _tmp_func_));
}

inline void edje::object::part_text_select_all(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_all(::efl::eolian::to_c(part_)));
}

inline void edje::object::part_text_input_panel_return_key_disabled_set(::efl::eina::string_view part_, bool disabled_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_return_key_disabled_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(disabled_)));
}

inline bool edje::object::part_text_input_panel_return_key_disabled_get(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_return_key_disabled_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_autocapital_type_set(::efl::eina::string_view part_, Edje_Text_Autocapital_Type autocapital_type_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_autocapital_type_set(::efl::eolian::to_c(part_), autocapital_type_));
}

inline Edje_Text_Autocapital_Type edje::object::part_text_autocapital_type_get(::efl::eina::string_view part_) const
{
   Edje_Text_Autocapital_Type _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_autocapital_type_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline void edje::object::part_unswallow(::evas::object obj_swallow_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_unswallow(::efl::eolian::to_c(obj_swallow_)));
}

inline void edje::object::part_text_prediction_allow_set(::efl::eina::string_view part_, bool prediction_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_prediction_allow_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(prediction_)));
}

inline bool edje::object::part_text_prediction_allow_get(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_prediction_allow_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::string_view edje::object::data_get(::efl::eina::string_view key_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_data_get(::efl::eolian::to_c(key_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::text_markup_filter_callback_add(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_text_markup_filter_callback_add(::efl::eolian::to_c(part_), func_, data_));
}

inline void edje::object::message_signal_process() const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_message_signal_process());
}

inline ::evas::object edje::object::part_box_remove(::efl::eina::string_view part_, ::evas::object child_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_remove(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_)));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline int edje::object::thaw() const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_thaw());
   return _tmp_ret;
}

inline ::evas::object edje::object::part_swallow_get(::efl::eina::string_view part_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_swallow_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_imf_context_reset(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_imf_context_reset(::efl::eolian::to_c(part_)));
}

inline void edje::object::part_text_input_panel_return_key_type_set(::efl::eina::string_view part_, Edje_Input_Panel_Return_Key_Type return_key_type_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_return_key_type_set(::efl::eolian::to_c(part_), return_key_type_));
}

inline Edje_Input_Panel_Return_Key_Type edje::object::part_text_input_panel_return_key_type_get(::efl::eina::string_view part_) const
{
   Edje_Input_Panel_Return_Key_Type _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_return_key_type_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline ::evas::object edje::object::part_table_child_get(::efl::eina::string_view part_, unsigned int col_, unsigned int row_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_child_get(::efl::eolian::to_c(part_), col_, row_));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_box_insert_before(::efl::eina::string_view part_, ::evas::object child_, const Evas_Object * reference_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_insert_before(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_), reference_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_external_param_set(::efl::eina::string_view part_, const Edje_External_Param * param_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_param_set(::efl::eolian::to_c(part_), param_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_external_param_get(::efl::eina::string_view part_, Edje_External_Param* param_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_param_get(::efl::eolian::to_c(part_), param_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::size_min_calc(Evas_Coord* minw_, Evas_Coord* minh_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_size_min_calc(minw_, minh_));
}

inline bool edje::object::part_box_append(::efl::eina::string_view part_, ::evas::object child_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_append(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::size_min_restricted_calc(Evas_Coord* minw_, Evas_Coord* minh_, Evas_Coord restrictedw_, Evas_Coord restrictedh_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_size_min_restricted_calc(minw_, minh_, restrictedw_, restrictedh_));
}

inline bool edje::object::part_box_remove_all(::efl::eina::string_view part_, bool clear_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_remove_all(::efl::eolian::to_c(part_), ::efl::eolian::to_c(clear_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_drag_page(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_page(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_text_set(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::string_view edje::object::part_text_get(::efl::eina::string_view part_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_input_panel_show_on_demand_set(::efl::eina::string_view part_, bool ondemand_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_show_on_demand_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(ondemand_)));
}

inline bool edje::object::part_text_input_panel_show_on_demand_get(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_show_on_demand_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_input_hint_set(::efl::eina::string_view part_, Edje_Input_Hints input_hints_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_hint_set(::efl::eolian::to_c(part_), input_hints_));
}

inline Edje_Input_Hints edje::object::part_text_input_hint_get(::efl::eina::string_view part_) const
{
   Edje_Input_Hints _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_hint_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline ::efl::eina::string_view edje::object::part_text_selection_get(::efl::eina::string_view part_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_selection_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_text_cursor_is_format_get(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_is_format_get(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::text_class_get(::efl::eina::string_view text_class_, const char ** font_, Evas_Font_Size* size_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_class_get(::efl::eolian::to_c(text_class_), font_, size_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::color_class_set(::efl::eina::string_view color_class_, int r_, int g_, int b_, int a_, int r2_, int g2_, int b2_, int a2_, int r3_, int g3_, int b3_, int a3_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_color_class_set(::efl::eolian::to_c(color_class_), r_, g_, b_, a_, r2_, g2_, b2_, a2_, r3_, g3_, b3_, a3_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::color_class_get(::efl::eina::string_view color_class_, int* r_, int* g_, int* b_, int* a_, int* r2_, int* g2_, int* b2_, int* a2_, int* r3_, int* g3_, int* b3_, int* a3_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_color_class_get(::efl::eolian::to_c(color_class_), r_, g_, b_, a_, r2_, g2_, b2_, a2_, r3_, g3_, b3_, a3_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::string_view edje::object::color_class_description_get(::efl::eina::string_view color_class_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_color_class_description_get(::efl::eolian::to_c(color_class_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_drag_step(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_step(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_text_cursor_up(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_up(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_cursor_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_geometry_get(::efl::eolian::to_c(part_), x_, y_, w_, h_));
}

inline ::efl::eina::crange_list< ::efl::eina::string_view > edje::object::part_text_anchor_list_get(::efl::eina::string_view part_) const
{
   const Eina_List * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_anchor_list_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::crange_list< ::efl::eina::string_view >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
}

inline void edje::object::text_insert_filter_callback_add(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_text_insert_filter_callback_add(::efl::eolian::to_c(part_), func_, data_));
}

inline void edje::object::part_text_input_panel_show(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_show(::efl::eolian::to_c(part_)));
}

inline bool edje::object::part_exists(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_exists(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void * edje::object::text_markup_filter_callback_del(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_markup_filter_callback_del(::efl::eolian::to_c(part_), func_));
   return _tmp_ret;
}

inline bool edje::object::part_text_cursor_is_visible_format_get(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_is_visible_format_get(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_user_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_user_insert(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
}

inline bool edje::object::part_text_cursor_prev(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_prev(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::crange_list< ::efl::eina::string_view > edje::object::part_text_item_list_get(::efl::eina::string_view part_) const
{
   const Eina_List * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_item_list_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::crange_list< ::efl::eina::string_view >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
}

inline bool edje::object::part_swallow(::efl::eina::string_view part_, ::evas::object obj_swallow_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_swallow(::efl::eolian::to_c(part_), ::efl::eolian::to_c(obj_swallow_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::update_hints_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_update_hints_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::update_hints_set(bool update_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_update_hints_set(::efl::eolian::to_c(update_)));
}

inline bool edje::object::mirrored_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_mirrored_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::mirrored_set(bool rtl_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_mirrored_set(::efl::eolian::to_c(rtl_)));
}

inline bool edje::object::animation_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_animation_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::animation_set(bool on_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_animation_set(::efl::eolian::to_c(on_)));
}

inline bool edje::object::play_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_play_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::play_set(bool play_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_play_set(::efl::eolian::to_c(play_)));
}

inline const Edje_Perspective * edje::object::perspective_get() const
{
   const Edje_Perspective * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_perspective_get());
   return _tmp_ret;
}

inline void edje::object::perspective_set(Edje_Perspective * ps_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_perspective_set(ps_));
}

inline double edje::object::scale_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_scale_get());
   return _tmp_ret;
}

inline bool edje::object::scale_set(double scale_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_scale_set(scale_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline double edje::object::base_scale_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_base_scale_get());
   return _tmp_ret;
}

inline void edje::object::text_change_cb_set(Edje_Text_Change_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_text_change_cb_set(func_, data_));
}

inline void edje::object::part_text_cursor_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_begin_set(::efl::eolian::to_c(part_), cur_));
}

inline void edje::object::part_text_cursor_line_end_set(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_line_end_set(::efl::eolian::to_c(part_), cur_));
}

inline bool edje::object::text_class_set(::efl::eina::string_view text_class_, ::efl::eina::string_view font_, Evas_Font_Size size_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_class_set(::efl::eolian::to_c(text_class_), ::efl::eolian::to_c(font_), size_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool edje::object::part_text_cursor_coord_set(::efl::eina::string_view part_, Edje_Cursor cur_, Evas_Coord x_, Evas_Coord y_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_coord_set(::efl::eolian::to_c(part_), cur_, x_, y_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::part_text_cursor_end_set(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_end_set(::efl::eolian::to_c(part_), cur_));
}

inline bool edje::object::part_text_escaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_escaped_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void edje::object::item_provider_set(Edje_Item_Provider_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_item_provider_set(func_, data_));
}

inline void edje::object::part_text_cursor_line_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_line_begin_set(::efl::eolian::to_c(part_), cur_));
}

inline void edje::object::message_handler_set(Edje_Message_Handler_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_message_handler_set(func_, data_));
}

inline void edje::object::size_min_get(Evas_Coord* minw_, Evas_Coord* minh_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_size_min_get(minw_, minh_));
}

inline ::efl::eina::range_list< ::efl::eina::string_view > edje::object::access_part_list_get() const
{
   Eina_List * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_access_part_list_get());
   return ::efl::eolian::to_cxx<::efl::eina::range_list< ::efl::eina::string_view >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
}

inline Edje_Load_Error edje::object::load_error_get() const
{
   Edje_Load_Error _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_load_error_get());
   return _tmp_ret;
}

inline void edje::object::size_max_get(Evas_Coord* maxw_, Evas_Coord* maxh_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_size_max_get(maxw_, maxh_));
}

inline bool eo_cxx::edje::object::part_table_clear(::efl::eina::string_view part_, bool clear_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_clear(::efl::eolian::to_c(part_), ::efl::eolian::to_c(clear_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline Edje_External_Param_Type eo_cxx::edje::object::part_external_param_type_get(::efl::eina::string_view part_, const char* param_) const
{
   Edje_External_Param_Type _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_param_type_get(::efl::eolian::to_c(part_), param_));
   return _tmp_ret;
}

inline void eo_cxx::edje::object::part_text_select_allow_set(::efl::eina::string_view part_, bool allow_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_allow_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(allow_)));
}

inline ::efl::eina::string_view eo_cxx::edje::object::part_state_get(::efl::eina::string_view part_, double* val_ret_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_state_get(::efl::eolian::to_c(part_), val_ret_));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline void * eo_cxx::edje::object::text_markup_filter_callback_del_full(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_markup_filter_callback_del_full(::efl::eolian::to_c(part_), func_, data_));
   return _tmp_ret;
}

inline bool eo_cxx::edje::object::part_drag_step_set(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_step_set(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_drag_step_get(::efl::eina::string_view part_, double* dx_, double* dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_step_get(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void * eo_cxx::edje::object::part_text_imf_context_get(::efl::eina::string_view part_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_imf_context_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline void eo_cxx::edje::object::part_text_select_begin(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_begin(::efl::eolian::to_c(part_)));
}

inline ::efl::eina::string_view eo_cxx::edje::object::part_text_style_user_peek(::efl::eina::string_view part_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_style_user_peek(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

template <typename F_func_>
inline void * eo_cxx::edje::object::signal_callback_del(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_) const
{
   void * _tmp_ret;
   typedef typename std::remove_reference<F_func_>::type _no_ref_F_func_;
   _no_ref_F_func_* _tmp_func_ = new _no_ref_F_func_(std::forward< F_func_ >(func_));
   eo_do(_concrete_eo_ptr(), eo_event_callback_add(EO_EV_DEL, &::efl::eolian::free_callback_calback<_no_ref_F_func_>, _tmp_func_));

   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_signal_callback_del(::efl::eolian::to_c(emission_), ::efl::eolian::to_c(source_), ::efl::eolian::get_callback<Edje_Signal_Cb, _no_ref_F_func_ >(), _tmp_func_));
   return _tmp_ret;
}

inline bool eo_cxx::edje::object::part_text_cursor_next(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_next(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_style_user_push(::efl::eina::string_view part_, ::efl::eina::string_view style_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_style_user_push(::efl::eolian::to_c(part_), ::efl::eolian::to_c(style_)));
}

inline void eo_cxx::edje::object::part_text_append(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_append(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
}

inline bool eo_cxx::edje::object::part_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_geometry_get(::efl::eolian::to_c(part_), x_, y_, w_, h_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_input_panel_hide(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_hide(::efl::eolian::to_c(part_)));
}

inline bool eo_cxx::edje::object::part_text_item_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view item_, Evas_Coord* cx_, Evas_Coord* cy_, Evas_Coord* cw_, Evas_Coord* ch_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_item_geometry_get(::efl::eolian::to_c(part_), ::efl::eolian::to_c(item_), cx_, cy_, cw_, ch_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_table_unpack(::efl::eina::string_view part_, ::evas::object child_obj_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_unpack(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_obj_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_select_abort(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_abort(::efl::eolian::to_c(part_)));
}

inline void * eo_cxx::edje::object::text_insert_filter_callback_del_full(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_insert_filter_callback_del_full(::efl::eolian::to_c(part_), func_, data_));
   return _tmp_ret;
}

inline void eo_cxx::edje::object::part_text_style_user_pop(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_style_user_pop(::efl::eolian::to_c(part_)));
}

inline void eo_cxx::edje::object::part_text_input_panel_imdata_set(::efl::eina::string_view part_, const void * data_, int len_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_imdata_set(::efl::eolian::to_c(part_), data_, len_));
}

inline void eo_cxx::edje::object::part_text_input_panel_imdata_get(::efl::eina::string_view part_, void * data_, int * len_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_imdata_get(::efl::eolian::to_c(part_), data_, len_));
}

inline void eo_cxx::edje::object::part_text_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_insert(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
}

inline ::evas::object eo_cxx::edje::object::part_box_remove_at(::efl::eina::string_view part_, unsigned int pos_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_remove_at(::efl::eolian::to_c(part_), pos_));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_cursor_copy(::efl::eina::string_view part_, Edje_Cursor src_, Edje_Cursor dst_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_copy(::efl::eolian::to_c(part_), src_, dst_));
}

inline bool eo_cxx::edje::object::parts_extends_calc(Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_parts_extends_calc(x_, y_, w_, h_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_drag_value_set(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_value_set(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_drag_value_get(::efl::eina::string_view part_, double* dx_, double* dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_value_get(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::calc_force() const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_calc_force());
}

inline void eo_cxx::edje::object::part_text_cursor_pos_set(::efl::eina::string_view part_, Edje_Cursor cur_, int pos_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_pos_set(::efl::eolian::to_c(part_), cur_, pos_));
}

inline int eo_cxx::edje::object::part_text_cursor_pos_get(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_pos_get(::efl::eolian::to_c(part_), cur_));
   return _tmp_ret;
}

inline int eo_cxx::edje::object::freeze() const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_freeze());
   return _tmp_ret;
}

inline char * eo_cxx::edje::object::part_text_cursor_content_get(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_content_get(::efl::eolian::to_c(part_), cur_));
   return _tmp_ret;
}

inline void eo_cxx::edje::object::part_text_input_panel_layout_set(::efl::eina::string_view part_, Edje_Input_Panel_Layout layout_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_layout_set(::efl::eolian::to_c(part_), layout_));
}

inline Edje_Input_Panel_Layout eo_cxx::edje::object::part_text_input_panel_layout_get(::efl::eina::string_view part_) const
{
   Edje_Input_Panel_Layout _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_layout_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline bool eo_cxx::edje::object::part_table_pack(::efl::eina::string_view part_, ::evas::object child_obj_, unsigned short col_, unsigned short row_, unsigned short colspan_, unsigned short rowspan_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_pack(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_obj_), col_, row_, colspan_, rowspan_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_input_panel_language_set(::efl::eina::string_view part_, Edje_Input_Panel_Lang lang_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_language_set(::efl::eolian::to_c(part_), lang_));
}

inline Edje_Input_Panel_Lang eo_cxx::edje::object::part_text_input_panel_language_get(::efl::eina::string_view part_) const
{
   Edje_Input_Panel_Lang _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_language_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline bool eo_cxx::edje::object::part_table_col_row_size_get(::efl::eina::string_view part_, int* cols_, int* rows_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_col_row_size_get(::efl::eolian::to_c(part_), cols_, rows_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::evas::object eo_cxx::edje::object::part_external_object_get(::efl::eina::string_view part_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_object_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::evas::object eo_cxx::edje::object::part_external_content_get(::efl::eina::string_view part_, const char* content_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_content_get(::efl::eolian::to_c(part_), content_));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::preload(bool cancel_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_preload(::efl::eolian::to_c(cancel_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_input_panel_enabled_set(::efl::eina::string_view part_, bool enabled_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_enabled_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(enabled_)));
}

inline bool eo_cxx::edje::object::part_text_input_panel_enabled_get(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_enabled_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_select_extend(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_extend(::efl::eolian::to_c(part_)));
}

inline bool eo_cxx::edje::object::part_box_insert_at(::efl::eina::string_view part_, ::evas::object child_, unsigned int pos_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_insert_at(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_), pos_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::crange_list< const Evas_Textblock_Rectangle * > eo_cxx::edje::object::part_text_anchor_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view anchor_) const
{
   const Eina_List * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_anchor_geometry_get(::efl::eolian::to_c(part_), ::efl::eolian::to_c(anchor_)));
   return ::efl::eolian::to_cxx<::efl::eina::crange_list< const Evas_Textblock_Rectangle * >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
}

inline bool eo_cxx::edje::object::part_text_cursor_down(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_down(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_drag_page_set(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_page_set(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_drag_page_get(::efl::eina::string_view part_, double* dx_, double* dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_page_get(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_box_prepend(::efl::eina::string_view part_, ::evas::object child_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_prepend(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::signal_emit(::efl::eina::string_view emission_, ::efl::eina::string_view source_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_signal_emit(::efl::eolian::to_c(emission_), ::efl::eolian::to_c(source_)));
}

inline void eo_cxx::edje::object::part_text_input_panel_layout_variation_set(::efl::eina::string_view part_, int variation_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_layout_variation_set(::efl::eolian::to_c(part_), variation_));
}

inline int eo_cxx::edje::object::part_text_input_panel_layout_variation_get(::efl::eina::string_view part_) const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_layout_variation_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline void eo_cxx::edje::object::message_send(Edje_Message_Type type_, int id_, void * msg_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_message_send(type_, id_, msg_));
}

inline void eo_cxx::edje::object::part_text_select_none(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_none(::efl::eolian::to_c(part_)));
}

inline const Evas_Object * eo_cxx::edje::object::part_object_get(::efl::eina::string_view part_) const
{
   const Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_object_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline bool eo_cxx::edje::object::part_drag_size_set(::efl::eina::string_view part_, double dw_, double dh_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_size_set(::efl::eolian::to_c(part_), dw_, dh_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_drag_size_get(::efl::eina::string_view part_, double* dw_, double* dh_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_size_get(::efl::eolian::to_c(part_), dw_, dh_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void * eo_cxx::edje::object::text_insert_filter_callback_del(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_insert_filter_callback_del(::efl::eolian::to_c(part_), func_));
   return _tmp_ret;
}

inline Edje_Drag_Dir eo_cxx::edje::object::part_drag_dir_get(::efl::eina::string_view part_) const
{
   Edje_Drag_Dir _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_dir_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline bool eo_cxx::edje::object::part_text_unescaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_to_escape_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_unescaped_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_to_escape_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline char * eo_cxx::edje::object::part_text_unescaped_get(::efl::eina::string_view part_) const
{
   char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_unescaped_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

template <typename F_func_>
inline void eo_cxx::edje::object::signal_callback_add(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_) const
{
   typedef typename std::remove_reference<F_func_>::type _no_ref_F_func_;
   _no_ref_F_func_* _tmp_func_ = new _no_ref_F_func_(std::forward< F_func_ >(func_));
   eo_do(_concrete_eo_ptr(), eo_event_callback_add(EO_EV_DEL, &::efl::eolian::free_callback_calback<_no_ref_F_func_>, _tmp_func_));

   eo_do(_concrete_eo_ptr(), ::edje_obj_signal_callback_add(::efl::eolian::to_c(emission_), ::efl::eolian::to_c(source_), ::efl::eolian::get_callback<Edje_Signal_Cb, _no_ref_F_func_ >(), _tmp_func_));
}

inline void eo_cxx::edje::object::part_text_select_all(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_select_all(::efl::eolian::to_c(part_)));
}

inline void eo_cxx::edje::object::part_text_input_panel_return_key_disabled_set(::efl::eina::string_view part_, bool disabled_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_return_key_disabled_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(disabled_)));
}

inline bool eo_cxx::edje::object::part_text_input_panel_return_key_disabled_get(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_return_key_disabled_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_autocapital_type_set(::efl::eina::string_view part_, Edje_Text_Autocapital_Type autocapital_type_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_autocapital_type_set(::efl::eolian::to_c(part_), autocapital_type_));
}

inline Edje_Text_Autocapital_Type eo_cxx::edje::object::part_text_autocapital_type_get(::efl::eina::string_view part_) const
{
   Edje_Text_Autocapital_Type _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_autocapital_type_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline void eo_cxx::edje::object::part_unswallow(::evas::object obj_swallow_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_unswallow(::efl::eolian::to_c(obj_swallow_)));
}

inline void eo_cxx::edje::object::part_text_prediction_allow_set(::efl::eina::string_view part_, bool prediction_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_prediction_allow_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(prediction_)));
}

inline bool eo_cxx::edje::object::part_text_prediction_allow_get(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_prediction_allow_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::string_view eo_cxx::edje::object::data_get(::efl::eina::string_view key_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_data_get(::efl::eolian::to_c(key_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::text_markup_filter_callback_add(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_text_markup_filter_callback_add(::efl::eolian::to_c(part_), func_, data_));
}

inline void eo_cxx::edje::object::message_signal_process() const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_message_signal_process());
}

inline ::evas::object eo_cxx::edje::object::part_box_remove(::efl::eina::string_view part_, ::evas::object child_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_remove(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_)));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline int eo_cxx::edje::object::thaw() const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_thaw());
   return _tmp_ret;
}

inline ::evas::object eo_cxx::edje::object::part_swallow_get(::efl::eina::string_view part_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_swallow_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_imf_context_reset(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_imf_context_reset(::efl::eolian::to_c(part_)));
}

inline void eo_cxx::edje::object::part_text_input_panel_return_key_type_set(::efl::eina::string_view part_, Edje_Input_Panel_Return_Key_Type return_key_type_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_return_key_type_set(::efl::eolian::to_c(part_), return_key_type_));
}

inline Edje_Input_Panel_Return_Key_Type eo_cxx::edje::object::part_text_input_panel_return_key_type_get(::efl::eina::string_view part_) const
{
   Edje_Input_Panel_Return_Key_Type _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_return_key_type_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline ::evas::object eo_cxx::edje::object::part_table_child_get(::efl::eina::string_view part_, unsigned int col_, unsigned int row_) const
{
   Evas_Object * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_table_child_get(::efl::eolian::to_c(part_), col_, row_));
   return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_box_insert_before(::efl::eina::string_view part_, ::evas::object child_, const Evas_Object * reference_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_insert_before(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_), reference_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_external_param_set(::efl::eina::string_view part_, const Edje_External_Param * param_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_param_set(::efl::eolian::to_c(part_), param_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_external_param_get(::efl::eina::string_view part_, Edje_External_Param* param_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_external_param_get(::efl::eolian::to_c(part_), param_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::size_min_calc(Evas_Coord* minw_, Evas_Coord* minh_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_size_min_calc(minw_, minh_));
}

inline bool eo_cxx::edje::object::part_box_append(::efl::eina::string_view part_, ::evas::object child_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_append(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::size_min_restricted_calc(Evas_Coord* minw_, Evas_Coord* minh_, Evas_Coord restrictedw_, Evas_Coord restrictedh_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_size_min_restricted_calc(minw_, minh_, restrictedw_, restrictedh_));
}

inline bool eo_cxx::edje::object::part_box_remove_all(::efl::eina::string_view part_, bool clear_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_box_remove_all(::efl::eolian::to_c(part_), ::efl::eolian::to_c(clear_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_drag_page(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_page(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_text_set(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::string_view eo_cxx::edje::object::part_text_get(::efl::eina::string_view part_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_input_panel_show_on_demand_set(::efl::eina::string_view part_, bool ondemand_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_show_on_demand_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(ondemand_)));
}

inline bool eo_cxx::edje::object::part_text_input_panel_show_on_demand_get(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_panel_show_on_demand_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_input_hint_set(::efl::eina::string_view part_, Edje_Input_Hints input_hints_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_hint_set(::efl::eolian::to_c(part_), input_hints_));
}

inline Edje_Input_Hints eo_cxx::edje::object::part_text_input_hint_get(::efl::eina::string_view part_) const
{
   Edje_Input_Hints _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_input_hint_get(::efl::eolian::to_c(part_)));
   return _tmp_ret;
}

inline ::efl::eina::string_view eo_cxx::edje::object::part_text_selection_get(::efl::eina::string_view part_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_selection_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_text_cursor_is_format_get(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_is_format_get(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::text_class_get(::efl::eina::string_view text_class_, const char ** font_, Evas_Font_Size* size_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_class_get(::efl::eolian::to_c(text_class_), font_, size_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::color_class_set(::efl::eina::string_view color_class_, int r_, int g_, int b_, int a_, int r2_, int g2_, int b2_, int a2_, int r3_, int g3_, int b3_, int a3_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_color_class_set(::efl::eolian::to_c(color_class_), r_, g_, b_, a_, r2_, g2_, b2_, a2_, r3_, g3_, b3_, a3_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::color_class_get(::efl::eina::string_view color_class_, int* r_, int* g_, int* b_, int* a_, int* r2_, int* g2_, int* b2_, int* a2_, int* r3_, int* g3_, int* b3_, int* a3_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_color_class_get(::efl::eolian::to_c(color_class_), r_, g_, b_, a_, r2_, g2_, b2_, a2_, r3_, g3_, b3_, a3_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::string_view eo_cxx::edje::object::color_class_description_get(::efl::eina::string_view color_class_) const
{
   const char * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_color_class_description_get(::efl::eolian::to_c(color_class_)));
   return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_drag_step(::efl::eina::string_view part_, double dx_, double dy_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_drag_step(::efl::eolian::to_c(part_), dx_, dy_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_text_cursor_up(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_up(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_cursor_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_geometry_get(::efl::eolian::to_c(part_), x_, y_, w_, h_));
}

inline ::efl::eina::crange_list< ::efl::eina::string_view > eo_cxx::edje::object::part_text_anchor_list_get(::efl::eina::string_view part_) const
{
   const Eina_List * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_anchor_list_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::crange_list< ::efl::eina::string_view >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
}

inline void eo_cxx::edje::object::text_insert_filter_callback_add(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_text_insert_filter_callback_add(::efl::eolian::to_c(part_), func_, data_));
}

inline void eo_cxx::edje::object::part_text_input_panel_show(::efl::eina::string_view part_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_input_panel_show(::efl::eolian::to_c(part_)));
}

inline bool eo_cxx::edje::object::part_exists(::efl::eina::string_view part_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_exists(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void * eo_cxx::edje::object::text_markup_filter_callback_del(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_) const
{
   void * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_markup_filter_callback_del(::efl::eolian::to_c(part_), func_));
   return _tmp_ret;
}

inline bool eo_cxx::edje::object::part_text_cursor_is_visible_format_get(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_is_visible_format_get(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_user_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_user_insert(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
}

inline bool eo_cxx::edje::object::part_text_cursor_prev(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_prev(::efl::eolian::to_c(part_), cur_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline ::efl::eina::crange_list< ::efl::eina::string_view > eo_cxx::edje::object::part_text_item_list_get(::efl::eina::string_view part_) const
{
   const Eina_List * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_item_list_get(::efl::eolian::to_c(part_)));
   return ::efl::eolian::to_cxx<::efl::eina::crange_list< ::efl::eina::string_view >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
}

inline bool eo_cxx::edje::object::part_swallow(::efl::eina::string_view part_, ::evas::object obj_swallow_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_swallow(::efl::eolian::to_c(part_), ::efl::eolian::to_c(obj_swallow_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::update_hints_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_update_hints_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::update_hints_set(bool update_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_update_hints_set(::efl::eolian::to_c(update_)));
}

inline bool eo_cxx::edje::object::mirrored_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_mirrored_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::mirrored_set(bool rtl_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_mirrored_set(::efl::eolian::to_c(rtl_)));
}

inline bool eo_cxx::edje::object::animation_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_animation_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::animation_set(bool on_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_animation_set(::efl::eolian::to_c(on_)));
}

inline bool eo_cxx::edje::object::play_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_play_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::play_set(bool play_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_play_set(::efl::eolian::to_c(play_)));
}

inline const Edje_Perspective * eo_cxx::edje::object::perspective_get() const
{
   const Edje_Perspective * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_perspective_get());
   return _tmp_ret;
}

inline void eo_cxx::edje::object::perspective_set(Edje_Perspective * ps_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_perspective_set(ps_));
}

inline double eo_cxx::edje::object::scale_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_scale_get());
   return _tmp_ret;
}

inline bool eo_cxx::edje::object::scale_set(double scale_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_scale_set(scale_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline double eo_cxx::edje::object::base_scale_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_base_scale_get());
   return _tmp_ret;
}

inline void eo_cxx::edje::object::text_change_cb_set(Edje_Text_Change_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_text_change_cb_set(func_, data_));
}

inline void eo_cxx::edje::object::part_text_cursor_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_begin_set(::efl::eolian::to_c(part_), cur_));
}

inline void eo_cxx::edje::object::part_text_cursor_line_end_set(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_line_end_set(::efl::eolian::to_c(part_), cur_));
}

inline bool eo_cxx::edje::object::text_class_set(::efl::eina::string_view text_class_, ::efl::eina::string_view font_, Evas_Font_Size size_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_text_class_set(::efl::eolian::to_c(text_class_), ::efl::eolian::to_c(font_), size_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline bool eo_cxx::edje::object::part_text_cursor_coord_set(::efl::eina::string_view part_, Edje_Cursor cur_, Evas_Coord x_, Evas_Coord y_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_cursor_coord_set(::efl::eolian::to_c(part_), cur_, x_, y_));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::part_text_cursor_end_set(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_end_set(::efl::eolian::to_c(part_), cur_));
}

inline bool eo_cxx::edje::object::part_text_escaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_) const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_part_text_escaped_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::edje::object::item_provider_set(Edje_Item_Provider_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_item_provider_set(func_, data_));
}

inline void eo_cxx::edje::object::part_text_cursor_line_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_part_text_cursor_line_begin_set(::efl::eolian::to_c(part_), cur_));
}

inline void eo_cxx::edje::object::message_handler_set(Edje_Message_Handler_Cb func_, void * data_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_message_handler_set(func_, data_));
}

inline void eo_cxx::edje::object::size_min_get(Evas_Coord* minw_, Evas_Coord* minh_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_size_min_get(minw_, minh_));
}

inline ::efl::eina::range_list< ::efl::eina::string_view > eo_cxx::edje::object::access_part_list_get() const
{
   Eina_List * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_access_part_list_get());
   return ::efl::eolian::to_cxx<::efl::eina::range_list< ::efl::eina::string_view >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
}

inline Edje_Load_Error eo_cxx::edje::object::load_error_get() const
{
   Edje_Load_Error _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::edje_obj_load_error_get());
   return _tmp_ret;
}

inline void eo_cxx::edje::object::size_max_get(Evas_Coord* maxw_, Evas_Coord* maxh_) const
{
   eo_do(_concrete_eo_ptr(), ::edje_obj_size_max_get(maxw_, maxh_));
}

inline ::eo_cxx::edje::object::operator ::edje::object() const
{
   return *static_cast<::edje::object const*>(static_cast<void const*>(this));
}

inline ::eo_cxx::edje::object::operator ::edje::object&()
{
   return *static_cast<::edje::object*>(static_cast<void*>(this));
}

inline ::eo_cxx::edje::object::operator ::edje::object const&() const
{
   return *static_cast<::edje::object const*>(static_cast<void const*>(this));
}

template <typename T>
bool edje_object_part_table_clear_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Eina_Bool clear_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_table_clear(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<bool>(clear_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Edje_External_Param_Type edje_object_part_external_param_type_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char* param_)
{
   Edje_External_Param_Type _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_external_param_type_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), param_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_select_allow_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Eina_Bool allow_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_select_allow_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<bool>(allow_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
::efl::eina::string_view edje_object_part_state_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double* val_ret_)
{
   ::efl::eina::string_view _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_state_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), val_ret_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void * edje_object_text_markup_filter_callback_del_full_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Markup_Filter_Cb func_, void * data_)
{
   void * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->text_markup_filter_callback_del_full(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), func_, data_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_step_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double dx_, double dy_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_step_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dx_, dy_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_step_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double* dx_, double* dy_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_step_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dx_, dy_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void * edje_object_part_text_imf_context_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   void * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_imf_context_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_select_begin_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_select_begin(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
::efl::eina::string_view edje_object_part_text_style_user_peek_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   ::efl::eina::string_view _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_style_user_peek(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void * edje_object_signal_callback_del_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * emission_, const char * source_, Edje_Signal_Cb func_, void * data_)
{
   void * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->signal_callback_del(::efl::eolian::to_cxx<::efl::eina::string_view>(emission_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(source_, std::tuple<std::false_type>()), func_, data_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_text_cursor_next_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_cursor_next(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_style_user_push_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char * style_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_style_user_push(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(style_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_append_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char * text_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_append(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(text_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_geometry_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_geometry_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), x_, y_, w_, h_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_input_panel_hide_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_hide(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_text_item_geometry_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char * item_, Evas_Coord* cx_, Evas_Coord* cy_, Evas_Coord* cw_, Evas_Coord* ch_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_item_geometry_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(item_, std::tuple<std::false_type>()), cx_, cy_, cw_, ch_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_table_unpack_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Object * child_obj_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_table_unpack(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::evas::object>(child_obj_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_select_abort_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_select_abort(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void * edje_object_text_insert_filter_callback_del_full_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Text_Filter_Cb func_, void * data_)
{
   void * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->text_insert_filter_callback_del_full(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), func_, data_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_style_user_pop_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_style_user_pop(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_input_panel_imdata_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const void * data_, int len_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_imdata_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), data_, len_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_input_panel_imdata_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, void * data_, int * len_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_imdata_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), data_, len_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_insert_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char * text_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_insert(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(text_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
::evas::object edje_object_part_box_remove_at_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, unsigned int pos_)
{
   ::evas::object _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_box_remove_at(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), pos_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_cursor_copy_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor src_, Edje_Cursor dst_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_cursor_copy(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), src_, dst_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_parts_extends_calc_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->parts_extends_calc(x_, y_, w_, h_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_value_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double dx_, double dy_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_value_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dx_, dy_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_value_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double* dx_, double* dy_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_value_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dx_, dy_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_calc_force_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   try
      {
         static_cast<T*>(self->this_)->calc_force();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_cursor_pos_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_, int pos_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_cursor_pos_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_, pos_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
int edje_object_part_text_cursor_pos_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   int _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_cursor_pos_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
int edje_object_freeze_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   int _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->freeze();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
char * edje_object_part_text_cursor_content_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   char * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_cursor_content_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_input_panel_layout_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Input_Panel_Layout layout_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_layout_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), layout_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
Edje_Input_Panel_Layout edje_object_part_text_input_panel_layout_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   Edje_Input_Panel_Layout _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_input_panel_layout_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_table_pack_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Object * child_obj_, unsigned short col_, unsigned short row_, unsigned short colspan_, unsigned short rowspan_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_table_pack(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::evas::object>(child_obj_, std::tuple<std::false_type>()), col_, row_, colspan_, rowspan_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_input_panel_language_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Input_Panel_Lang lang_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_language_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), lang_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
Edje_Input_Panel_Lang edje_object_part_text_input_panel_language_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   Edje_Input_Panel_Lang _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_input_panel_language_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_table_col_row_size_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, int* cols_, int* rows_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_table_col_row_size_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cols_, rows_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::evas::object edje_object_part_external_object_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   ::evas::object _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_external_object_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::evas::object edje_object_part_external_content_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char* content_)
{
   ::evas::object _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_external_content_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), content_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_preload_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Eina_Bool cancel_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->preload(::efl::eolian::to_cxx<bool>(cancel_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_input_panel_enabled_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Eina_Bool enabled_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_enabled_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<bool>(enabled_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_text_input_panel_enabled_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_input_panel_enabled_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_select_extend_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_select_extend(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_box_insert_at_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Object * child_, unsigned int pos_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_box_insert_at(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::evas::object>(child_, std::tuple<std::false_type>()), pos_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::efl::eina::crange_list< const Evas_Textblock_Rectangle * > edje_object_part_text_anchor_geometry_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char * anchor_)
{
   ::efl::eina::crange_list< const Evas_Textblock_Rectangle * > _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_anchor_geometry_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(anchor_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_text_cursor_down_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_cursor_down(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_page_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double dx_, double dy_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_page_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dx_, dy_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_page_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double* dx_, double* dy_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_page_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dx_, dy_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_box_prepend_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Object * child_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_box_prepend(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::evas::object>(child_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_signal_emit_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * emission_, const char * source_)
{
   try
      {
         static_cast<T*>(self->this_)->signal_emit(::efl::eolian::to_cxx<::efl::eina::string_view>(emission_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(source_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_input_panel_layout_variation_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, int variation_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_layout_variation_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), variation_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
int edje_object_part_text_input_panel_layout_variation_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   int _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_input_panel_layout_variation_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_message_send_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Edje_Message_Type type_, int id_, void * msg_)
{
   try
      {
         static_cast<T*>(self->this_)->message_send(type_, id_, msg_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_select_none_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_select_none(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
const Evas_Object * edje_object_part_object_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   const Evas_Object * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_object_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_size_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double dw_, double dh_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_size_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dw_, dh_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_size_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double* dw_, double* dh_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_size_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dw_, dh_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void * edje_object_text_insert_filter_callback_del_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Text_Filter_Cb func_)
{
   void * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->text_insert_filter_callback_del(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), func_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Edje_Drag_Dir edje_object_part_drag_dir_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   Edje_Drag_Dir _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_dir_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_text_unescaped_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char * text_to_escape_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_unescaped_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(text_to_escape_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
char * edje_object_part_text_unescaped_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   char * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_unescaped_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_signal_callback_add_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * emission_, const char * source_, Edje_Signal_Cb func_, void * data_)
{
   try
      {
         static_cast<T*>(self->this_)->signal_callback_add(::efl::eolian::to_cxx<::efl::eina::string_view>(emission_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(source_, std::tuple<std::false_type>()), func_, data_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_select_all_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_select_all(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_input_panel_return_key_disabled_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Eina_Bool disabled_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_return_key_disabled_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<bool>(disabled_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_text_input_panel_return_key_disabled_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_input_panel_return_key_disabled_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_autocapital_type_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Text_Autocapital_Type autocapital_type_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_autocapital_type_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), autocapital_type_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
Edje_Text_Autocapital_Type edje_object_part_text_autocapital_type_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   Edje_Text_Autocapital_Type _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_autocapital_type_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_unswallow_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Evas_Object * obj_swallow_)
{
   try
      {
         static_cast<T*>(self->this_)->part_unswallow(::efl::eolian::to_cxx<::evas::object>(obj_swallow_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_prediction_allow_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Eina_Bool prediction_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_prediction_allow_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<bool>(prediction_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_text_prediction_allow_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_prediction_allow_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::efl::eina::string_view edje_object_data_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * key_)
{
   ::efl::eina::string_view _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->data_get(::efl::eolian::to_cxx<::efl::eina::string_view>(key_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_text_markup_filter_callback_add_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Markup_Filter_Cb func_, void * data_)
{
   try
      {
         static_cast<T*>(self->this_)->text_markup_filter_callback_add(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), func_, data_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_message_signal_process_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   try
      {
         static_cast<T*>(self->this_)->message_signal_process();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
::evas::object edje_object_part_box_remove_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Object * child_)
{
   ::evas::object _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_box_remove(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::evas::object>(child_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
int edje_object_thaw_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   int _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->thaw();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::evas::object edje_object_part_swallow_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   ::evas::object _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_swallow_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_imf_context_reset_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_imf_context_reset(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_input_panel_return_key_type_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Input_Panel_Return_Key_Type return_key_type_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_return_key_type_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), return_key_type_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
Edje_Input_Panel_Return_Key_Type edje_object_part_text_input_panel_return_key_type_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   Edje_Input_Panel_Return_Key_Type _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_input_panel_return_key_type_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::evas::object edje_object_part_table_child_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, unsigned int col_, unsigned int row_)
{
   ::evas::object _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_table_child_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), col_, row_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_box_insert_before_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Object * child_, const Evas_Object * reference_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_box_insert_before(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::evas::object>(child_, std::tuple<std::false_type>()), reference_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_external_param_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const Edje_External_Param * param_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_external_param_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), param_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_external_param_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_External_Param* param_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_external_param_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), param_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_size_min_calc_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Evas_Coord* minw_, Evas_Coord* minh_)
{
   try
      {
         static_cast<T*>(self->this_)->size_min_calc(minw_, minh_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_box_append_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Object * child_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_box_append(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::evas::object>(child_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_size_min_restricted_calc_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Evas_Coord* minw_, Evas_Coord* minh_, Evas_Coord restrictedw_, Evas_Coord restrictedh_)
{
   try
      {
         static_cast<T*>(self->this_)->size_min_restricted_calc(minw_, minh_, restrictedw_, restrictedh_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_box_remove_all_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Eina_Bool clear_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_box_remove_all(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<bool>(clear_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_page_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double dx_, double dy_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_page(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dx_, dy_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_text_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char * text_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(text_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::efl::eina::string_view edje_object_part_text_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   ::efl::eina::string_view _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_input_panel_show_on_demand_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Eina_Bool ondemand_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_show_on_demand_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<bool>(ondemand_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_text_input_panel_show_on_demand_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_input_panel_show_on_demand_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_input_hint_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Input_Hints input_hints_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_hint_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), input_hints_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
Edje_Input_Hints edje_object_part_text_input_hint_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   Edje_Input_Hints _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_input_hint_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::efl::eina::string_view edje_object_part_text_selection_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   ::efl::eina::string_view _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_selection_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_text_cursor_is_format_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_cursor_is_format_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_text_class_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * text_class_, const char ** font_, Evas_Font_Size* size_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->text_class_get(::efl::eolian::to_cxx<::efl::eina::string_view>(text_class_, std::tuple<std::false_type>()), font_, size_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_color_class_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * color_class_, int r_, int g_, int b_, int a_, int r2_, int g2_, int b2_, int a2_, int r3_, int g3_, int b3_, int a3_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->color_class_set(::efl::eolian::to_cxx<::efl::eina::string_view>(color_class_, std::tuple<std::false_type>()), r_, g_, b_, a_, r2_, g2_, b2_, a2_, r3_, g3_, b3_, a3_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_color_class_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * color_class_, int* r_, int* g_, int* b_, int* a_, int* r2_, int* g2_, int* b2_, int* a2_, int* r3_, int* g3_, int* b3_, int* a3_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->color_class_get(::efl::eolian::to_cxx<::efl::eina::string_view>(color_class_, std::tuple<std::false_type>()), r_, g_, b_, a_, r2_, g2_, b2_, a2_, r3_, g3_, b3_, a3_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::efl::eina::string_view edje_object_color_class_description_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * color_class_)
{
   ::efl::eina::string_view _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->color_class_description_get(::efl::eolian::to_cxx<::efl::eina::string_view>(color_class_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_drag_step_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, double dx_, double dy_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_drag_step(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), dx_, dy_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_text_cursor_up_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_cursor_up(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_cursor_geometry_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_cursor_geometry_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), x_, y_, w_, h_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
::efl::eina::crange_list< ::efl::eina::string_view > edje_object_part_text_anchor_list_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   ::efl::eina::crange_list< ::efl::eina::string_view > _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_anchor_list_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_text_insert_filter_callback_add_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Text_Filter_Cb func_, void * data_)
{
   try
      {
         static_cast<T*>(self->this_)->text_insert_filter_callback_add(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), func_, data_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_input_panel_show_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_input_panel_show(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_exists_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_exists(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void * edje_object_text_markup_filter_callback_del_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Markup_Filter_Cb func_)
{
   void * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->text_markup_filter_callback_del(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), func_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_text_cursor_is_visible_format_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_cursor_is_visible_format_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_user_insert_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char * text_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_user_insert(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(text_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_text_cursor_prev_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_cursor_prev(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
::efl::eina::crange_list< ::efl::eina::string_view > edje_object_part_text_item_list_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_)
{
   ::efl::eina::crange_list< ::efl::eina::string_view > _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_item_list_get(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_swallow_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Evas_Object * obj_swallow_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_swallow(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::evas::object>(obj_swallow_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_update_hints_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->update_hints_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_update_hints_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Eina_Bool update_)
{
   try
      {
         static_cast<T*>(self->this_)->update_hints_set(::efl::eolian::to_cxx<bool>(update_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_mirrored_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->mirrored_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_mirrored_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Eina_Bool rtl_)
{
   try
      {
         static_cast<T*>(self->this_)->mirrored_set(::efl::eolian::to_cxx<bool>(rtl_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_animation_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->animation_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_animation_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Eina_Bool on_)
{
   try
      {
         static_cast<T*>(self->this_)->animation_set(::efl::eolian::to_cxx<bool>(on_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_play_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->play_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_play_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Eina_Bool play_)
{
   try
      {
         static_cast<T*>(self->this_)->play_set(::efl::eolian::to_cxx<bool>(play_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
const Edje_Perspective * edje_object_perspective_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   const Edje_Perspective * _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->perspective_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_perspective_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Edje_Perspective * ps_)
{
   try
      {
         static_cast<T*>(self->this_)->perspective_set(ps_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
double edje_object_scale_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   double _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->scale_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_scale_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, double scale_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->scale_set(scale_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
double edje_object_base_scale_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   double _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->base_scale_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_text_change_cb_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Edje_Text_Change_Cb func_, void * data_)
{
   try
      {
         static_cast<T*>(self->this_)->text_change_cb_set(func_, data_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_cursor_begin_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_cursor_begin_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_cursor_line_end_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_cursor_line_end_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_text_class_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * text_class_, const char * font_, Evas_Font_Size size_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->text_class_set(::efl::eolian::to_cxx<::efl::eina::string_view>(text_class_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(font_, std::tuple<std::false_type>()), size_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
bool edje_object_part_text_cursor_coord_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_, Evas_Coord x_, Evas_Coord y_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_cursor_coord_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_, x_, y_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_part_text_cursor_end_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_cursor_end_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool edje_object_part_text_escaped_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, const char * text_)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->part_text_escaped_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), ::efl::eolian::to_cxx<::efl::eina::string_view>(text_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_item_provider_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Edje_Item_Provider_Cb func_, void * data_)
{
   try
      {
         static_cast<T*>(self->this_)->item_provider_set(func_, data_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_part_text_cursor_line_begin_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, const char * part_, Edje_Cursor cur_)
{
   try
      {
         static_cast<T*>(self->this_)->part_text_cursor_line_begin_set(::efl::eolian::to_cxx<::efl::eina::string_view>(part_, std::tuple<std::false_type>()), cur_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_message_handler_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Edje_Message_Handler_Cb func_, void * data_)
{
   try
      {
         static_cast<T*>(self->this_)->message_handler_set(func_, data_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
void edje_object_size_min_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Evas_Coord* minw_, Evas_Coord* minh_)
{
   try
      {
         static_cast<T*>(self->this_)->size_min_get(minw_, minh_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
::efl::eina::range_list< ::efl::eina::string_view > edje_object_access_part_list_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   ::efl::eina::range_list< ::efl::eina::string_view > _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->access_part_list_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
Edje_Load_Error edje_object_load_error_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   Edje_Load_Error _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->load_error_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void edje_object_size_max_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Evas_Coord* maxw_, Evas_Coord* maxh_)
{
   try
      {
         static_cast<T*>(self->this_)->size_max_get(maxw_, maxh_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

namespace efl { namespace eo { namespace detail {

template<>
struct operations< ::edje::object >
{
   template <typename T>
   struct type
         : virtual operations< ::evas::smart_clipped >::template type<T>
         , virtual operations< ::efl::file >::template type<T>
   {
      virtual bool part_table_clear(::efl::eina::string_view part_, bool clear_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_table_clear(::efl::eolian::to_c(part_), ::efl::eolian::to_c(clear_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual Edje_External_Param_Type part_external_param_type_get(::efl::eina::string_view part_, const char* param_)
      {
         Edje_External_Param_Type _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_external_param_type_get(::efl::eolian::to_c(part_), param_));
            return _tmp_ret;
      }

      virtual void part_text_select_allow_set(::efl::eina::string_view part_, bool allow_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_select_allow_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(allow_)));
      }

      virtual ::efl::eina::string_view part_state_get(::efl::eina::string_view part_, double* val_ret_)
      {
         const char * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_state_get(::efl::eolian::to_c(part_), val_ret_));
            return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void * text_markup_filter_callback_del_full(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_)
      {
         void * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_text_markup_filter_callback_del_full(::efl::eolian::to_c(part_), func_, data_));
            return _tmp_ret;
      }

      virtual bool part_drag_step_set(::efl::eina::string_view part_, double dx_, double dy_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_step_set(::efl::eolian::to_c(part_), dx_, dy_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_drag_step_get(::efl::eina::string_view part_, double* dx_, double* dy_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_step_get(::efl::eolian::to_c(part_), dx_, dy_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void * part_text_imf_context_get(::efl::eina::string_view part_)
      {
         void * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_imf_context_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      virtual void part_text_select_begin(::efl::eina::string_view part_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_select_begin(::efl::eolian::to_c(part_)));
      }

      virtual ::efl::eina::string_view part_text_style_user_peek(::efl::eina::string_view part_)
      {
         const char * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_style_user_peek(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
      }

      template <typename F_func_>
      void * signal_callback_del(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_)
      {
         void * _tmp_ret = {};
         typedef typename std::remove_reference<F_func_>::type _no_ref_F_func_;
         _no_ref_F_func_* _tmp_func_ = new _no_ref_F_func_(std::forward< F_func_ >(func_));
         eo_do(dynamic_cast<T*>(this)->_eo_ptr(), eo_event_callback_add(EO_EV_DEL, &::efl::eolian::free_callback_calback<_no_ref_F_func_>, _tmp_func_));


         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_signal_callback_del(::efl::eolian::to_c(emission_), ::efl::eolian::to_c(source_), ::efl::eolian::get_callback<Edje_Signal_Cb, _no_ref_F_func_ >(), _tmp_func_));
            return _tmp_ret;
      }

      virtual bool part_text_cursor_next(::efl::eina::string_view part_, Edje_Cursor cur_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_cursor_next(::efl::eolian::to_c(part_), cur_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_style_user_push(::efl::eina::string_view part_, ::efl::eina::string_view style_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_style_user_push(::efl::eolian::to_c(part_), ::efl::eolian::to_c(style_)));
      }

      virtual void part_text_append(::efl::eina::string_view part_, ::efl::eina::string_view text_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_append(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
      }

      virtual bool part_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_geometry_get(::efl::eolian::to_c(part_), x_, y_, w_, h_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_input_panel_hide(::efl::eina::string_view part_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_hide(::efl::eolian::to_c(part_)));
      }

      virtual bool part_text_item_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view item_, Evas_Coord* cx_, Evas_Coord* cy_, Evas_Coord* cw_, Evas_Coord* ch_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_item_geometry_get(::efl::eolian::to_c(part_), ::efl::eolian::to_c(item_), cx_, cy_, cw_, ch_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_table_unpack(::efl::eina::string_view part_, ::evas::object child_obj_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_table_unpack(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_obj_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_select_abort(::efl::eina::string_view part_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_select_abort(::efl::eolian::to_c(part_)));
      }

      virtual void * text_insert_filter_callback_del_full(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_)
      {
         void * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_text_insert_filter_callback_del_full(::efl::eolian::to_c(part_), func_, data_));
            return _tmp_ret;
      }

      virtual void part_text_style_user_pop(::efl::eina::string_view part_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_style_user_pop(::efl::eolian::to_c(part_)));
      }

      virtual void part_text_input_panel_imdata_set(::efl::eina::string_view part_, const void * data_, int len_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_imdata_set(::efl::eolian::to_c(part_), data_, len_));
      }

      virtual void part_text_input_panel_imdata_get(::efl::eina::string_view part_, void * data_, int * len_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_imdata_get(::efl::eolian::to_c(part_), data_, len_));
      }

      virtual void part_text_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_insert(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
      }

      virtual ::evas::object part_box_remove_at(::efl::eina::string_view part_, unsigned int pos_)
      {
         Evas_Object * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_box_remove_at(::efl::eolian::to_c(part_), pos_));
            return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_cursor_copy(::efl::eina::string_view part_, Edje_Cursor src_, Edje_Cursor dst_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_cursor_copy(::efl::eolian::to_c(part_), src_, dst_));
      }

      virtual bool parts_extends_calc(Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_parts_extends_calc(x_, y_, w_, h_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_drag_value_set(::efl::eina::string_view part_, double dx_, double dy_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_value_set(::efl::eolian::to_c(part_), dx_, dy_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_drag_value_get(::efl::eina::string_view part_, double* dx_, double* dy_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_value_get(::efl::eolian::to_c(part_), dx_, dy_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void calc_force()
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_calc_force());
      }

      virtual void part_text_cursor_pos_set(::efl::eina::string_view part_, Edje_Cursor cur_, int pos_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_cursor_pos_set(::efl::eolian::to_c(part_), cur_, pos_));
      }

      virtual int part_text_cursor_pos_get(::efl::eina::string_view part_, Edje_Cursor cur_)
      {
         int _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_cursor_pos_get(::efl::eolian::to_c(part_), cur_));
            return _tmp_ret;
      }

      virtual int freeze()
      {
         int _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_freeze());
            return _tmp_ret;
      }

      virtual char * part_text_cursor_content_get(::efl::eina::string_view part_, Edje_Cursor cur_)
      {
         char * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_cursor_content_get(::efl::eolian::to_c(part_), cur_));
            return _tmp_ret;
      }

      virtual void part_text_input_panel_layout_set(::efl::eina::string_view part_, Edje_Input_Panel_Layout layout_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_layout_set(::efl::eolian::to_c(part_), layout_));
      }

      virtual Edje_Input_Panel_Layout part_text_input_panel_layout_get(::efl::eina::string_view part_)
      {
         Edje_Input_Panel_Layout _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_input_panel_layout_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      virtual bool part_table_pack(::efl::eina::string_view part_, ::evas::object child_obj_, unsigned short col_, unsigned short row_, unsigned short colspan_, unsigned short rowspan_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_table_pack(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_obj_), col_, row_, colspan_, rowspan_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_input_panel_language_set(::efl::eina::string_view part_, Edje_Input_Panel_Lang lang_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_language_set(::efl::eolian::to_c(part_), lang_));
      }

      virtual Edje_Input_Panel_Lang part_text_input_panel_language_get(::efl::eina::string_view part_)
      {
         Edje_Input_Panel_Lang _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_input_panel_language_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      virtual bool part_table_col_row_size_get(::efl::eina::string_view part_, int* cols_, int* rows_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_table_col_row_size_get(::efl::eolian::to_c(part_), cols_, rows_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual ::evas::object part_external_object_get(::efl::eina::string_view part_)
      {
         Evas_Object * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_external_object_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual ::evas::object part_external_content_get(::efl::eina::string_view part_, const char* content_)
      {
         Evas_Object * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_external_content_get(::efl::eolian::to_c(part_), content_));
            return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool preload(bool cancel_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_preload(::efl::eolian::to_c(cancel_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_input_panel_enabled_set(::efl::eina::string_view part_, bool enabled_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_enabled_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(enabled_)));
      }

      virtual bool part_text_input_panel_enabled_get(::efl::eina::string_view part_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_input_panel_enabled_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_select_extend(::efl::eina::string_view part_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_select_extend(::efl::eolian::to_c(part_)));
      }

      virtual bool part_box_insert_at(::efl::eina::string_view part_, ::evas::object child_, unsigned int pos_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_box_insert_at(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_), pos_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual ::efl::eina::crange_list< const Evas_Textblock_Rectangle * > part_text_anchor_geometry_get(::efl::eina::string_view part_, ::efl::eina::string_view anchor_)
      {
         const Eina_List * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_anchor_geometry_get(::efl::eolian::to_c(part_), ::efl::eolian::to_c(anchor_)));
            return ::efl::eolian::to_cxx<::efl::eina::crange_list< const Evas_Textblock_Rectangle * >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
      }

      virtual bool part_text_cursor_down(::efl::eina::string_view part_, Edje_Cursor cur_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_cursor_down(::efl::eolian::to_c(part_), cur_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_drag_page_set(::efl::eina::string_view part_, double dx_, double dy_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_page_set(::efl::eolian::to_c(part_), dx_, dy_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_drag_page_get(::efl::eina::string_view part_, double* dx_, double* dy_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_page_get(::efl::eolian::to_c(part_), dx_, dy_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_box_prepend(::efl::eina::string_view part_, ::evas::object child_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_box_prepend(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void signal_emit(::efl::eina::string_view emission_, ::efl::eina::string_view source_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_signal_emit(::efl::eolian::to_c(emission_), ::efl::eolian::to_c(source_)));
      }

      virtual void part_text_input_panel_layout_variation_set(::efl::eina::string_view part_, int variation_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_layout_variation_set(::efl::eolian::to_c(part_), variation_));
      }

      virtual int part_text_input_panel_layout_variation_get(::efl::eina::string_view part_)
      {
         int _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_input_panel_layout_variation_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      virtual void message_send(Edje_Message_Type type_, int id_, void * msg_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_message_send(type_, id_, msg_));
      }

      virtual void part_text_select_none(::efl::eina::string_view part_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_select_none(::efl::eolian::to_c(part_)));
      }

      virtual const Evas_Object * part_object_get(::efl::eina::string_view part_)
      {
         const Evas_Object * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_object_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      virtual bool part_drag_size_set(::efl::eina::string_view part_, double dw_, double dh_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_size_set(::efl::eolian::to_c(part_), dw_, dh_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_drag_size_get(::efl::eina::string_view part_, double* dw_, double* dh_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_size_get(::efl::eolian::to_c(part_), dw_, dh_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void * text_insert_filter_callback_del(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_)
      {
         void * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_text_insert_filter_callback_del(::efl::eolian::to_c(part_), func_));
            return _tmp_ret;
      }

      virtual Edje_Drag_Dir part_drag_dir_get(::efl::eina::string_view part_)
      {
         Edje_Drag_Dir _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_dir_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      virtual bool part_text_unescaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_to_escape_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_unescaped_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_to_escape_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual char * part_text_unescaped_get(::efl::eina::string_view part_)
      {
         char * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_unescaped_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      template <typename F_func_>
      void signal_callback_add(::efl::eina::string_view emission_, ::efl::eina::string_view source_, F_func_ && func_)
      {
         typedef typename std::remove_reference<F_func_>::type _no_ref_F_func_;
         _no_ref_F_func_* _tmp_func_ = new _no_ref_F_func_(std::forward< F_func_ >(func_));
         eo_do(dynamic_cast<T*>(this)->_eo_ptr(), eo_event_callback_add(EO_EV_DEL, &::efl::eolian::free_callback_calback<_no_ref_F_func_>, _tmp_func_));


         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_signal_callback_add(::efl::eolian::to_c(emission_), ::efl::eolian::to_c(source_), ::efl::eolian::get_callback<Edje_Signal_Cb, _no_ref_F_func_ >(), _tmp_func_));
      }

      virtual void part_text_select_all(::efl::eina::string_view part_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_select_all(::efl::eolian::to_c(part_)));
      }

      virtual void part_text_input_panel_return_key_disabled_set(::efl::eina::string_view part_, bool disabled_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_return_key_disabled_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(disabled_)));
      }

      virtual bool part_text_input_panel_return_key_disabled_get(::efl::eina::string_view part_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_input_panel_return_key_disabled_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_autocapital_type_set(::efl::eina::string_view part_, Edje_Text_Autocapital_Type autocapital_type_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_autocapital_type_set(::efl::eolian::to_c(part_), autocapital_type_));
      }

      virtual Edje_Text_Autocapital_Type part_text_autocapital_type_get(::efl::eina::string_view part_)
      {
         Edje_Text_Autocapital_Type _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_autocapital_type_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      virtual void part_unswallow(::evas::object obj_swallow_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_unswallow(::efl::eolian::to_c(obj_swallow_)));
      }

      virtual void part_text_prediction_allow_set(::efl::eina::string_view part_, bool prediction_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_prediction_allow_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(prediction_)));
      }

      virtual bool part_text_prediction_allow_get(::efl::eina::string_view part_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_prediction_allow_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual ::efl::eina::string_view data_get(::efl::eina::string_view key_)
      {
         const char * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_data_get(::efl::eolian::to_c(key_)));
            return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void text_markup_filter_callback_add(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_, void * data_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_text_markup_filter_callback_add(::efl::eolian::to_c(part_), func_, data_));
      }

      virtual void message_signal_process()
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_message_signal_process());
      }

      virtual ::evas::object part_box_remove(::efl::eina::string_view part_, ::evas::object child_)
      {
         Evas_Object * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_box_remove(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_)));
            return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual int thaw()
      {
         int _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_thaw());
            return _tmp_ret;
      }

      virtual ::evas::object part_swallow_get(::efl::eina::string_view part_)
      {
         Evas_Object * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_swallow_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_imf_context_reset(::efl::eina::string_view part_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_imf_context_reset(::efl::eolian::to_c(part_)));
      }

      virtual void part_text_input_panel_return_key_type_set(::efl::eina::string_view part_, Edje_Input_Panel_Return_Key_Type return_key_type_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_return_key_type_set(::efl::eolian::to_c(part_), return_key_type_));
      }

      virtual Edje_Input_Panel_Return_Key_Type part_text_input_panel_return_key_type_get(::efl::eina::string_view part_)
      {
         Edje_Input_Panel_Return_Key_Type _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_input_panel_return_key_type_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      virtual ::evas::object part_table_child_get(::efl::eina::string_view part_, unsigned int col_, unsigned int row_)
      {
         Evas_Object * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_table_child_get(::efl::eolian::to_c(part_), col_, row_));
            return ::efl::eolian::to_cxx<::evas::object>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_box_insert_before(::efl::eina::string_view part_, ::evas::object child_, const Evas_Object * reference_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_box_insert_before(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_), reference_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_external_param_set(::efl::eina::string_view part_, const Edje_External_Param * param_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_external_param_set(::efl::eolian::to_c(part_), param_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_external_param_get(::efl::eina::string_view part_, Edje_External_Param* param_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_external_param_get(::efl::eolian::to_c(part_), param_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void size_min_calc(Evas_Coord* minw_, Evas_Coord* minh_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_size_min_calc(minw_, minh_));
      }

      virtual bool part_box_append(::efl::eina::string_view part_, ::evas::object child_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_box_append(::efl::eolian::to_c(part_), ::efl::eolian::to_c(child_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void size_min_restricted_calc(Evas_Coord* minw_, Evas_Coord* minh_, Evas_Coord restrictedw_, Evas_Coord restrictedh_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_size_min_restricted_calc(minw_, minh_, restrictedw_, restrictedh_));
      }

      virtual bool part_box_remove_all(::efl::eina::string_view part_, bool clear_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_box_remove_all(::efl::eolian::to_c(part_), ::efl::eolian::to_c(clear_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_drag_page(::efl::eina::string_view part_, double dx_, double dy_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_page(::efl::eolian::to_c(part_), dx_, dy_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_text_set(::efl::eina::string_view part_, ::efl::eina::string_view text_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual ::efl::eina::string_view part_text_get(::efl::eina::string_view part_)
      {
         const char * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_input_panel_show_on_demand_set(::efl::eina::string_view part_, bool ondemand_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_show_on_demand_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(ondemand_)));
      }

      virtual bool part_text_input_panel_show_on_demand_get(::efl::eina::string_view part_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_input_panel_show_on_demand_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_input_hint_set(::efl::eina::string_view part_, Edje_Input_Hints input_hints_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_hint_set(::efl::eolian::to_c(part_), input_hints_));
      }

      virtual Edje_Input_Hints part_text_input_hint_get(::efl::eina::string_view part_)
      {
         Edje_Input_Hints _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_input_hint_get(::efl::eolian::to_c(part_)));
            return _tmp_ret;
      }

      virtual ::efl::eina::string_view part_text_selection_get(::efl::eina::string_view part_)
      {
         const char * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_selection_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_text_cursor_is_format_get(::efl::eina::string_view part_, Edje_Cursor cur_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_cursor_is_format_get(::efl::eolian::to_c(part_), cur_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool text_class_get(::efl::eina::string_view text_class_, const char ** font_, Evas_Font_Size* size_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_text_class_get(::efl::eolian::to_c(text_class_), font_, size_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool color_class_set(::efl::eina::string_view color_class_, int r_, int g_, int b_, int a_, int r2_, int g2_, int b2_, int a2_, int r3_, int g3_, int b3_, int a3_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_color_class_set(::efl::eolian::to_c(color_class_), r_, g_, b_, a_, r2_, g2_, b2_, a2_, r3_, g3_, b3_, a3_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool color_class_get(::efl::eina::string_view color_class_, int* r_, int* g_, int* b_, int* a_, int* r2_, int* g2_, int* b2_, int* a2_, int* r3_, int* g3_, int* b3_, int* a3_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_color_class_get(::efl::eolian::to_c(color_class_), r_, g_, b_, a_, r2_, g2_, b2_, a2_, r3_, g3_, b3_, a3_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual ::efl::eina::string_view color_class_description_get(::efl::eina::string_view color_class_)
      {
         const char * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_color_class_description_get(::efl::eolian::to_c(color_class_)));
            return ::efl::eolian::to_cxx<::efl::eina::string_view>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_drag_step(::efl::eina::string_view part_, double dx_, double dy_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_drag_step(::efl::eolian::to_c(part_), dx_, dy_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_text_cursor_up(::efl::eina::string_view part_, Edje_Cursor cur_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_cursor_up(::efl::eolian::to_c(part_), cur_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_cursor_geometry_get(::efl::eina::string_view part_, Evas_Coord* x_, Evas_Coord* y_, Evas_Coord* w_, Evas_Coord* h_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_cursor_geometry_get(::efl::eolian::to_c(part_), x_, y_, w_, h_));
      }

      virtual ::efl::eina::crange_list< ::efl::eina::string_view > part_text_anchor_list_get(::efl::eina::string_view part_)
      {
         const Eina_List * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_anchor_list_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<::efl::eina::crange_list< ::efl::eina::string_view >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
      }

      virtual void text_insert_filter_callback_add(::efl::eina::string_view part_, Edje_Text_Filter_Cb func_, void * data_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_text_insert_filter_callback_add(::efl::eolian::to_c(part_), func_, data_));
      }

      virtual void part_text_input_panel_show(::efl::eina::string_view part_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_input_panel_show(::efl::eolian::to_c(part_)));
      }

      virtual bool part_exists(::efl::eina::string_view part_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_exists(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void * text_markup_filter_callback_del(::efl::eina::string_view part_, Edje_Markup_Filter_Cb func_)
      {
         void * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_text_markup_filter_callback_del(::efl::eolian::to_c(part_), func_));
            return _tmp_ret;
      }

      virtual bool part_text_cursor_is_visible_format_get(::efl::eina::string_view part_, Edje_Cursor cur_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_cursor_is_visible_format_get(::efl::eolian::to_c(part_), cur_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_user_insert(::efl::eina::string_view part_, ::efl::eina::string_view text_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_user_insert(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
      }

      virtual bool part_text_cursor_prev(::efl::eina::string_view part_, Edje_Cursor cur_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_cursor_prev(::efl::eolian::to_c(part_), cur_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual ::efl::eina::crange_list< ::efl::eina::string_view > part_text_item_list_get(::efl::eina::string_view part_)
      {
         const Eina_List * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_item_list_get(::efl::eolian::to_c(part_)));
            return ::efl::eolian::to_cxx<::efl::eina::crange_list< ::efl::eina::string_view >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
      }

      virtual bool part_swallow(::efl::eina::string_view part_, ::evas::object obj_swallow_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_swallow(::efl::eolian::to_c(part_), ::efl::eolian::to_c(obj_swallow_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool update_hints_get()
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_update_hints_get());
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void update_hints_set(bool update_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_update_hints_set(::efl::eolian::to_c(update_)));
      }

      virtual bool mirrored_get()
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_mirrored_get());
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void mirrored_set(bool rtl_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_mirrored_set(::efl::eolian::to_c(rtl_)));
      }

      virtual bool animation_get()
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_animation_get());
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void animation_set(bool on_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_animation_set(::efl::eolian::to_c(on_)));
      }

      virtual bool play_get()
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_play_get());
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void play_set(bool play_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_play_set(::efl::eolian::to_c(play_)));
      }

      virtual const Edje_Perspective * perspective_get()
      {
         const Edje_Perspective * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_perspective_get());
            return _tmp_ret;
      }

      virtual void perspective_set(Edje_Perspective * ps_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_perspective_set(ps_));
      }

      virtual double scale_get()
      {
         double _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_scale_get());
            return _tmp_ret;
      }

      virtual bool scale_set(double scale_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_scale_set(scale_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual double base_scale_get()
      {
         double _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_base_scale_get());
            return _tmp_ret;
      }

      virtual void text_change_cb_set(Edje_Text_Change_Cb func_, void * data_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_text_change_cb_set(func_, data_));
      }

      virtual void part_text_cursor_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_cursor_begin_set(::efl::eolian::to_c(part_), cur_));
      }

      virtual void part_text_cursor_line_end_set(::efl::eina::string_view part_, Edje_Cursor cur_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_cursor_line_end_set(::efl::eolian::to_c(part_), cur_));
      }

      virtual bool text_class_set(::efl::eina::string_view text_class_, ::efl::eina::string_view font_, Evas_Font_Size size_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_text_class_set(::efl::eolian::to_c(text_class_), ::efl::eolian::to_c(font_), size_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual bool part_text_cursor_coord_set(::efl::eina::string_view part_, Edje_Cursor cur_, Evas_Coord x_, Evas_Coord y_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_cursor_coord_set(::efl::eolian::to_c(part_), cur_, x_, y_));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void part_text_cursor_end_set(::efl::eina::string_view part_, Edje_Cursor cur_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_cursor_end_set(::efl::eolian::to_c(part_), cur_));
      }

      virtual bool part_text_escaped_set(::efl::eina::string_view part_, ::efl::eina::string_view text_)
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_part_text_escaped_set(::efl::eolian::to_c(part_), ::efl::eolian::to_c(text_)));
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void item_provider_set(Edje_Item_Provider_Cb func_, void * data_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_item_provider_set(func_, data_));
      }

      virtual void part_text_cursor_line_begin_set(::efl::eina::string_view part_, Edje_Cursor cur_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_part_text_cursor_line_begin_set(::efl::eolian::to_c(part_), cur_));
      }

      virtual void message_handler_set(Edje_Message_Handler_Cb func_, void * data_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_message_handler_set(func_, data_));
      }

      virtual void size_min_get(Evas_Coord* minw_, Evas_Coord* minh_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_size_min_get(minw_, minh_));
      }

      virtual ::efl::eina::range_list< ::efl::eina::string_view > access_part_list_get()
      {
         Eina_List * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_access_part_list_get());
            return ::efl::eolian::to_cxx<::efl::eina::range_list< ::efl::eina::string_view >>(_tmp_ret, std::tuple<std::false_type, std::false_type>());
      }

      virtual Edje_Load_Error load_error_get()
      {
         Edje_Load_Error _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::edje_obj_load_error_get());
            return _tmp_ret;
      }

      virtual void size_max_get(Evas_Coord* maxw_, Evas_Coord* maxh_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::edje_obj_size_max_get(maxw_, maxh_));
      }

   };
};


#ifdef OBJECT_PROTECTED
template<>
struct operation_description_class_size< ::edje::object >
{
   static constexpr int value = 143 + operation_description_class_size<::evas::smart_clipped >::value + operation_description_class_size<::efl::file >::value;
};

#else
template<>
struct operation_description_class_size< ::edje::object >
{
   static constexpr int value = 143 + operation_description_class_size<::evas::smart_clipped >::value + operation_description_class_size<::efl::file >::value;
};

#endif

template <typename T>
int initialize_operation_description(::efl::eo::detail::tag<::edje::object>
                                 , Eo_Op_Description* ops)
{
   (void)ops;
   ops[0].func = reinterpret_cast<void*>(& ::edje_object_part_table_clear_wrapper<T>);
   ops[0].api_func = reinterpret_cast<void*>(& ::edje_obj_part_table_clear);
   ops[0].op = EO_OP_OVERRIDE;
   ops[0].op_type = EO_OP_TYPE_REGULAR;
   ops[0].doc = NULL;

   ops[1].func = reinterpret_cast<void*>(& ::edje_object_part_external_param_type_get_wrapper<T>);
   ops[1].api_func = reinterpret_cast<void*>(& ::edje_obj_part_external_param_type_get);
   ops[1].op = EO_OP_OVERRIDE;
   ops[1].op_type = EO_OP_TYPE_REGULAR;
   ops[1].doc = NULL;

   ops[2].func = reinterpret_cast<void*>(& ::edje_object_part_text_select_allow_set_wrapper<T>);
   ops[2].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_select_allow_set);
   ops[2].op = EO_OP_OVERRIDE;
   ops[2].op_type = EO_OP_TYPE_REGULAR;
   ops[2].doc = NULL;

   ops[3].func = reinterpret_cast<void*>(& ::edje_object_part_state_get_wrapper<T>);
   ops[3].api_func = reinterpret_cast<void*>(& ::edje_obj_part_state_get);
   ops[3].op = EO_OP_OVERRIDE;
   ops[3].op_type = EO_OP_TYPE_REGULAR;
   ops[3].doc = NULL;

   ops[4].func = reinterpret_cast<void*>(& ::edje_object_text_markup_filter_callback_del_full_wrapper<T>);
   ops[4].api_func = reinterpret_cast<void*>(& ::edje_obj_text_markup_filter_callback_del_full);
   ops[4].op = EO_OP_OVERRIDE;
   ops[4].op_type = EO_OP_TYPE_REGULAR;
   ops[4].doc = NULL;

   ops[5].func = reinterpret_cast<void*>(& ::edje_object_part_drag_step_set_wrapper<T>);
   ops[5].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_step_set);
   ops[5].op = EO_OP_OVERRIDE;
   ops[5].op_type = EO_OP_TYPE_REGULAR;
   ops[5].doc = NULL;

   ops[6].func = reinterpret_cast<void*>(& ::edje_object_part_drag_step_get_wrapper<T>);
   ops[6].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_step_get);
   ops[6].op = EO_OP_OVERRIDE;
   ops[6].op_type = EO_OP_TYPE_REGULAR;
   ops[6].doc = NULL;

   ops[7].func = reinterpret_cast<void*>(& ::edje_object_part_text_imf_context_get_wrapper<T>);
   ops[7].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_imf_context_get);
   ops[7].op = EO_OP_OVERRIDE;
   ops[7].op_type = EO_OP_TYPE_REGULAR;
   ops[7].doc = NULL;

   ops[8].func = reinterpret_cast<void*>(& ::edje_object_part_text_select_begin_wrapper<T>);
   ops[8].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_select_begin);
   ops[8].op = EO_OP_OVERRIDE;
   ops[8].op_type = EO_OP_TYPE_REGULAR;
   ops[8].doc = NULL;

   ops[9].func = reinterpret_cast<void*>(& ::edje_object_part_text_style_user_peek_wrapper<T>);
   ops[9].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_style_user_peek);
   ops[9].op = EO_OP_OVERRIDE;
   ops[9].op_type = EO_OP_TYPE_REGULAR;
   ops[9].doc = NULL;

   ops[10].func = reinterpret_cast<void*>(& ::edje_object_signal_callback_del_wrapper<T>);
   ops[10].api_func = reinterpret_cast<void*>(& ::edje_obj_signal_callback_del);
   ops[10].op = EO_OP_OVERRIDE;
   ops[10].op_type = EO_OP_TYPE_REGULAR;
   ops[10].doc = NULL;

   ops[11].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_next_wrapper<T>);
   ops[11].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_next);
   ops[11].op = EO_OP_OVERRIDE;
   ops[11].op_type = EO_OP_TYPE_REGULAR;
   ops[11].doc = NULL;

   ops[12].func = reinterpret_cast<void*>(& ::edje_object_part_text_style_user_push_wrapper<T>);
   ops[12].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_style_user_push);
   ops[12].op = EO_OP_OVERRIDE;
   ops[12].op_type = EO_OP_TYPE_REGULAR;
   ops[12].doc = NULL;

   ops[13].func = reinterpret_cast<void*>(& ::edje_object_part_text_append_wrapper<T>);
   ops[13].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_append);
   ops[13].op = EO_OP_OVERRIDE;
   ops[13].op_type = EO_OP_TYPE_REGULAR;
   ops[13].doc = NULL;

   ops[14].func = reinterpret_cast<void*>(& ::edje_object_part_geometry_get_wrapper<T>);
   ops[14].api_func = reinterpret_cast<void*>(& ::edje_obj_part_geometry_get);
   ops[14].op = EO_OP_OVERRIDE;
   ops[14].op_type = EO_OP_TYPE_REGULAR;
   ops[14].doc = NULL;

   ops[15].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_hide_wrapper<T>);
   ops[15].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_hide);
   ops[15].op = EO_OP_OVERRIDE;
   ops[15].op_type = EO_OP_TYPE_REGULAR;
   ops[15].doc = NULL;

   ops[16].func = reinterpret_cast<void*>(& ::edje_object_part_text_item_geometry_get_wrapper<T>);
   ops[16].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_item_geometry_get);
   ops[16].op = EO_OP_OVERRIDE;
   ops[16].op_type = EO_OP_TYPE_REGULAR;
   ops[16].doc = NULL;

   ops[17].func = reinterpret_cast<void*>(& ::edje_object_part_table_unpack_wrapper<T>);
   ops[17].api_func = reinterpret_cast<void*>(& ::edje_obj_part_table_unpack);
   ops[17].op = EO_OP_OVERRIDE;
   ops[17].op_type = EO_OP_TYPE_REGULAR;
   ops[17].doc = NULL;

   ops[18].func = reinterpret_cast<void*>(& ::edje_object_part_text_select_abort_wrapper<T>);
   ops[18].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_select_abort);
   ops[18].op = EO_OP_OVERRIDE;
   ops[18].op_type = EO_OP_TYPE_REGULAR;
   ops[18].doc = NULL;

   ops[19].func = reinterpret_cast<void*>(& ::edje_object_text_insert_filter_callback_del_full_wrapper<T>);
   ops[19].api_func = reinterpret_cast<void*>(& ::edje_obj_text_insert_filter_callback_del_full);
   ops[19].op = EO_OP_OVERRIDE;
   ops[19].op_type = EO_OP_TYPE_REGULAR;
   ops[19].doc = NULL;

   ops[20].func = reinterpret_cast<void*>(& ::edje_object_part_text_style_user_pop_wrapper<T>);
   ops[20].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_style_user_pop);
   ops[20].op = EO_OP_OVERRIDE;
   ops[20].op_type = EO_OP_TYPE_REGULAR;
   ops[20].doc = NULL;

   ops[21].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_imdata_set_wrapper<T>);
   ops[21].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_imdata_set);
   ops[21].op = EO_OP_OVERRIDE;
   ops[21].op_type = EO_OP_TYPE_REGULAR;
   ops[21].doc = NULL;

   ops[22].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_imdata_get_wrapper<T>);
   ops[22].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_imdata_get);
   ops[22].op = EO_OP_OVERRIDE;
   ops[22].op_type = EO_OP_TYPE_REGULAR;
   ops[22].doc = NULL;

   ops[23].func = reinterpret_cast<void*>(& ::edje_object_part_text_insert_wrapper<T>);
   ops[23].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_insert);
   ops[23].op = EO_OP_OVERRIDE;
   ops[23].op_type = EO_OP_TYPE_REGULAR;
   ops[23].doc = NULL;

   ops[24].func = reinterpret_cast<void*>(& ::edje_object_part_box_remove_at_wrapper<T>);
   ops[24].api_func = reinterpret_cast<void*>(& ::edje_obj_part_box_remove_at);
   ops[24].op = EO_OP_OVERRIDE;
   ops[24].op_type = EO_OP_TYPE_REGULAR;
   ops[24].doc = NULL;

   ops[25].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_copy_wrapper<T>);
   ops[25].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_copy);
   ops[25].op = EO_OP_OVERRIDE;
   ops[25].op_type = EO_OP_TYPE_REGULAR;
   ops[25].doc = NULL;

   ops[26].func = reinterpret_cast<void*>(& ::edje_object_parts_extends_calc_wrapper<T>);
   ops[26].api_func = reinterpret_cast<void*>(& ::edje_obj_parts_extends_calc);
   ops[26].op = EO_OP_OVERRIDE;
   ops[26].op_type = EO_OP_TYPE_REGULAR;
   ops[26].doc = NULL;

   ops[27].func = reinterpret_cast<void*>(& ::edje_object_part_drag_value_set_wrapper<T>);
   ops[27].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_value_set);
   ops[27].op = EO_OP_OVERRIDE;
   ops[27].op_type = EO_OP_TYPE_REGULAR;
   ops[27].doc = NULL;

   ops[28].func = reinterpret_cast<void*>(& ::edje_object_part_drag_value_get_wrapper<T>);
   ops[28].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_value_get);
   ops[28].op = EO_OP_OVERRIDE;
   ops[28].op_type = EO_OP_TYPE_REGULAR;
   ops[28].doc = NULL;

   ops[29].func = reinterpret_cast<void*>(& ::edje_object_calc_force_wrapper<T>);
   ops[29].api_func = reinterpret_cast<void*>(& ::edje_obj_calc_force);
   ops[29].op = EO_OP_OVERRIDE;
   ops[29].op_type = EO_OP_TYPE_REGULAR;
   ops[29].doc = NULL;

   ops[30].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_pos_set_wrapper<T>);
   ops[30].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_pos_set);
   ops[30].op = EO_OP_OVERRIDE;
   ops[30].op_type = EO_OP_TYPE_REGULAR;
   ops[30].doc = NULL;

   ops[31].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_pos_get_wrapper<T>);
   ops[31].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_pos_get);
   ops[31].op = EO_OP_OVERRIDE;
   ops[31].op_type = EO_OP_TYPE_REGULAR;
   ops[31].doc = NULL;

   ops[32].func = reinterpret_cast<void*>(& ::edje_object_freeze_wrapper<T>);
   ops[32].api_func = reinterpret_cast<void*>(& ::edje_obj_freeze);
   ops[32].op = EO_OP_OVERRIDE;
   ops[32].op_type = EO_OP_TYPE_REGULAR;
   ops[32].doc = NULL;

   ops[33].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_content_get_wrapper<T>);
   ops[33].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_content_get);
   ops[33].op = EO_OP_OVERRIDE;
   ops[33].op_type = EO_OP_TYPE_REGULAR;
   ops[33].doc = NULL;

   ops[34].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_layout_set_wrapper<T>);
   ops[34].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_layout_set);
   ops[34].op = EO_OP_OVERRIDE;
   ops[34].op_type = EO_OP_TYPE_REGULAR;
   ops[34].doc = NULL;

   ops[35].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_layout_get_wrapper<T>);
   ops[35].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_layout_get);
   ops[35].op = EO_OP_OVERRIDE;
   ops[35].op_type = EO_OP_TYPE_REGULAR;
   ops[35].doc = NULL;

   ops[36].func = reinterpret_cast<void*>(& ::edje_object_part_table_pack_wrapper<T>);
   ops[36].api_func = reinterpret_cast<void*>(& ::edje_obj_part_table_pack);
   ops[36].op = EO_OP_OVERRIDE;
   ops[36].op_type = EO_OP_TYPE_REGULAR;
   ops[36].doc = NULL;

   ops[37].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_language_set_wrapper<T>);
   ops[37].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_language_set);
   ops[37].op = EO_OP_OVERRIDE;
   ops[37].op_type = EO_OP_TYPE_REGULAR;
   ops[37].doc = NULL;

   ops[38].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_language_get_wrapper<T>);
   ops[38].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_language_get);
   ops[38].op = EO_OP_OVERRIDE;
   ops[38].op_type = EO_OP_TYPE_REGULAR;
   ops[38].doc = NULL;

   ops[39].func = reinterpret_cast<void*>(& ::edje_object_part_table_col_row_size_get_wrapper<T>);
   ops[39].api_func = reinterpret_cast<void*>(& ::edje_obj_part_table_col_row_size_get);
   ops[39].op = EO_OP_OVERRIDE;
   ops[39].op_type = EO_OP_TYPE_REGULAR;
   ops[39].doc = NULL;

   ops[40].func = reinterpret_cast<void*>(& ::edje_object_part_external_object_get_wrapper<T>);
   ops[40].api_func = reinterpret_cast<void*>(& ::edje_obj_part_external_object_get);
   ops[40].op = EO_OP_OVERRIDE;
   ops[40].op_type = EO_OP_TYPE_REGULAR;
   ops[40].doc = NULL;

   ops[41].func = reinterpret_cast<void*>(& ::edje_object_part_external_content_get_wrapper<T>);
   ops[41].api_func = reinterpret_cast<void*>(& ::edje_obj_part_external_content_get);
   ops[41].op = EO_OP_OVERRIDE;
   ops[41].op_type = EO_OP_TYPE_REGULAR;
   ops[41].doc = NULL;

   ops[42].func = reinterpret_cast<void*>(& ::edje_object_preload_wrapper<T>);
   ops[42].api_func = reinterpret_cast<void*>(& ::edje_obj_preload);
   ops[42].op = EO_OP_OVERRIDE;
   ops[42].op_type = EO_OP_TYPE_REGULAR;
   ops[42].doc = NULL;

   ops[43].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_enabled_set_wrapper<T>);
   ops[43].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_enabled_set);
   ops[43].op = EO_OP_OVERRIDE;
   ops[43].op_type = EO_OP_TYPE_REGULAR;
   ops[43].doc = NULL;

   ops[44].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_enabled_get_wrapper<T>);
   ops[44].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_enabled_get);
   ops[44].op = EO_OP_OVERRIDE;
   ops[44].op_type = EO_OP_TYPE_REGULAR;
   ops[44].doc = NULL;

   ops[45].func = reinterpret_cast<void*>(& ::edje_object_part_text_select_extend_wrapper<T>);
   ops[45].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_select_extend);
   ops[45].op = EO_OP_OVERRIDE;
   ops[45].op_type = EO_OP_TYPE_REGULAR;
   ops[45].doc = NULL;

   ops[46].func = reinterpret_cast<void*>(& ::edje_object_part_box_insert_at_wrapper<T>);
   ops[46].api_func = reinterpret_cast<void*>(& ::edje_obj_part_box_insert_at);
   ops[46].op = EO_OP_OVERRIDE;
   ops[46].op_type = EO_OP_TYPE_REGULAR;
   ops[46].doc = NULL;

   ops[47].func = reinterpret_cast<void*>(& ::edje_object_part_text_anchor_geometry_get_wrapper<T>);
   ops[47].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_anchor_geometry_get);
   ops[47].op = EO_OP_OVERRIDE;
   ops[47].op_type = EO_OP_TYPE_REGULAR;
   ops[47].doc = NULL;

   ops[48].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_down_wrapper<T>);
   ops[48].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_down);
   ops[48].op = EO_OP_OVERRIDE;
   ops[48].op_type = EO_OP_TYPE_REGULAR;
   ops[48].doc = NULL;

   ops[49].func = reinterpret_cast<void*>(& ::edje_object_part_drag_page_set_wrapper<T>);
   ops[49].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_page_set);
   ops[49].op = EO_OP_OVERRIDE;
   ops[49].op_type = EO_OP_TYPE_REGULAR;
   ops[49].doc = NULL;

   ops[50].func = reinterpret_cast<void*>(& ::edje_object_part_drag_page_get_wrapper<T>);
   ops[50].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_page_get);
   ops[50].op = EO_OP_OVERRIDE;
   ops[50].op_type = EO_OP_TYPE_REGULAR;
   ops[50].doc = NULL;

   ops[51].func = reinterpret_cast<void*>(& ::edje_object_part_box_prepend_wrapper<T>);
   ops[51].api_func = reinterpret_cast<void*>(& ::edje_obj_part_box_prepend);
   ops[51].op = EO_OP_OVERRIDE;
   ops[51].op_type = EO_OP_TYPE_REGULAR;
   ops[51].doc = NULL;

   ops[52].func = reinterpret_cast<void*>(& ::edje_object_signal_emit_wrapper<T>);
   ops[52].api_func = reinterpret_cast<void*>(& ::edje_obj_signal_emit);
   ops[52].op = EO_OP_OVERRIDE;
   ops[52].op_type = EO_OP_TYPE_REGULAR;
   ops[52].doc = NULL;

   ops[53].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_layout_variation_set_wrapper<T>);
   ops[53].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_layout_variation_set);
   ops[53].op = EO_OP_OVERRIDE;
   ops[53].op_type = EO_OP_TYPE_REGULAR;
   ops[53].doc = NULL;

   ops[54].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_layout_variation_get_wrapper<T>);
   ops[54].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_layout_variation_get);
   ops[54].op = EO_OP_OVERRIDE;
   ops[54].op_type = EO_OP_TYPE_REGULAR;
   ops[54].doc = NULL;

   ops[55].func = reinterpret_cast<void*>(& ::edje_object_message_send_wrapper<T>);
   ops[55].api_func = reinterpret_cast<void*>(& ::edje_obj_message_send);
   ops[55].op = EO_OP_OVERRIDE;
   ops[55].op_type = EO_OP_TYPE_REGULAR;
   ops[55].doc = NULL;

   ops[56].func = reinterpret_cast<void*>(& ::edje_object_part_text_select_none_wrapper<T>);
   ops[56].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_select_none);
   ops[56].op = EO_OP_OVERRIDE;
   ops[56].op_type = EO_OP_TYPE_REGULAR;
   ops[56].doc = NULL;

   ops[57].func = reinterpret_cast<void*>(& ::edje_object_part_object_get_wrapper<T>);
   ops[57].api_func = reinterpret_cast<void*>(& ::edje_obj_part_object_get);
   ops[57].op = EO_OP_OVERRIDE;
   ops[57].op_type = EO_OP_TYPE_REGULAR;
   ops[57].doc = NULL;

   ops[58].func = reinterpret_cast<void*>(& ::edje_object_part_drag_size_set_wrapper<T>);
   ops[58].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_size_set);
   ops[58].op = EO_OP_OVERRIDE;
   ops[58].op_type = EO_OP_TYPE_REGULAR;
   ops[58].doc = NULL;

   ops[59].func = reinterpret_cast<void*>(& ::edje_object_part_drag_size_get_wrapper<T>);
   ops[59].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_size_get);
   ops[59].op = EO_OP_OVERRIDE;
   ops[59].op_type = EO_OP_TYPE_REGULAR;
   ops[59].doc = NULL;

   ops[60].func = reinterpret_cast<void*>(& ::edje_object_text_insert_filter_callback_del_wrapper<T>);
   ops[60].api_func = reinterpret_cast<void*>(& ::edje_obj_text_insert_filter_callback_del);
   ops[60].op = EO_OP_OVERRIDE;
   ops[60].op_type = EO_OP_TYPE_REGULAR;
   ops[60].doc = NULL;

   ops[61].func = reinterpret_cast<void*>(& ::edje_object_part_drag_dir_get_wrapper<T>);
   ops[61].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_dir_get);
   ops[61].op = EO_OP_OVERRIDE;
   ops[61].op_type = EO_OP_TYPE_REGULAR;
   ops[61].doc = NULL;

   ops[62].func = reinterpret_cast<void*>(& ::edje_object_part_text_unescaped_set_wrapper<T>);
   ops[62].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_unescaped_set);
   ops[62].op = EO_OP_OVERRIDE;
   ops[62].op_type = EO_OP_TYPE_REGULAR;
   ops[62].doc = NULL;

   ops[63].func = reinterpret_cast<void*>(& ::edje_object_part_text_unescaped_get_wrapper<T>);
   ops[63].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_unescaped_get);
   ops[63].op = EO_OP_OVERRIDE;
   ops[63].op_type = EO_OP_TYPE_REGULAR;
   ops[63].doc = NULL;

   ops[64].func = reinterpret_cast<void*>(& ::edje_object_signal_callback_add_wrapper<T>);
   ops[64].api_func = reinterpret_cast<void*>(& ::edje_obj_signal_callback_add);
   ops[64].op = EO_OP_OVERRIDE;
   ops[64].op_type = EO_OP_TYPE_REGULAR;
   ops[64].doc = NULL;

   ops[65].func = reinterpret_cast<void*>(& ::edje_object_part_text_select_all_wrapper<T>);
   ops[65].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_select_all);
   ops[65].op = EO_OP_OVERRIDE;
   ops[65].op_type = EO_OP_TYPE_REGULAR;
   ops[65].doc = NULL;

   ops[66].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_return_key_disabled_set_wrapper<T>);
   ops[66].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_return_key_disabled_set);
   ops[66].op = EO_OP_OVERRIDE;
   ops[66].op_type = EO_OP_TYPE_REGULAR;
   ops[66].doc = NULL;

   ops[67].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_return_key_disabled_get_wrapper<T>);
   ops[67].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_return_key_disabled_get);
   ops[67].op = EO_OP_OVERRIDE;
   ops[67].op_type = EO_OP_TYPE_REGULAR;
   ops[67].doc = NULL;

   ops[68].func = reinterpret_cast<void*>(& ::edje_object_part_text_autocapital_type_set_wrapper<T>);
   ops[68].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_autocapital_type_set);
   ops[68].op = EO_OP_OVERRIDE;
   ops[68].op_type = EO_OP_TYPE_REGULAR;
   ops[68].doc = NULL;

   ops[69].func = reinterpret_cast<void*>(& ::edje_object_part_text_autocapital_type_get_wrapper<T>);
   ops[69].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_autocapital_type_get);
   ops[69].op = EO_OP_OVERRIDE;
   ops[69].op_type = EO_OP_TYPE_REGULAR;
   ops[69].doc = NULL;

   ops[70].func = reinterpret_cast<void*>(& ::edje_object_part_unswallow_wrapper<T>);
   ops[70].api_func = reinterpret_cast<void*>(& ::edje_obj_part_unswallow);
   ops[70].op = EO_OP_OVERRIDE;
   ops[70].op_type = EO_OP_TYPE_REGULAR;
   ops[70].doc = NULL;

   ops[71].func = reinterpret_cast<void*>(& ::edje_object_part_text_prediction_allow_set_wrapper<T>);
   ops[71].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_prediction_allow_set);
   ops[71].op = EO_OP_OVERRIDE;
   ops[71].op_type = EO_OP_TYPE_REGULAR;
   ops[71].doc = NULL;

   ops[72].func = reinterpret_cast<void*>(& ::edje_object_part_text_prediction_allow_get_wrapper<T>);
   ops[72].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_prediction_allow_get);
   ops[72].op = EO_OP_OVERRIDE;
   ops[72].op_type = EO_OP_TYPE_REGULAR;
   ops[72].doc = NULL;

   ops[73].func = reinterpret_cast<void*>(& ::edje_object_data_get_wrapper<T>);
   ops[73].api_func = reinterpret_cast<void*>(& ::edje_obj_data_get);
   ops[73].op = EO_OP_OVERRIDE;
   ops[73].op_type = EO_OP_TYPE_REGULAR;
   ops[73].doc = NULL;

   ops[74].func = reinterpret_cast<void*>(& ::edje_object_text_markup_filter_callback_add_wrapper<T>);
   ops[74].api_func = reinterpret_cast<void*>(& ::edje_obj_text_markup_filter_callback_add);
   ops[74].op = EO_OP_OVERRIDE;
   ops[74].op_type = EO_OP_TYPE_REGULAR;
   ops[74].doc = NULL;

   ops[75].func = reinterpret_cast<void*>(& ::edje_object_message_signal_process_wrapper<T>);
   ops[75].api_func = reinterpret_cast<void*>(& ::edje_obj_message_signal_process);
   ops[75].op = EO_OP_OVERRIDE;
   ops[75].op_type = EO_OP_TYPE_REGULAR;
   ops[75].doc = NULL;

   ops[76].func = reinterpret_cast<void*>(& ::edje_object_part_box_remove_wrapper<T>);
   ops[76].api_func = reinterpret_cast<void*>(& ::edje_obj_part_box_remove);
   ops[76].op = EO_OP_OVERRIDE;
   ops[76].op_type = EO_OP_TYPE_REGULAR;
   ops[76].doc = NULL;

   ops[77].func = reinterpret_cast<void*>(& ::edje_object_thaw_wrapper<T>);
   ops[77].api_func = reinterpret_cast<void*>(& ::edje_obj_thaw);
   ops[77].op = EO_OP_OVERRIDE;
   ops[77].op_type = EO_OP_TYPE_REGULAR;
   ops[77].doc = NULL;

   ops[78].func = reinterpret_cast<void*>(& ::edje_object_part_swallow_get_wrapper<T>);
   ops[78].api_func = reinterpret_cast<void*>(& ::edje_obj_part_swallow_get);
   ops[78].op = EO_OP_OVERRIDE;
   ops[78].op_type = EO_OP_TYPE_REGULAR;
   ops[78].doc = NULL;

   ops[79].func = reinterpret_cast<void*>(& ::edje_object_part_text_imf_context_reset_wrapper<T>);
   ops[79].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_imf_context_reset);
   ops[79].op = EO_OP_OVERRIDE;
   ops[79].op_type = EO_OP_TYPE_REGULAR;
   ops[79].doc = NULL;

   ops[80].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_return_key_type_set_wrapper<T>);
   ops[80].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_return_key_type_set);
   ops[80].op = EO_OP_OVERRIDE;
   ops[80].op_type = EO_OP_TYPE_REGULAR;
   ops[80].doc = NULL;

   ops[81].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_return_key_type_get_wrapper<T>);
   ops[81].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_return_key_type_get);
   ops[81].op = EO_OP_OVERRIDE;
   ops[81].op_type = EO_OP_TYPE_REGULAR;
   ops[81].doc = NULL;

   ops[82].func = reinterpret_cast<void*>(& ::edje_object_part_table_child_get_wrapper<T>);
   ops[82].api_func = reinterpret_cast<void*>(& ::edje_obj_part_table_child_get);
   ops[82].op = EO_OP_OVERRIDE;
   ops[82].op_type = EO_OP_TYPE_REGULAR;
   ops[82].doc = NULL;

   ops[83].func = reinterpret_cast<void*>(& ::edje_object_part_box_insert_before_wrapper<T>);
   ops[83].api_func = reinterpret_cast<void*>(& ::edje_obj_part_box_insert_before);
   ops[83].op = EO_OP_OVERRIDE;
   ops[83].op_type = EO_OP_TYPE_REGULAR;
   ops[83].doc = NULL;

   ops[84].func = reinterpret_cast<void*>(& ::edje_object_part_external_param_set_wrapper<T>);
   ops[84].api_func = reinterpret_cast<void*>(& ::edje_obj_part_external_param_set);
   ops[84].op = EO_OP_OVERRIDE;
   ops[84].op_type = EO_OP_TYPE_REGULAR;
   ops[84].doc = NULL;

   ops[85].func = reinterpret_cast<void*>(& ::edje_object_part_external_param_get_wrapper<T>);
   ops[85].api_func = reinterpret_cast<void*>(& ::edje_obj_part_external_param_get);
   ops[85].op = EO_OP_OVERRIDE;
   ops[85].op_type = EO_OP_TYPE_REGULAR;
   ops[85].doc = NULL;

   ops[86].func = reinterpret_cast<void*>(& ::edje_object_size_min_calc_wrapper<T>);
   ops[86].api_func = reinterpret_cast<void*>(& ::edje_obj_size_min_calc);
   ops[86].op = EO_OP_OVERRIDE;
   ops[86].op_type = EO_OP_TYPE_REGULAR;
   ops[86].doc = NULL;

   ops[87].func = reinterpret_cast<void*>(& ::edje_object_part_box_append_wrapper<T>);
   ops[87].api_func = reinterpret_cast<void*>(& ::edje_obj_part_box_append);
   ops[87].op = EO_OP_OVERRIDE;
   ops[87].op_type = EO_OP_TYPE_REGULAR;
   ops[87].doc = NULL;

   ops[88].func = reinterpret_cast<void*>(& ::edje_object_size_min_restricted_calc_wrapper<T>);
   ops[88].api_func = reinterpret_cast<void*>(& ::edje_obj_size_min_restricted_calc);
   ops[88].op = EO_OP_OVERRIDE;
   ops[88].op_type = EO_OP_TYPE_REGULAR;
   ops[88].doc = NULL;

   ops[89].func = reinterpret_cast<void*>(& ::edje_object_part_box_remove_all_wrapper<T>);
   ops[89].api_func = reinterpret_cast<void*>(& ::edje_obj_part_box_remove_all);
   ops[89].op = EO_OP_OVERRIDE;
   ops[89].op_type = EO_OP_TYPE_REGULAR;
   ops[89].doc = NULL;

   ops[90].func = reinterpret_cast<void*>(& ::edje_object_part_drag_page_wrapper<T>);
   ops[90].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_page);
   ops[90].op = EO_OP_OVERRIDE;
   ops[90].op_type = EO_OP_TYPE_REGULAR;
   ops[90].doc = NULL;

   ops[91].func = reinterpret_cast<void*>(& ::edje_object_part_text_set_wrapper<T>);
   ops[91].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_set);
   ops[91].op = EO_OP_OVERRIDE;
   ops[91].op_type = EO_OP_TYPE_REGULAR;
   ops[91].doc = NULL;

   ops[92].func = reinterpret_cast<void*>(& ::edje_object_part_text_get_wrapper<T>);
   ops[92].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_get);
   ops[92].op = EO_OP_OVERRIDE;
   ops[92].op_type = EO_OP_TYPE_REGULAR;
   ops[92].doc = NULL;

   ops[93].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_show_on_demand_set_wrapper<T>);
   ops[93].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_show_on_demand_set);
   ops[93].op = EO_OP_OVERRIDE;
   ops[93].op_type = EO_OP_TYPE_REGULAR;
   ops[93].doc = NULL;

   ops[94].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_show_on_demand_get_wrapper<T>);
   ops[94].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_show_on_demand_get);
   ops[94].op = EO_OP_OVERRIDE;
   ops[94].op_type = EO_OP_TYPE_REGULAR;
   ops[94].doc = NULL;

   ops[95].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_hint_set_wrapper<T>);
   ops[95].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_hint_set);
   ops[95].op = EO_OP_OVERRIDE;
   ops[95].op_type = EO_OP_TYPE_REGULAR;
   ops[95].doc = NULL;

   ops[96].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_hint_get_wrapper<T>);
   ops[96].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_hint_get);
   ops[96].op = EO_OP_OVERRIDE;
   ops[96].op_type = EO_OP_TYPE_REGULAR;
   ops[96].doc = NULL;

   ops[97].func = reinterpret_cast<void*>(& ::edje_object_part_text_selection_get_wrapper<T>);
   ops[97].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_selection_get);
   ops[97].op = EO_OP_OVERRIDE;
   ops[97].op_type = EO_OP_TYPE_REGULAR;
   ops[97].doc = NULL;

   ops[98].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_is_format_get_wrapper<T>);
   ops[98].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_is_format_get);
   ops[98].op = EO_OP_OVERRIDE;
   ops[98].op_type = EO_OP_TYPE_REGULAR;
   ops[98].doc = NULL;

   ops[99].func = reinterpret_cast<void*>(& ::edje_object_text_class_get_wrapper<T>);
   ops[99].api_func = reinterpret_cast<void*>(& ::edje_obj_text_class_get);
   ops[99].op = EO_OP_OVERRIDE;
   ops[99].op_type = EO_OP_TYPE_REGULAR;
   ops[99].doc = NULL;

   ops[100].func = reinterpret_cast<void*>(& ::edje_object_color_class_set_wrapper<T>);
   ops[100].api_func = reinterpret_cast<void*>(& ::edje_obj_color_class_set);
   ops[100].op = EO_OP_OVERRIDE;
   ops[100].op_type = EO_OP_TYPE_REGULAR;
   ops[100].doc = NULL;

   ops[101].func = reinterpret_cast<void*>(& ::edje_object_color_class_get_wrapper<T>);
   ops[101].api_func = reinterpret_cast<void*>(& ::edje_obj_color_class_get);
   ops[101].op = EO_OP_OVERRIDE;
   ops[101].op_type = EO_OP_TYPE_REGULAR;
   ops[101].doc = NULL;

   ops[102].func = reinterpret_cast<void*>(& ::edje_object_color_class_description_get_wrapper<T>);
   ops[102].api_func = reinterpret_cast<void*>(& ::edje_obj_color_class_description_get);
   ops[102].op = EO_OP_OVERRIDE;
   ops[102].op_type = EO_OP_TYPE_REGULAR;
   ops[102].doc = NULL;

   ops[103].func = reinterpret_cast<void*>(& ::edje_object_part_drag_step_wrapper<T>);
   ops[103].api_func = reinterpret_cast<void*>(& ::edje_obj_part_drag_step);
   ops[103].op = EO_OP_OVERRIDE;
   ops[103].op_type = EO_OP_TYPE_REGULAR;
   ops[103].doc = NULL;

   ops[104].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_up_wrapper<T>);
   ops[104].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_up);
   ops[104].op = EO_OP_OVERRIDE;
   ops[104].op_type = EO_OP_TYPE_REGULAR;
   ops[104].doc = NULL;

   ops[105].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_geometry_get_wrapper<T>);
   ops[105].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_geometry_get);
   ops[105].op = EO_OP_OVERRIDE;
   ops[105].op_type = EO_OP_TYPE_REGULAR;
   ops[105].doc = NULL;

   ops[106].func = reinterpret_cast<void*>(& ::edje_object_part_text_anchor_list_get_wrapper<T>);
   ops[106].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_anchor_list_get);
   ops[106].op = EO_OP_OVERRIDE;
   ops[106].op_type = EO_OP_TYPE_REGULAR;
   ops[106].doc = NULL;

   ops[107].func = reinterpret_cast<void*>(& ::edje_object_text_insert_filter_callback_add_wrapper<T>);
   ops[107].api_func = reinterpret_cast<void*>(& ::edje_obj_text_insert_filter_callback_add);
   ops[107].op = EO_OP_OVERRIDE;
   ops[107].op_type = EO_OP_TYPE_REGULAR;
   ops[107].doc = NULL;

   ops[108].func = reinterpret_cast<void*>(& ::edje_object_part_text_input_panel_show_wrapper<T>);
   ops[108].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_input_panel_show);
   ops[108].op = EO_OP_OVERRIDE;
   ops[108].op_type = EO_OP_TYPE_REGULAR;
   ops[108].doc = NULL;

   ops[109].func = reinterpret_cast<void*>(& ::edje_object_part_exists_wrapper<T>);
   ops[109].api_func = reinterpret_cast<void*>(& ::edje_obj_part_exists);
   ops[109].op = EO_OP_OVERRIDE;
   ops[109].op_type = EO_OP_TYPE_REGULAR;
   ops[109].doc = NULL;

   ops[110].func = reinterpret_cast<void*>(& ::edje_object_text_markup_filter_callback_del_wrapper<T>);
   ops[110].api_func = reinterpret_cast<void*>(& ::edje_obj_text_markup_filter_callback_del);
   ops[110].op = EO_OP_OVERRIDE;
   ops[110].op_type = EO_OP_TYPE_REGULAR;
   ops[110].doc = NULL;

   ops[111].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_is_visible_format_get_wrapper<T>);
   ops[111].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_is_visible_format_get);
   ops[111].op = EO_OP_OVERRIDE;
   ops[111].op_type = EO_OP_TYPE_REGULAR;
   ops[111].doc = NULL;

   ops[112].func = reinterpret_cast<void*>(& ::edje_object_part_text_user_insert_wrapper<T>);
   ops[112].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_user_insert);
   ops[112].op = EO_OP_OVERRIDE;
   ops[112].op_type = EO_OP_TYPE_REGULAR;
   ops[112].doc = NULL;

   ops[113].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_prev_wrapper<T>);
   ops[113].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_prev);
   ops[113].op = EO_OP_OVERRIDE;
   ops[113].op_type = EO_OP_TYPE_REGULAR;
   ops[113].doc = NULL;

   ops[114].func = reinterpret_cast<void*>(& ::edje_object_part_text_item_list_get_wrapper<T>);
   ops[114].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_item_list_get);
   ops[114].op = EO_OP_OVERRIDE;
   ops[114].op_type = EO_OP_TYPE_REGULAR;
   ops[114].doc = NULL;

   ops[115].func = reinterpret_cast<void*>(& ::edje_object_part_swallow_wrapper<T>);
   ops[115].api_func = reinterpret_cast<void*>(& ::edje_obj_part_swallow);
   ops[115].op = EO_OP_OVERRIDE;
   ops[115].op_type = EO_OP_TYPE_REGULAR;
   ops[115].doc = NULL;

   ops[116].func = reinterpret_cast<void*>(& ::edje_object_update_hints_get_wrapper<T>);
   ops[116].api_func = reinterpret_cast<void*>(& ::edje_obj_update_hints_get);
   ops[116].op = EO_OP_OVERRIDE;
   ops[116].op_type = EO_OP_TYPE_REGULAR;
   ops[116].doc = NULL;

   ops[117].func = reinterpret_cast<void*>(& ::edje_object_update_hints_set_wrapper<T>);
   ops[117].api_func = reinterpret_cast<void*>(& ::edje_obj_update_hints_set);
   ops[117].op = EO_OP_OVERRIDE;
   ops[117].op_type = EO_OP_TYPE_REGULAR;
   ops[117].doc = NULL;

   ops[118].func = reinterpret_cast<void*>(& ::edje_object_mirrored_get_wrapper<T>);
   ops[118].api_func = reinterpret_cast<void*>(& ::edje_obj_mirrored_get);
   ops[118].op = EO_OP_OVERRIDE;
   ops[118].op_type = EO_OP_TYPE_REGULAR;
   ops[118].doc = NULL;

   ops[119].func = reinterpret_cast<void*>(& ::edje_object_mirrored_set_wrapper<T>);
   ops[119].api_func = reinterpret_cast<void*>(& ::edje_obj_mirrored_set);
   ops[119].op = EO_OP_OVERRIDE;
   ops[119].op_type = EO_OP_TYPE_REGULAR;
   ops[119].doc = NULL;

   ops[120].func = reinterpret_cast<void*>(& ::edje_object_animation_get_wrapper<T>);
   ops[120].api_func = reinterpret_cast<void*>(& ::edje_obj_animation_get);
   ops[120].op = EO_OP_OVERRIDE;
   ops[120].op_type = EO_OP_TYPE_REGULAR;
   ops[120].doc = NULL;

   ops[121].func = reinterpret_cast<void*>(& ::edje_object_animation_set_wrapper<T>);
   ops[121].api_func = reinterpret_cast<void*>(& ::edje_obj_animation_set);
   ops[121].op = EO_OP_OVERRIDE;
   ops[121].op_type = EO_OP_TYPE_REGULAR;
   ops[121].doc = NULL;

   ops[122].func = reinterpret_cast<void*>(& ::edje_object_play_get_wrapper<T>);
   ops[122].api_func = reinterpret_cast<void*>(& ::edje_obj_play_get);
   ops[122].op = EO_OP_OVERRIDE;
   ops[122].op_type = EO_OP_TYPE_REGULAR;
   ops[122].doc = NULL;

   ops[123].func = reinterpret_cast<void*>(& ::edje_object_play_set_wrapper<T>);
   ops[123].api_func = reinterpret_cast<void*>(& ::edje_obj_play_set);
   ops[123].op = EO_OP_OVERRIDE;
   ops[123].op_type = EO_OP_TYPE_REGULAR;
   ops[123].doc = NULL;

   ops[124].func = reinterpret_cast<void*>(& ::edje_object_perspective_get_wrapper<T>);
   ops[124].api_func = reinterpret_cast<void*>(& ::edje_obj_perspective_get);
   ops[124].op = EO_OP_OVERRIDE;
   ops[124].op_type = EO_OP_TYPE_REGULAR;
   ops[124].doc = NULL;

   ops[125].func = reinterpret_cast<void*>(& ::edje_object_perspective_set_wrapper<T>);
   ops[125].api_func = reinterpret_cast<void*>(& ::edje_obj_perspective_set);
   ops[125].op = EO_OP_OVERRIDE;
   ops[125].op_type = EO_OP_TYPE_REGULAR;
   ops[125].doc = NULL;

   ops[126].func = reinterpret_cast<void*>(& ::edje_object_scale_get_wrapper<T>);
   ops[126].api_func = reinterpret_cast<void*>(& ::edje_obj_scale_get);
   ops[126].op = EO_OP_OVERRIDE;
   ops[126].op_type = EO_OP_TYPE_REGULAR;
   ops[126].doc = NULL;

   ops[127].func = reinterpret_cast<void*>(& ::edje_object_scale_set_wrapper<T>);
   ops[127].api_func = reinterpret_cast<void*>(& ::edje_obj_scale_set);
   ops[127].op = EO_OP_OVERRIDE;
   ops[127].op_type = EO_OP_TYPE_REGULAR;
   ops[127].doc = NULL;

   ops[128].func = reinterpret_cast<void*>(& ::edje_object_base_scale_get_wrapper<T>);
   ops[128].api_func = reinterpret_cast<void*>(& ::edje_obj_base_scale_get);
   ops[128].op = EO_OP_OVERRIDE;
   ops[128].op_type = EO_OP_TYPE_REGULAR;
   ops[128].doc = NULL;

   ops[129].func = reinterpret_cast<void*>(& ::edje_object_text_change_cb_set_wrapper<T>);
   ops[129].api_func = reinterpret_cast<void*>(& ::edje_obj_text_change_cb_set);
   ops[129].op = EO_OP_OVERRIDE;
   ops[129].op_type = EO_OP_TYPE_REGULAR;
   ops[129].doc = NULL;

   ops[130].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_begin_set_wrapper<T>);
   ops[130].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_begin_set);
   ops[130].op = EO_OP_OVERRIDE;
   ops[130].op_type = EO_OP_TYPE_REGULAR;
   ops[130].doc = NULL;

   ops[131].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_line_end_set_wrapper<T>);
   ops[131].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_line_end_set);
   ops[131].op = EO_OP_OVERRIDE;
   ops[131].op_type = EO_OP_TYPE_REGULAR;
   ops[131].doc = NULL;

   ops[132].func = reinterpret_cast<void*>(& ::edje_object_text_class_set_wrapper<T>);
   ops[132].api_func = reinterpret_cast<void*>(& ::edje_obj_text_class_set);
   ops[132].op = EO_OP_OVERRIDE;
   ops[132].op_type = EO_OP_TYPE_REGULAR;
   ops[132].doc = NULL;

   ops[133].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_coord_set_wrapper<T>);
   ops[133].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_coord_set);
   ops[133].op = EO_OP_OVERRIDE;
   ops[133].op_type = EO_OP_TYPE_REGULAR;
   ops[133].doc = NULL;

   ops[134].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_end_set_wrapper<T>);
   ops[134].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_end_set);
   ops[134].op = EO_OP_OVERRIDE;
   ops[134].op_type = EO_OP_TYPE_REGULAR;
   ops[134].doc = NULL;

   ops[135].func = reinterpret_cast<void*>(& ::edje_object_part_text_escaped_set_wrapper<T>);
   ops[135].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_escaped_set);
   ops[135].op = EO_OP_OVERRIDE;
   ops[135].op_type = EO_OP_TYPE_REGULAR;
   ops[135].doc = NULL;

   ops[136].func = reinterpret_cast<void*>(& ::edje_object_item_provider_set_wrapper<T>);
   ops[136].api_func = reinterpret_cast<void*>(& ::edje_obj_item_provider_set);
   ops[136].op = EO_OP_OVERRIDE;
   ops[136].op_type = EO_OP_TYPE_REGULAR;
   ops[136].doc = NULL;

   ops[137].func = reinterpret_cast<void*>(& ::edje_object_part_text_cursor_line_begin_set_wrapper<T>);
   ops[137].api_func = reinterpret_cast<void*>(& ::edje_obj_part_text_cursor_line_begin_set);
   ops[137].op = EO_OP_OVERRIDE;
   ops[137].op_type = EO_OP_TYPE_REGULAR;
   ops[137].doc = NULL;

   ops[138].func = reinterpret_cast<void*>(& ::edje_object_message_handler_set_wrapper<T>);
   ops[138].api_func = reinterpret_cast<void*>(& ::edje_obj_message_handler_set);
   ops[138].op = EO_OP_OVERRIDE;
   ops[138].op_type = EO_OP_TYPE_REGULAR;
   ops[138].doc = NULL;

   ops[139].func = reinterpret_cast<void*>(& ::edje_object_size_min_get_wrapper<T>);
   ops[139].api_func = reinterpret_cast<void*>(& ::edje_obj_size_min_get);
   ops[139].op = EO_OP_OVERRIDE;
   ops[139].op_type = EO_OP_TYPE_REGULAR;
   ops[139].doc = NULL;

   ops[140].func = reinterpret_cast<void*>(& ::edje_object_access_part_list_get_wrapper<T>);
   ops[140].api_func = reinterpret_cast<void*>(& ::edje_obj_access_part_list_get);
   ops[140].op = EO_OP_OVERRIDE;
   ops[140].op_type = EO_OP_TYPE_REGULAR;
   ops[140].doc = NULL;

   ops[141].func = reinterpret_cast<void*>(& ::edje_object_load_error_get_wrapper<T>);
   ops[141].api_func = reinterpret_cast<void*>(& ::edje_obj_load_error_get);
   ops[141].op = EO_OP_OVERRIDE;
   ops[141].op_type = EO_OP_TYPE_REGULAR;
   ops[141].doc = NULL;

   ops[142].func = reinterpret_cast<void*>(& ::edje_object_size_max_get_wrapper<T>);
   ops[142].api_func = reinterpret_cast<void*>(& ::edje_obj_size_max_get);
   ops[142].op = EO_OP_OVERRIDE;
   ops[142].op_type = EO_OP_TYPE_REGULAR;
   ops[142].doc = NULL;

   initialize_operation_description<T>(::efl::eo::detail::tag<::evas::smart_clipped>(), &ops[operation_description_class_size< ::edje::object >::value]);
   initialize_operation_description<T>(::efl::eo::detail::tag<::efl::file>(), &ops[operation_description_class_size< ::edje::object >::value + operation_description_class_size<::evas::smart_clipped>::value]);
   return 0;
}
inline Eo_Class const* get_eo_class(tag<::edje::object>)
{
   return (EDJE_OBJECT_CLASS);
}

} } }

/// @endcond

