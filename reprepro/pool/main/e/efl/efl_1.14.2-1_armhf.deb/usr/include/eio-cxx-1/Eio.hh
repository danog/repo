#ifndef EFL_CXX_EIO_HH
#define EFL_CXX_EIO_HH

#ifdef EFL_BETA_API_SUPPORT
#include <eio_model.eo.hh>
#endif

#endif

