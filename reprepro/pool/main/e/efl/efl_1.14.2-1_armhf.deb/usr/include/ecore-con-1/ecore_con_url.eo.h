#ifndef _ECORE_CON_URL_EO_H_
#define _ECORE_CON_URL_EO_H_

#ifndef _ECORE_CON_URL_EO_CLASS_TYPE
#define _ECORE_CON_URL_EO_CLASS_TYPE

typedef Eo Ecore_Con_Url;

#endif

#ifndef _ECORE_CON_URL_EO_TYPES
#define _ECORE_CON_URL_EO_TYPES


#endif
#define ECORE_CON_URL_CLASS ecore_con_url_class_get()

EAPI const Eo_Class *ecore_con_url_class_get(void) EINA_CONST;

/**
 *
 * No description supplied.
 *
 * @param[in] url The URL
 *
 */
EOAPI Eina_Bool  ecore_con_url_obj_url_set(const char *url);

/**
 *
 * No description supplied.
 *
 *
 */
EOAPI const char * ecore_con_url_obj_url_get(void);


#endif
