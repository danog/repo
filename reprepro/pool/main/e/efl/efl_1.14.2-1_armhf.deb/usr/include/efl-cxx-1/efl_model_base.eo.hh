#ifndef EFL_GENERATED_EFL_MODEL_BASE_HH
#define EFL_GENERATED_EFL_MODEL_BASE_HH

extern "C"
{
#include <Efl.h>
}
#include <Eo.hh>

#include <eo_cxx_interop.hh>

extern "C"
{
#include "efl_model_base.eo.h"
}

#include <eina-cxx/eina_accessor.hh>
#include <eo_concrete.hh>
#include <string>

namespace efl { namespace model {

struct base;

} }

/// @cond EO_CXX_ABSTRACT
namespace eo_cxx {

namespace efl { namespace model {

struct base
{
   /// @brief Load emodel.
   ///
   /// By convention this means loading data from an external source and populating
   /// the models properties and children with it. For example in the case of file
   /// system backed model, this means opening the relevant files and reading the
   /// data from them(creating the properties and children from it).
   /// the model emit EFL_MODEL_EVENT_LOAD_STATUS after end with Efl_Model_Load_Status
   /// @warning This convention should be followed, but no guarantees of behaviour
   /// by user defined types can be given.
   ///
   /// Alternatively is possible to use properties_load to load only properties
   /// and children_load to load only children. If efl_model_load is called then
   /// calling properties_load and/or children_load is not necessary.
   ///
   /// @see Efl_Model_Load_Status
   /// @see efl_model_properties_load
   /// @see efl_model_children_load
   /// @see efl_model_unload
   /// @see efl_model_load_status_get
   ///
   /// @since 1.14
   ///
   void load() const;

   /// @brief Unload emodel.
   ///
   /// By convention this means releasing data received/read from an external source. For
   /// example of a database backed model this might mean releasing the iterator for
   /// the currently loaded data or deleting a temporary table.
   /// the model emit EFL_MODEL_EVENT_LOAD_STATUS after end with model load status
   /// @warning This convention should be followed, but no guarantees of behaviour
   /// by user defined types can be given.
   ///
   /// @see Efl_Model_Load_Status
   /// @see efl_model_load
   /// @see efl_model_load_status_get
   ///
   /// @since 1.14
   ///
   void unload() const;

   /// @brief Properties emodel load.
   ///
   /// By convention this means loading data from an external source and populating
   /// the models properties only. This method is a subset of efl_model_load, meaning that
   /// it won't load children, it is a hint.
   /// For loadind both properties and children use efl_model_load
   /// instead.
   ///
   /// @see efl_model_load
   ///
   /// @since 1.14
   ///
   void properties_load() const;

   /// @brief Children emodel load.
   ///
   /// By convention this means loading data from an external source and populating
   /// the models children only. This method is a subset of efl_model_load, meaning that
   /// it won't load properties. For loadind both properties and children use efl_model_load
   /// instead.
   ///
   /// @see efl_model_load
   ///
   /// @since 1.14
   ///
   void children_load() const;

   /// @brief Add a new child.
   ///
   /// @return: @c Emodel* on success, @c NULL otherwise
   ///
   /// Add a new child, possibly dummy, depending on the implementation,
   /// of a internal keeping. When the child is effectively
   /// added the event EFL_MODEL_EVENT_CHILD_ADD is then raised and the new child
   /// is kept along with other children.
   ///
   /// @see EFL_MODEL_EVENT_CHILD_ADD
   /// @see load_status_get
   ///
   /// @since 1.14
   ///
   ::efl::eo::concrete child_add() const;

   /// @brief Remove a child.
   ///
   /// @return: @c Efl_Model_Load_Status on success, @c EFL_MODEL_LOAD_STATUS_ERROR otherwise.
   ///
   /// Remove a child of a internal keeping. When the child is effectively
   /// removed the event EFL_MODEL_EVENT_CHILD_REMOVED is then raised to give a
   /// chance for listeners to perform any cleanup and/or update references.
   ///
   /// @see EFL_MODEL_EVENT_CHILD_REMOVED
   /// @since 1.14
   ///
   /// @param child Child to be removed
   ///
   Efl_Model_Load_Status child_del(::efl::eo::concrete child_) const;

   /// @brief Get a load emodel current status.
   ///
   /// @return: @c Efl_Model_Load_Status
   ///
   /// By convention this means get the current model status.
   /// Possible values are defined Efl_Model_Load_Status enumerator.
   ///
   /// @see Efl_Model_Load_Status
   /// @see efl_model_load
   ///
   /// @since 1.14
   ///
   Efl_Model_Load_Status load_status_get() const;

   /// @brief Get properties from model.
   ///
   /// @return: @c Efl_Model_Load_Status
   ///
   /// properties_get is due to provide callers a way the fetch the current
   /// properties implemented/used by the model.
   /// The event EFL_MODEL_EVENT_PROPERTIES_CHANGE will be raised to notify listeners
   /// of any modifications in the properties.
   ///
   /// @see EFL_MODEL_EVENT_PROPERTIES_CHANGE
   /// @since 1.14
   ///
   /// @param properties array of current properties
   ///
   Efl_Model_Load_Status properties_get(Eina_Array * const* properties_) const;

   /// @brief Retrieve the value of a given property name.
   ///
   /// @return: @c Load Status, on success, @c EFL_MODEL_LOAD_STATUS_ERROR otherwise
   ///
   /// property_get will only be available when load status is equal to
   /// EFL_MODEL_LOAD_STATUS_LOADED.
   ///
   /// At this point the caller is free to get values from properties.
   /// The event EFL_MODEL_EVENT_PROPERTIES_CHANGE may be raised to notify
   /// listeners of the property/value.
   ///
   /// @see efl_model_properties_get
   /// @see EFL_MODEL_EVENT_PROPERTIES_CHANGE
   ///
   /// @since 1.14
   ///
   /// @param value New value
   ///
   Efl_Model_Load_Status property_get(::efl::eina::string_view property_, const Eina_Value ** value_) const;

   /// @brief Set a property value of a given property name.
   ///
   /// @return: @c EINA_TRUE, on success, @c EINA_FALSE in readonly property or error
   ///
   /// The caller must ensure to call at least efl_model_prop_list before being
   /// able to see/set properties.
   /// This function sets a new property value into given property name. Once
   /// the operation is completed the concrete implementation should raise
   /// EFL_MODEL_EVENT_PROPERTIES_CHANGE event in order to notify listeners of the
   /// new value of the property.
   ///
   /// If the model doesn't have the property then there are two possibilities,
   /// either raise an error or create the new property in model
   ///
   /// @see efl_model_property_get
   /// @see EFL_MODEL_EVENT_PROPERTIES_CHANGE
   /// @since 1.14
   ///
   /// @param value New value
   ///
   Efl_Model_Load_Status property_set(::efl::eina::string_view property_, const Eina_Value * value_) const;

   /// @brief Get children slice OR full range.
   ///
   /// @return: @c Efl_Model_Load_Status. See below for more info.
   ///
   /// Before being able to get the children list the model status must be
   /// on loaded status (EFL_MODEL_LOAD_STATUS_LOADED).
   /// However there may be circunstancies where the model could be
   /// in a different state, in such cases it is advisable
   /// to simply return: its current state, which will be
   /// of course, different than @c EFL_MODEL_LOAD_STATUS_LOADED_CHILDREN.
   /// When children accessor is return:ed as NULL one should then
   /// test the current load status return:ed by @children_slice_get
   /// in order to check against an empty list or real error.
   ///
   /// children_slice_get behaves in two different ways, it may provide
   /// the slice if both @c start AND @c count are non-zero OR full range otherwise.
   ///
   /// The return:ed Eina_Accessor must be freed when it is no longer needed and
   /// eo_unref() must be invoked for children if caller wants a copy.
   ///
   /// Since 'slice' is a range, for example if we have 20 childs a slice could be
   /// the range from 3(start) to 4(count), see:
   /// child 0  [no]
   /// child 1  [no]
   /// child 2  [yes]
   /// child 3  [yes]
   /// child 4  [yes]
   /// child 5  [yes]
   /// child 6  [no]
   /// child 7  [no]
   ///
   /// Optionally the user can call children_count_get to know
   /// the number of children so a valid range can be known in advance.
   ///
   /// Below are examples of both usage types: slices and full ranges.
   /// @code
   ///
   /// // Returns full list
   /// eo_do(obj, efl_model_children_slice_get(0, 0, &children_accessor));
   ///
   /// // Returns 5 items, counting from item #5
   /// eo_do(obj, efl_model_children_slice_get(5, 5, &children_accessor));
   ///
   /// @endcode
   ///
   /// @see efl_model_children_get
   /// @see efl_model_children_count_get
   /// @see efl_model_load
   /// @see efl_model_load_status_get
   /// @since 1.14
   ///
   /// @param children_accessor 
   ///
   Efl_Model_Load_Status children_slice_get(unsigned start_, unsigned count_, Eina_Accessor ** children_accessor_) const;

   /// @brief Get children count.
   ///
   /// @return: @c EINA_TRUE, on success, @c EINA_FALSE otherwise
   ///
   /// When efl_model_load is completed efl_model_coildren_count_get can be use
   /// to get the number of children. children_count_get can also be used
   /// before calling children_slice_get so a valid range is known.
   /// Event EFL_MODEL_CHILDREN_COUNT_CHANGED is emitted when count is finished.
   ///
   /// @see efl_model_children_get
   /// @see efl_model_children_slice_get
   /// @see efl_model_load
   /// @see efl_model_load_status_get
   /// @since 1.14
   ///
   /// @param children_count 
   ///
   Efl_Model_Load_Status children_count_get(unsigned* children_count_) const;

   /// Event dispatch when load status changes
   template <typename F>
   ::efl::eo::signal_connection
   callback_load_status_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_LOAD_STATUS, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_LOAD_STATUS );
   }

   /// Event dispatch when load status changes
   template <typename T>
   void
   callback_load_status_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_LOAD_STATUS, info));
   }

   /// Event dispatched when properties list is available.
   template <typename F>
   ::efl::eo::signal_connection
   callback_properties_changed_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_PROPERTIES_CHANGED, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_PROPERTIES_CHANGED );
   }

   /// Event dispatched when properties list is available.
   template <typename T>
   void
   callback_properties_changed_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_PROPERTIES_CHANGED, info));
   }

   /// Event dispatched when new child is added.
   template <typename F>
   ::efl::eo::signal_connection
   callback_child_added_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_CHILD_ADDED, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_CHILD_ADDED );
   }

   /// Event dispatched when new child is added.
   template <typename T>
   void
   callback_child_added_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_CHILD_ADDED, info));
   }

   /// Event dispatched when child is removed.
   template <typename F>
   ::efl::eo::signal_connection
   callback_child_removed_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_CHILD_REMOVED, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_CHILD_REMOVED );
   }

   /// Event dispatched when child is removed.
   template <typename T>
   void
   callback_child_removed_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_CHILD_REMOVED, info));
   }

   /// Event dispatched when children count is finished.
   template <typename F>
   ::efl::eo::signal_connection
   callback_children_count_changed_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_CHILDREN_COUNT_CHANGED, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_CHILDREN_COUNT_CHANGED );
   }

   /// Event dispatched when children count is finished.
   template <typename T>
   void
   callback_children_count_changed_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_CHILDREN_COUNT_CHANGED, info));
   }



   static Eo_Class const* _eo_class()
   {
      return(EFL_MODEL_BASE_INTERFACE);
   }

   operator ::efl::model::base() const;
   operator ::efl::model::base&();
   operator ::efl::model::base const&() const;

   /// @cond LOCAL
   template <typename D>
   struct address_of
   {
      operator ::efl::model::base*() const { return static_cast<::efl::model::base*>(static_cast<D const*>(this)->p); }
      operator ::efl::model::base const*() const { return static_cast<::efl::model::base const*>(static_cast<D const*>(this)->p); }
   };

   template <typename D>
   struct address_const_of
   {
      operator ::efl::model::base const*() const { return static_cast<::efl::model::base const*>(static_cast<D const*>(this)->p); }
   };
   /// @endcond

private:

   /// @internal
   Eo* _concrete_eo_ptr() const
   {
      return static_cast<::efl::eo::concrete const*>(static_cast<void const*>(this))->_eo_ptr();
   }

};

} }

}
/// @endcond

namespace efl { namespace model {

/// @brief Class base
struct base
      : ::efl::eo::concrete
{
   //@{
   /**
      @brief Constructs a new efl::model::base object.

      Constructs a new efl::model::base object. If you want this object to be a child
      of another Eo object, use an @ref efl::eo::parent expression, like the example.

      Example:
      @code
      efl::model::base my_base(efl::eo::parent = parent_object);
      @endcode

      @see base(Eo* eo)
   */
   explicit base(::efl::eo::parent_type _p)
      : base(_ctors_call(_p))
   {}

   explicit base()
      : base(_ctors_call(::efl::eo::parent = nullptr))
   {}
   //@}

   /// @brief Eo Constructor.
   ///
   /// Constructs the object from an Eo* pointer stealing its ownership.
   ///
   /// @param eo The Eo object pointer.
   ///
   explicit base(Eo* eo)
      : ::efl::eo::concrete(eo)
   {}

   /// @brief nullptr_t Constructor.
   ///
   /// Constructs an empty (null) object.
   ///
   explicit base(std::nullptr_t)
      : ::efl::eo::concrete(nullptr)
   {}

   /// @brief Copy Constructor.
   ///
   base(base const& other)
      : base(eo_ref(other._eo_ptr()))
   {}

   ~base() {}

   /// @brief Load emodel.
   ///
   /// By convention this means loading data from an external source and populating
   /// the models properties and children with it. For example in the case of file
   /// system backed model, this means opening the relevant files and reading the
   /// data from them(creating the properties and children from it).
   /// the model emit EFL_MODEL_EVENT_LOAD_STATUS after end with Efl_Model_Load_Status
   /// @warning This convention should be followed, but no guarantees of behaviour
   /// by user defined types can be given.
   ///
   /// Alternatively is possible to use properties_load to load only properties
   /// and children_load to load only children. If efl_model_load is called then
   /// calling properties_load and/or children_load is not necessary.
   ///
   /// @see Efl_Model_Load_Status
   /// @see efl_model_properties_load
   /// @see efl_model_children_load
   /// @see efl_model_unload
   /// @see efl_model_load_status_get
   ///
   /// @since 1.14
   ///
   void load() const;

   /// @brief Unload emodel.
   ///
   /// By convention this means releasing data received/read from an external source. For
   /// example of a database backed model this might mean releasing the iterator for
   /// the currently loaded data or deleting a temporary table.
   /// the model emit EFL_MODEL_EVENT_LOAD_STATUS after end with model load status
   /// @warning This convention should be followed, but no guarantees of behaviour
   /// by user defined types can be given.
   ///
   /// @see Efl_Model_Load_Status
   /// @see efl_model_load
   /// @see efl_model_load_status_get
   ///
   /// @since 1.14
   ///
   void unload() const;

   /// @brief Properties emodel load.
   ///
   /// By convention this means loading data from an external source and populating
   /// the models properties only. This method is a subset of efl_model_load, meaning that
   /// it won't load children, it is a hint.
   /// For loadind both properties and children use efl_model_load
   /// instead.
   ///
   /// @see efl_model_load
   ///
   /// @since 1.14
   ///
   void properties_load() const;

   /// @brief Children emodel load.
   ///
   /// By convention this means loading data from an external source and populating
   /// the models children only. This method is a subset of efl_model_load, meaning that
   /// it won't load properties. For loadind both properties and children use efl_model_load
   /// instead.
   ///
   /// @see efl_model_load
   ///
   /// @since 1.14
   ///
   void children_load() const;

   /// @brief Add a new child.
   ///
   /// @return: @c Emodel* on success, @c NULL otherwise
   ///
   /// Add a new child, possibly dummy, depending on the implementation,
   /// of a internal keeping. When the child is effectively
   /// added the event EFL_MODEL_EVENT_CHILD_ADD is then raised and the new child
   /// is kept along with other children.
   ///
   /// @see EFL_MODEL_EVENT_CHILD_ADD
   /// @see load_status_get
   ///
   /// @since 1.14
   ///
   ::efl::eo::concrete child_add() const;

   /// @brief Remove a child.
   ///
   /// @return: @c Efl_Model_Load_Status on success, @c EFL_MODEL_LOAD_STATUS_ERROR otherwise.
   ///
   /// Remove a child of a internal keeping. When the child is effectively
   /// removed the event EFL_MODEL_EVENT_CHILD_REMOVED is then raised to give a
   /// chance for listeners to perform any cleanup and/or update references.
   ///
   /// @see EFL_MODEL_EVENT_CHILD_REMOVED
   /// @since 1.14
   ///
   /// @param child Child to be removed
   ///
   Efl_Model_Load_Status child_del(::efl::eo::concrete child_) const;

   /// @brief Get a load emodel current status.
   ///
   /// @return: @c Efl_Model_Load_Status
   ///
   /// By convention this means get the current model status.
   /// Possible values are defined Efl_Model_Load_Status enumerator.
   ///
   /// @see Efl_Model_Load_Status
   /// @see efl_model_load
   ///
   /// @since 1.14
   ///
   Efl_Model_Load_Status load_status_get() const;

   /// @brief Get properties from model.
   ///
   /// @return: @c Efl_Model_Load_Status
   ///
   /// properties_get is due to provide callers a way the fetch the current
   /// properties implemented/used by the model.
   /// The event EFL_MODEL_EVENT_PROPERTIES_CHANGE will be raised to notify listeners
   /// of any modifications in the properties.
   ///
   /// @see EFL_MODEL_EVENT_PROPERTIES_CHANGE
   /// @since 1.14
   ///
   /// @param properties array of current properties
   ///
   Efl_Model_Load_Status properties_get(Eina_Array * const* properties_) const;

   /// @brief Retrieve the value of a given property name.
   ///
   /// @return: @c Load Status, on success, @c EFL_MODEL_LOAD_STATUS_ERROR otherwise
   ///
   /// property_get will only be available when load status is equal to
   /// EFL_MODEL_LOAD_STATUS_LOADED.
   ///
   /// At this point the caller is free to get values from properties.
   /// The event EFL_MODEL_EVENT_PROPERTIES_CHANGE may be raised to notify
   /// listeners of the property/value.
   ///
   /// @see efl_model_properties_get
   /// @see EFL_MODEL_EVENT_PROPERTIES_CHANGE
   ///
   /// @since 1.14
   ///
   /// @param value New value
   ///
   Efl_Model_Load_Status property_get(::efl::eina::string_view property_, const Eina_Value ** value_) const;

   /// @brief Set a property value of a given property name.
   ///
   /// @return: @c EINA_TRUE, on success, @c EINA_FALSE in readonly property or error
   ///
   /// The caller must ensure to call at least efl_model_prop_list before being
   /// able to see/set properties.
   /// This function sets a new property value into given property name. Once
   /// the operation is completed the concrete implementation should raise
   /// EFL_MODEL_EVENT_PROPERTIES_CHANGE event in order to notify listeners of the
   /// new value of the property.
   ///
   /// If the model doesn't have the property then there are two possibilities,
   /// either raise an error or create the new property in model
   ///
   /// @see efl_model_property_get
   /// @see EFL_MODEL_EVENT_PROPERTIES_CHANGE
   /// @since 1.14
   ///
   /// @param value New value
   ///
   Efl_Model_Load_Status property_set(::efl::eina::string_view property_, const Eina_Value * value_) const;

   /// @brief Get children slice OR full range.
   ///
   /// @return: @c Efl_Model_Load_Status. See below for more info.
   ///
   /// Before being able to get the children list the model status must be
   /// on loaded status (EFL_MODEL_LOAD_STATUS_LOADED).
   /// However there may be circunstancies where the model could be
   /// in a different state, in such cases it is advisable
   /// to simply return: its current state, which will be
   /// of course, different than @c EFL_MODEL_LOAD_STATUS_LOADED_CHILDREN.
   /// When children accessor is return:ed as NULL one should then
   /// test the current load status return:ed by @children_slice_get
   /// in order to check against an empty list or real error.
   ///
   /// children_slice_get behaves in two different ways, it may provide
   /// the slice if both @c start AND @c count are non-zero OR full range otherwise.
   ///
   /// The return:ed Eina_Accessor must be freed when it is no longer needed and
   /// eo_unref() must be invoked for children if caller wants a copy.
   ///
   /// Since 'slice' is a range, for example if we have 20 childs a slice could be
   /// the range from 3(start) to 4(count), see:
   /// child 0  [no]
   /// child 1  [no]
   /// child 2  [yes]
   /// child 3  [yes]
   /// child 4  [yes]
   /// child 5  [yes]
   /// child 6  [no]
   /// child 7  [no]
   ///
   /// Optionally the user can call children_count_get to know
   /// the number of children so a valid range can be known in advance.
   ///
   /// Below are examples of both usage types: slices and full ranges.
   /// @code
   ///
   /// // Returns full list
   /// eo_do(obj, efl_model_children_slice_get(0, 0, &children_accessor));
   ///
   /// // Returns 5 items, counting from item #5
   /// eo_do(obj, efl_model_children_slice_get(5, 5, &children_accessor));
   ///
   /// @endcode
   ///
   /// @see efl_model_children_get
   /// @see efl_model_children_count_get
   /// @see efl_model_load
   /// @see efl_model_load_status_get
   /// @since 1.14
   ///
   /// @param children_accessor 
   ///
   Efl_Model_Load_Status children_slice_get(unsigned start_, unsigned count_, Eina_Accessor ** children_accessor_) const;

   /// @brief Get children count.
   ///
   /// @return: @c EINA_TRUE, on success, @c EINA_FALSE otherwise
   ///
   /// When efl_model_load is completed efl_model_coildren_count_get can be use
   /// to get the number of children. children_count_get can also be used
   /// before calling children_slice_get so a valid range is known.
   /// Event EFL_MODEL_CHILDREN_COUNT_CHANGED is emitted when count is finished.
   ///
   /// @see efl_model_children_get
   /// @see efl_model_children_slice_get
   /// @see efl_model_load
   /// @see efl_model_load_status_get
   /// @since 1.14
   ///
   /// @param children_count 
   ///
   Efl_Model_Load_Status children_count_get(unsigned* children_count_) const;

   /// Event dispatched when new child is added.
   template <typename F>
   ::efl::eo::signal_connection
   callback_child_added_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_CHILD_ADDED, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_CHILD_ADDED );
   }

   /// Event dispatched when new child is added.
   template <typename T>
   void
   callback_child_added_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_CHILD_ADDED, info));
   }

   /// Event dispatched when child is removed.
   template <typename F>
   ::efl::eo::signal_connection
   callback_child_removed_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_CHILD_REMOVED, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_CHILD_REMOVED );
   }

   /// Event dispatched when child is removed.
   template <typename T>
   void
   callback_child_removed_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_CHILD_REMOVED, info));
   }

   /// Event dispatched when children count is finished.
   template <typename F>
   ::efl::eo::signal_connection
   callback_children_count_changed_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_CHILDREN_COUNT_CHANGED, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_CHILDREN_COUNT_CHANGED );
   }

   /// Event dispatched when children count is finished.
   template <typename T>
   void
   callback_children_count_changed_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_CHILDREN_COUNT_CHANGED, info));
   }

   /// Event dispatch when load status changes
   template <typename F>
   ::efl::eo::signal_connection
   callback_load_status_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_LOAD_STATUS, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_LOAD_STATUS );
   }

   /// Event dispatch when load status changes
   template <typename T>
   void
   callback_load_status_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_LOAD_STATUS, info));
   }

   /// Event dispatched when properties list is available.
   template <typename F>
   ::efl::eo::signal_connection
   callback_properties_changed_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_MODEL_BASE_EVENT_PROPERTIES_CHANGED, priority_,
            &::efl::eo::_detail::event_callback<::efl::model::base, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::model::base, function_type>,
         EFL_MODEL_BASE_EVENT_PROPERTIES_CHANGED );
   }

   /// Event dispatched when properties list is available.
   template <typename T>
   void
   callback_properties_changed_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_MODEL_BASE_EVENT_PROPERTIES_CHANGED, info));
   }



   static Eo_Class const* _eo_class()
   {
      return(EFL_MODEL_BASE_INTERFACE);
   }

   /// @cond LOCAL
   struct address_of
      : ::eo_cxx::efl::model::base::address_of<address_of>
      , ::efl::eo::detail::concrete_address_of
   {
      explicit address_of(::efl::model::base* p)
         : ::efl::eo::detail::concrete_address_of(p)
      {}
   };
   address_of operator&() { return address_of(this); }

   struct address_const_of
      : ::eo_cxx::efl::model::base::address_const_of<address_const_of>
      , ::efl::eo::detail::concrete_address_const_of
   {
      explicit address_const_of(::efl::model::base const* p)
         : ::efl::eo::detail::concrete_address_const_of(p)
      {}
   };
   address_const_of operator&() const { return address_const_of(this); }

   /// @endcond

private:

   /// @internal
   static Eo* _ctors_call(::efl::eo::parent_type _p)
   {
      Eo* _ret_eo = eo_add_ref(EFL_MODEL_BASE_INTERFACE, _p._eo_raw);

      return _ret_eo;
   }

   /// @internal
   Eo* _concrete_eo_ptr() const { return _eo_ptr(); }
};

static_assert(sizeof(::efl::model::base) == sizeof(Eo*), "");
static_assert(std::is_standard_layout<::efl::model::base>::value, "");

} }


#include "efl_model_base.eo.impl.hh"

#endif // EFL_GENERATED_EFL_MODEL_BASE_HH

