#ifndef _EFL_VG_GRADIENT_RADIAL_EO_H_
#define _EFL_VG_GRADIENT_RADIAL_EO_H_

#ifndef _EFL_VG_GRADIENT_RADIAL_EO_CLASS_TYPE
#define _EFL_VG_GRADIENT_RADIAL_EO_CLASS_TYPE

typedef Eo Efl_VG_Gradient_Radial;

#endif

#ifndef _EFL_VG_GRADIENT_RADIAL_EO_TYPES
#define _EFL_VG_GRADIENT_RADIAL_EO_TYPES


#endif
#define EFL_VG_GRADIENT_RADIAL_CLASS efl_vg_gradient_radial_class_get()

EAPI const Eo_Class *efl_vg_gradient_radial_class_get(void) EINA_CONST;


#endif
