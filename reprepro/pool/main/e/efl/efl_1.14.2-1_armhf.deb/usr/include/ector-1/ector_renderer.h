#ifndef ECTOR_RENDERER_H
#define ECTOR_RENDERER_H

#include "ector_renderer_generic_base.eo.h"
#include "ector_renderer_generic_shape.eo.h"
#include "ector_renderer_generic_gradient.eo.h"
#include "ector_renderer_generic_gradient_linear.eo.h"
#include "ector_renderer_generic_gradient_radial.eo.h"

#endif
