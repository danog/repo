#ifndef EFL_CXX_EDJE_HH
#define EFL_CXX_EDJE_HH

#ifdef EFL_BETA_API_SUPPORT
#include <edje_object.eo.hh>
#include <edje_edit.eo.hh>
#endif

#endif

