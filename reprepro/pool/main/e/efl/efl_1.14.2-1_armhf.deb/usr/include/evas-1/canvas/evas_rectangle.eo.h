#ifndef _EVAS_RECTANGLE_EO_H_
#define _EVAS_RECTANGLE_EO_H_

#ifndef _EVAS_RECTANGLE_EO_CLASS_TYPE
#define _EVAS_RECTANGLE_EO_CLASS_TYPE

typedef Eo Evas_Rectangle;

#endif

#ifndef _EVAS_RECTANGLE_EO_TYPES
#define _EVAS_RECTANGLE_EO_TYPES


#endif
#define EVAS_RECTANGLE_CLASS evas_rectangle_class_get()

EAPI const Eo_Class *evas_rectangle_class_get(void) EINA_CONST;


#endif
