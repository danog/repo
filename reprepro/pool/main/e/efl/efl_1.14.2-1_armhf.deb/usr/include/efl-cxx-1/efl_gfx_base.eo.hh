#ifndef EFL_GENERATED_EFL_GFX_BASE_HH
#define EFL_GENERATED_EFL_GFX_BASE_HH

extern "C"
{
#include <Efl.h>
}
#include <Eo.hh>

#include <eo_cxx_interop.hh>

extern "C"
{
#include "efl_gfx_base.eo.h"
}

#include <string>

namespace efl { namespace gfx {

struct base;

} }

/// @cond EO_CXX_ABSTRACT
namespace eo_cxx {

namespace efl { namespace gfx {

struct base
{
   /// @brief Retrieves the position of the given Evas object.
   ///
   /// @param x in
   /// @param y in
   ///
   void position_get(int* x_, int* y_) const;

   /// @brief Move the given Evas object to the given location inside its canvas' viewport.
   ///
   /// @param x in
   /// @param y in
   ///
   void position_set(int x_, int y_) const;

   /// @brief Retrieves the (rectangular) size of the given Evas object.
   ///
   /// @param w in
   /// @param h in
   ///
   void size_get(int* w_, int* h_) const;

   /// @brief Changes the size of the given Evas object.
   ///
   /// @param w in
   /// @param h in
   ///
   void size_set(int w_, int h_) const;

   /// @brief Retrieves the general/main color of the given Evas object.
   ///
   /// Retrieves the “main” color's RGB component (and alpha channel)
   /// values, <b>which range from 0 to 255</b>. For the alpha channel,
   /// which defines the object's transparency level, 0 means totally
   /// transparent, while 255 means opaque. These color values are
   /// premultiplied by the alpha value.
   ///
   /// Usually you’ll use this attribute for text and rectangle objects,
   /// where the “main” color is their unique one. If set for objects
   /// which themselves have colors, like the images one, those colors get
   /// modulated by this one.
   ///
   /// @note All newly created Evas rectangles get the default color
   /// values of <code>255 255 255 255</code> (opaque white).
   ///
   /// @note Use @c NULL pointers on the components you're not interested
   /// in: they'll be ignored by the function.
   ///
   /// Example:
   /// @dontinclude evas-object-manipulation.c
   /// @skip int alpha, r, g, b;
   /// @until return
   ///
   /// See the full @ref Example_Evas_Object_Manipulation "example".
   ///
   /// @ingroup Evas_Object_Group_Basic
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   void color_get(int* r_, int* g_, int* b_, int* a_) const;

   /// @brief Sets the general/main color of the given Evas object to the given
   /// one.
   ///
   /// @see evas_object_color_get() (for an example)
   /// @note These color values are expected to be premultiplied by @p a.
   ///
   /// @ingroup Evas_Object_Group_Basic
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   void color_set(int r_, int g_, int b_, int a_) const;

   /// @brief Retrieves a specific color of the given Evas object.
   ///
   /// Retrieves a specific color's RGB component (and alpha channel)
   /// values, <b>which range from 0 to 255</b>. For the alpha channel,
   /// which defines the object's transparency level, 0 means totally
   /// transparent, while 255 means opaque. These color values are
   /// premultiplied by the alpha value.
   ///
   /// The “main“ color being mapped to @c NULL.
   ///
   /// Usually you’ll use this attribute for text and rectangle objects,
   /// where the “main” color is their unique one. If set for objects
   /// which themselves have colors, like the images one, those colors get
   /// modulated by this one.
   ///
   /// @note Use @c NULL pointers on the components you're not interested
   /// in: they'll be ignored by the function.
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   bool color_part_get(::efl::eina::string_view part_, int* r_, int* g_, int* b_, int* a_) const;

   /// @brief Sets a specifc color of the given Efl.Gfx.Base object to the given
   /// one.
   ///
   /// @see evas_object_color_get() (for an example)
   /// @note These color values are expected to be premultiplied by @p a.
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   bool color_part_set(::efl::eina::string_view part_, int r_, int g_, int b_, int a_) const;

   /// @brief Retrieves whether or not the given Evas object is visible.
   ///
   /// @param v @c EINA_TRUE if to make the object visible, @c EINA_FALSE otherwise
   ///
   bool visible_get() const;

   /// @brief Makes the given Evas object visible or invisible.
   ///
   /// @param v @c EINA_TRUE if to make the object visible, @c EINA_FALSE otherwise
   ///
   void visible_set(bool v_) const;



   static Eo_Class const* _eo_class()
   {
      return(EFL_GFX_BASE_INTERFACE);
   }

   operator ::efl::gfx::base() const;
   operator ::efl::gfx::base&();
   operator ::efl::gfx::base const&() const;

   /// @cond LOCAL
   template <typename D>
   struct address_of
   {
      operator ::efl::gfx::base*() const { return static_cast<::efl::gfx::base*>(static_cast<D const*>(this)->p); }
      operator ::efl::gfx::base const*() const { return static_cast<::efl::gfx::base const*>(static_cast<D const*>(this)->p); }
   };

   template <typename D>
   struct address_const_of
   {
      operator ::efl::gfx::base const*() const { return static_cast<::efl::gfx::base const*>(static_cast<D const*>(this)->p); }
   };
   /// @endcond

private:

   /// @internal
   Eo* _concrete_eo_ptr() const
   {
      return static_cast<::efl::eo::concrete const*>(static_cast<void const*>(this))->_eo_ptr();
   }

};

} }

}
/// @endcond

namespace efl { namespace gfx {

/// @brief Class base
struct base
      : ::efl::eo::concrete
{
   //@{
   /**
      @brief Constructs a new efl::gfx::base object.

      Constructs a new efl::gfx::base object. If you want this object to be a child
      of another Eo object, use an @ref efl::eo::parent expression, like the example.

      Example:
      @code
      efl::gfx::base my_base(efl::eo::parent = parent_object);
      @endcode

      @see base(Eo* eo)
   */
   explicit base(::efl::eo::parent_type _p)
      : base(_ctors_call(_p))
   {}

   explicit base()
      : base(_ctors_call(::efl::eo::parent = nullptr))
   {}
   //@}

   /// @brief Eo Constructor.
   ///
   /// Constructs the object from an Eo* pointer stealing its ownership.
   ///
   /// @param eo The Eo object pointer.
   ///
   explicit base(Eo* eo)
      : ::efl::eo::concrete(eo)
   {}

   /// @brief nullptr_t Constructor.
   ///
   /// Constructs an empty (null) object.
   ///
   explicit base(std::nullptr_t)
      : ::efl::eo::concrete(nullptr)
   {}

   /// @brief Copy Constructor.
   ///
   base(base const& other)
      : base(eo_ref(other._eo_ptr()))
   {}

   ~base() {}

   /// @brief Retrieves the position of the given Evas object.
   ///
   /// @param x in
   /// @param y in
   ///
   void position_get(int* x_, int* y_) const;

   /// @brief Move the given Evas object to the given location inside its canvas' viewport.
   ///
   /// @param x in
   /// @param y in
   ///
   void position_set(int x_, int y_) const;

   /// @brief Retrieves the (rectangular) size of the given Evas object.
   ///
   /// @param w in
   /// @param h in
   ///
   void size_get(int* w_, int* h_) const;

   /// @brief Changes the size of the given Evas object.
   ///
   /// @param w in
   /// @param h in
   ///
   void size_set(int w_, int h_) const;

   /// @brief Retrieves the general/main color of the given Evas object.
   ///
   /// Retrieves the “main” color's RGB component (and alpha channel)
   /// values, <b>which range from 0 to 255</b>. For the alpha channel,
   /// which defines the object's transparency level, 0 means totally
   /// transparent, while 255 means opaque. These color values are
   /// premultiplied by the alpha value.
   ///
   /// Usually you’ll use this attribute for text and rectangle objects,
   /// where the “main” color is their unique one. If set for objects
   /// which themselves have colors, like the images one, those colors get
   /// modulated by this one.
   ///
   /// @note All newly created Evas rectangles get the default color
   /// values of <code>255 255 255 255</code> (opaque white).
   ///
   /// @note Use @c NULL pointers on the components you're not interested
   /// in: they'll be ignored by the function.
   ///
   /// Example:
   /// @dontinclude evas-object-manipulation.c
   /// @skip int alpha, r, g, b;
   /// @until return
   ///
   /// See the full @ref Example_Evas_Object_Manipulation "example".
   ///
   /// @ingroup Evas_Object_Group_Basic
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   void color_get(int* r_, int* g_, int* b_, int* a_) const;

   /// @brief Sets the general/main color of the given Evas object to the given
   /// one.
   ///
   /// @see evas_object_color_get() (for an example)
   /// @note These color values are expected to be premultiplied by @p a.
   ///
   /// @ingroup Evas_Object_Group_Basic
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   void color_set(int r_, int g_, int b_, int a_) const;

   /// @brief Retrieves a specific color of the given Evas object.
   ///
   /// Retrieves a specific color's RGB component (and alpha channel)
   /// values, <b>which range from 0 to 255</b>. For the alpha channel,
   /// which defines the object's transparency level, 0 means totally
   /// transparent, while 255 means opaque. These color values are
   /// premultiplied by the alpha value.
   ///
   /// The “main“ color being mapped to @c NULL.
   ///
   /// Usually you’ll use this attribute for text and rectangle objects,
   /// where the “main” color is their unique one. If set for objects
   /// which themselves have colors, like the images one, those colors get
   /// modulated by this one.
   ///
   /// @note Use @c NULL pointers on the components you're not interested
   /// in: they'll be ignored by the function.
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   bool color_part_get(::efl::eina::string_view part_, int* r_, int* g_, int* b_, int* a_) const;

   /// @brief Sets a specifc color of the given Efl.Gfx.Base object to the given
   /// one.
   ///
   /// @see evas_object_color_get() (for an example)
   /// @note These color values are expected to be premultiplied by @p a.
   ///
   /// @param r The red component of the given color.
   /// @param g The green component of the given color.
   /// @param b The blue component of the given color.
   /// @param a The alpha component of the given color.
   ///
   bool color_part_set(::efl::eina::string_view part_, int r_, int g_, int b_, int a_) const;

   /// @brief Retrieves whether or not the given Evas object is visible.
   ///
   /// @param v @c EINA_TRUE if to make the object visible, @c EINA_FALSE otherwise
   ///
   bool visible_get() const;

   /// @brief Makes the given Evas object visible or invisible.
   ///
   /// @param v @c EINA_TRUE if to make the object visible, @c EINA_FALSE otherwise
   ///
   void visible_set(bool v_) const;



   static Eo_Class const* _eo_class()
   {
      return(EFL_GFX_BASE_INTERFACE);
   }

   /// @cond LOCAL
   struct address_of
      : ::eo_cxx::efl::gfx::base::address_of<address_of>
      , ::efl::eo::detail::concrete_address_of
   {
      explicit address_of(::efl::gfx::base* p)
         : ::efl::eo::detail::concrete_address_of(p)
      {}
   };
   address_of operator&() { return address_of(this); }

   struct address_const_of
      : ::eo_cxx::efl::gfx::base::address_const_of<address_const_of>
      , ::efl::eo::detail::concrete_address_const_of
   {
      explicit address_const_of(::efl::gfx::base const* p)
         : ::efl::eo::detail::concrete_address_const_of(p)
      {}
   };
   address_const_of operator&() const { return address_const_of(this); }

   /// @endcond

private:

   /// @internal
   static Eo* _ctors_call(::efl::eo::parent_type _p)
   {
      Eo* _ret_eo = eo_add_ref(EFL_GFX_BASE_INTERFACE, _p._eo_raw);

      return _ret_eo;
   }

   /// @internal
   Eo* _concrete_eo_ptr() const { return _eo_ptr(); }
};

static_assert(sizeof(::efl::gfx::base) == sizeof(Eo*), "");
static_assert(std::is_standard_layout<::efl::gfx::base>::value, "");

} }


#include "efl_gfx_base.eo.impl.hh"

#endif // EFL_GENERATED_EFL_GFX_BASE_HH

