#ifndef EFL_GENERATED_EFL_FILE_HH
#define EFL_GENERATED_EFL_FILE_HH

extern "C"
{
#include <Efl.h>
}
#include <Eo.hh>

#include <eo_cxx_interop.hh>

extern "C"
{
#include "efl_file.eo.h"
}

#include <string>

namespace efl {

struct file;

}

/// @cond EO_CXX_ABSTRACT
namespace eo_cxx {

namespace efl {

struct file
{
   /// @brief Save the given image object's contents to an (image) file.
   ///
   /// The extension suffix on @p file will determine which <b>saver
   /// module</b> Evas is to use when saving, thus the final file's
   /// format. If the file supports multiple data stored in it (Eet ones),
   /// you can specify the key to be used as the index of the image in it.
   ///
   /// You can specify some flags when saving the image.  Currently
   /// acceptable flags are @c quality and @c compress. Eg.: @c
   /// "quality=100 compress=9"
   ///
   /// @param file The filename to be used to save the image (extension
   /// obligatory).
   /// @param key The image key in the file (if an Eet one), or @c NULL,
   /// otherwise.
   /// @param flags String containing the flags to be used (@c NULL for
   /// none).
   ///
   bool save(::efl::eina::string_view file_, ::efl::eina::string_view key_, ::efl::eina::string_view flags_) const;

   /// @brief Eject the represented object.
   ///
   /// Get rid of and clean the pointed resource.
   ///
   void eject() const;

   /// @brief Block and wait until all asynchronous operations are completed. Unless
   /// the async flag was set on this object, this method has no effect.
   ///
   /// Returns false if an error occured.
   ///
   bool async_wait() const;

   /// @brief Get the source mmaped file from where an image object must fetch the real
   /// image data (it must be an Eina_File).
   ///
   /// If the file supports multiple data stored in it (as Eet files do),
   /// you can get the key to be used as the index of the image in
   /// this file.
   ///
   /// @since 1.10
   ///
   /// @param f The mmaped file
   /// @param key The image key in @p file (if its an Eet one), or @c
   /// NULL, otherwise.
   ///
   void mmap_get(const Eina_File ** f_, const char ** key_) const;

   /// @brief Set the source mmaped file from where an image object must fetch the real
   /// image data (it must be an Eina_File).
   ///
   /// If the file supports multiple data stored in it (as Eet files do),
   /// you can specify the key to be used as the index of the image in
   /// this file.
   ///
   /// @since 1.8
   ///
   /// @param f The mmaped file
   /// @param key The image key in @p file (if its an Eet one), or @c
   /// NULL, otherwise.
   ///
   bool mmap_set(const Eina_File * f_, ::efl::eina::string_view key_) const;

   /// @brief Retrieve the source file from where an image object is to fetch the
   /// real image data (it may be an Eet file, besides pure image ones).
   ///
   /// You must @b not modify the strings on the returned pointers.
   ///
   /// @note Use @c NULL pointers on the file components you're not
   /// interested in: they'll be ignored by the function.
   ///
   /// @param file The image file path.
   /// @param key The image key in @p file (if its an Eet one), or @c
   /// NULL, otherwise.
   ///
   void file_get(const char ** file_, const char ** key_) const;

   /// @brief Set the source file from where an image object must fetch the real
   /// image data (it may be an Eet file, besides pure image ones).
   ///
   /// If the file supports multiple data stored in it (as Eet files do),
   /// you can specify the key to be used as the index of the image in
   /// this file.
   ///
   /// Example:
   /// @code
   /// img = evas_object_image_add(canvas);
   /// evas_object_image_file_set(img, "/path/to/img", NULL);
   /// err = evas_object_image_load_error_get(img);
   /// if (err != EVAS_LOAD_ERROR_NONE)
   /// {
   /// fprintf(stderr, "could not load image '%s'. error string is \"%s\"\n",
   /// valid_path, evas_load_error_str(err));
   /// }
   /// else
   /// {
   /// evas_object_image_fill_set(img, 0, 0, w, h);
   /// evas_object_resize(img, w, h);
   /// evas_object_show(img);
   /// }
   /// @endcode
   ///
   /// @param file The image file path.
   /// @param key The image key in @p file (if its an Eet one), or @c
   /// NULL, otherwise.
   ///
   bool file_set(::efl::eina::string_view file_, ::efl::eina::string_view key_) const;

   /// @brief Retrieves the asynchronous open flag, which will be true only if
   /// enabled and supported by the object.
   ///
   /// @param async Flag for asynchronous open.
   ///
   bool async_get() const;

   /// @brief If true, file open will happen asynchronously allowing for better
   /// performance in some situations. The file will be opened from a
   /// different thread. Classes implementing async open might then block
   /// and wait when querying information from the file (eg. image size).
   ///
   /// Only a few objects implement this feature, and this flag may
   /// be ignored by EFL. In that case, get() will always return false.
   ///
   /// @param async Flag for asynchronous open.
   ///
   void async_set(bool async_) const;

   /// The file was successfully opened asynchronously
   template <typename F>
   ::efl::eo::signal_connection
   callback_async_opened_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_FILE_EVENT_ASYNC_OPENED, priority_,
            &::efl::eo::_detail::event_callback<::efl::file, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::file, function_type>,
         EFL_FILE_EVENT_ASYNC_OPENED );
   }

   /// The file was successfully opened asynchronously
   template <typename T>
   void
   callback_async_opened_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_FILE_EVENT_ASYNC_OPENED, info));
   }

   /// Error occured in asynchronous file operation
   template <typename F>
   ::efl::eo::signal_connection
   callback_async_error_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_FILE_EVENT_ASYNC_ERROR, priority_,
            &::efl::eo::_detail::event_callback<::efl::file, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::file, function_type>,
         EFL_FILE_EVENT_ASYNC_ERROR );
   }

   /// Error occured in asynchronous file operation
   template <typename T>
   void
   callback_async_error_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_FILE_EVENT_ASYNC_ERROR, info));
   }



   static Eo_Class const* _eo_class()
   {
      return(EFL_FILE_INTERFACE);
   }

   operator ::efl::file() const;
   operator ::efl::file&();
   operator ::efl::file const&() const;

   /// @cond LOCAL
   template <typename D>
   struct address_of
   {
      operator ::efl::file*() const { return static_cast<::efl::file*>(static_cast<D const*>(this)->p); }
      operator ::efl::file const*() const { return static_cast<::efl::file const*>(static_cast<D const*>(this)->p); }
   };

   template <typename D>
   struct address_const_of
   {
      operator ::efl::file const*() const { return static_cast<::efl::file const*>(static_cast<D const*>(this)->p); }
   };
   /// @endcond

private:

   /// @internal
   Eo* _concrete_eo_ptr() const
   {
      return static_cast<::efl::eo::concrete const*>(static_cast<void const*>(this))->_eo_ptr();
   }

};

}

}
/// @endcond

namespace efl {

/// @brief Class file
struct file
      : ::efl::eo::concrete
{
   //@{
   /**
      @brief Constructs a new efl::file object.

      Constructs a new efl::file object. If you want this object to be a child
      of another Eo object, use an @ref efl::eo::parent expression, like the example.

      Example:
      @code
      efl::file my_file(efl::eo::parent = parent_object);
      @endcode

      @see file(Eo* eo)
   */
   explicit file(::efl::eo::parent_type _p)
      : file(_ctors_call(_p))
   {}

   explicit file()
      : file(_ctors_call(::efl::eo::parent = nullptr))
   {}
   //@}

   /// @brief Eo Constructor.
   ///
   /// Constructs the object from an Eo* pointer stealing its ownership.
   ///
   /// @param eo The Eo object pointer.
   ///
   explicit file(Eo* eo)
      : ::efl::eo::concrete(eo)
   {}

   /// @brief nullptr_t Constructor.
   ///
   /// Constructs an empty (null) object.
   ///
   explicit file(std::nullptr_t)
      : ::efl::eo::concrete(nullptr)
   {}

   /// @brief Copy Constructor.
   ///
   file(file const& other)
      : file(eo_ref(other._eo_ptr()))
   {}

   ~file() {}

   /// @brief Save the given image object's contents to an (image) file.
   ///
   /// The extension suffix on @p file will determine which <b>saver
   /// module</b> Evas is to use when saving, thus the final file's
   /// format. If the file supports multiple data stored in it (Eet ones),
   /// you can specify the key to be used as the index of the image in it.
   ///
   /// You can specify some flags when saving the image.  Currently
   /// acceptable flags are @c quality and @c compress. Eg.: @c
   /// "quality=100 compress=9"
   ///
   /// @param file The filename to be used to save the image (extension
   /// obligatory).
   /// @param key The image key in the file (if an Eet one), or @c NULL,
   /// otherwise.
   /// @param flags String containing the flags to be used (@c NULL for
   /// none).
   ///
   bool save(::efl::eina::string_view file_, ::efl::eina::string_view key_, ::efl::eina::string_view flags_) const;

   /// @brief Eject the represented object.
   ///
   /// Get rid of and clean the pointed resource.
   ///
   void eject() const;

   /// @brief Block and wait until all asynchronous operations are completed. Unless
   /// the async flag was set on this object, this method has no effect.
   ///
   /// Returns false if an error occured.
   ///
   bool async_wait() const;

   /// @brief Get the source mmaped file from where an image object must fetch the real
   /// image data (it must be an Eina_File).
   ///
   /// If the file supports multiple data stored in it (as Eet files do),
   /// you can get the key to be used as the index of the image in
   /// this file.
   ///
   /// @since 1.10
   ///
   /// @param f The mmaped file
   /// @param key The image key in @p file (if its an Eet one), or @c
   /// NULL, otherwise.
   ///
   void mmap_get(const Eina_File ** f_, const char ** key_) const;

   /// @brief Set the source mmaped file from where an image object must fetch the real
   /// image data (it must be an Eina_File).
   ///
   /// If the file supports multiple data stored in it (as Eet files do),
   /// you can specify the key to be used as the index of the image in
   /// this file.
   ///
   /// @since 1.8
   ///
   /// @param f The mmaped file
   /// @param key The image key in @p file (if its an Eet one), or @c
   /// NULL, otherwise.
   ///
   bool mmap_set(const Eina_File * f_, ::efl::eina::string_view key_) const;

   /// @brief Retrieve the source file from where an image object is to fetch the
   /// real image data (it may be an Eet file, besides pure image ones).
   ///
   /// You must @b not modify the strings on the returned pointers.
   ///
   /// @note Use @c NULL pointers on the file components you're not
   /// interested in: they'll be ignored by the function.
   ///
   /// @param file The image file path.
   /// @param key The image key in @p file (if its an Eet one), or @c
   /// NULL, otherwise.
   ///
   void file_get(const char ** file_, const char ** key_) const;

   /// @brief Set the source file from where an image object must fetch the real
   /// image data (it may be an Eet file, besides pure image ones).
   ///
   /// If the file supports multiple data stored in it (as Eet files do),
   /// you can specify the key to be used as the index of the image in
   /// this file.
   ///
   /// Example:
   /// @code
   /// img = evas_object_image_add(canvas);
   /// evas_object_image_file_set(img, "/path/to/img", NULL);
   /// err = evas_object_image_load_error_get(img);
   /// if (err != EVAS_LOAD_ERROR_NONE)
   /// {
   /// fprintf(stderr, "could not load image '%s'. error string is \"%s\"\n",
   /// valid_path, evas_load_error_str(err));
   /// }
   /// else
   /// {
   /// evas_object_image_fill_set(img, 0, 0, w, h);
   /// evas_object_resize(img, w, h);
   /// evas_object_show(img);
   /// }
   /// @endcode
   ///
   /// @param file The image file path.
   /// @param key The image key in @p file (if its an Eet one), or @c
   /// NULL, otherwise.
   ///
   bool file_set(::efl::eina::string_view file_, ::efl::eina::string_view key_) const;

   /// @brief Retrieves the asynchronous open flag, which will be true only if
   /// enabled and supported by the object.
   ///
   /// @param async Flag for asynchronous open.
   ///
   bool async_get() const;

   /// @brief If true, file open will happen asynchronously allowing for better
   /// performance in some situations. The file will be opened from a
   /// different thread. Classes implementing async open might then block
   /// and wait when querying information from the file (eg. image size).
   ///
   /// Only a few objects implement this feature, and this flag may
   /// be ignored by EFL. In that case, get() will always return false.
   ///
   /// @param async Flag for asynchronous open.
   ///
   void async_set(bool async_) const;

   /// Error occured in asynchronous file operation
   template <typename F>
   ::efl::eo::signal_connection
   callback_async_error_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_FILE_EVENT_ASYNC_ERROR, priority_,
            &::efl::eo::_detail::event_callback<::efl::file, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::file, function_type>,
         EFL_FILE_EVENT_ASYNC_ERROR );
   }

   /// Error occured in asynchronous file operation
   template <typename T>
   void
   callback_async_error_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_FILE_EVENT_ASYNC_ERROR, info));
   }

   /// The file was successfully opened asynchronously
   template <typename F>
   ::efl::eo::signal_connection
   callback_async_opened_add(F && callback_,
                        ::efl::eo::callback_priority priority_ =
                        ::efl::eo::callback_priorities::default_)
   {
      typedef typename std::remove_reference<F>::type function_type;
      ::std::unique_ptr<function_type> f ( new function_type(std::forward<F>(callback_)) );
      eo_do(_concrete_eo_ptr(),
            eo_event_callback_priority_add
            (EFL_FILE_EVENT_ASYNC_OPENED, priority_,
            &::efl::eo::_detail::event_callback<::efl::file, function_type>, f.get()));
      return ::efl::eo::make_signal_connection
         (f, _concrete_eo_ptr(), &::efl::eo::_detail::event_callback<::efl::file, function_type>,
         EFL_FILE_EVENT_ASYNC_OPENED );
   }

   /// The file was successfully opened asynchronously
   template <typename T>
   void
   callback_async_opened_call(T* info)
   {
      eo_do(_concrete_eo_ptr(), eo_event_callback_call
            (EFL_FILE_EVENT_ASYNC_OPENED, info));
   }



   static Eo_Class const* _eo_class()
   {
      return(EFL_FILE_INTERFACE);
   }

   /// @cond LOCAL
   struct address_of
      : ::eo_cxx::efl::file::address_of<address_of>
      , ::efl::eo::detail::concrete_address_of
   {
      explicit address_of(::efl::file* p)
         : ::efl::eo::detail::concrete_address_of(p)
      {}
   };
   address_of operator&() { return address_of(this); }

   struct address_const_of
      : ::eo_cxx::efl::file::address_const_of<address_const_of>
      , ::efl::eo::detail::concrete_address_const_of
   {
      explicit address_const_of(::efl::file const* p)
         : ::efl::eo::detail::concrete_address_const_of(p)
      {}
   };
   address_const_of operator&() const { return address_const_of(this); }

   /// @endcond

private:

   /// @internal
   static Eo* _ctors_call(::efl::eo::parent_type _p)
   {
      Eo* _ret_eo = eo_add_ref(EFL_FILE_INTERFACE, _p._eo_raw);

      return _ret_eo;
   }

   /// @internal
   Eo* _concrete_eo_ptr() const { return _eo_ptr(); }
};

static_assert(sizeof(::efl::file) == sizeof(Eo*), "");
static_assert(std::is_standard_layout<::efl::file>::value, "");

}


#include "efl_file.eo.impl.hh"

#endif // EFL_GENERATED_EFL_FILE_HH

