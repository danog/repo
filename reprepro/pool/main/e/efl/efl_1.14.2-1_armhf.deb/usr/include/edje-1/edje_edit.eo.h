#ifndef _EDJE_EDIT_EO_H_
#define _EDJE_EDIT_EO_H_

#ifndef _EDJE_EDIT_EO_CLASS_TYPE
#define _EDJE_EDIT_EO_CLASS_TYPE

typedef Eo Edje_Edit;

#endif

#ifndef _EDJE_EDIT_EO_TYPES
#define _EDJE_EDIT_EO_TYPES


#endif
#define EDJE_EDIT_CLASS edje_edit_class_get()

EAPI const Eo_Class *edje_edit_class_get(void) EINA_CONST;


#endif
