#ifndef _EFL_VG_GRADIENT_EO_LEGACY_H_
#define _EFL_VG_GRADIENT_EO_LEGACY_H_

#ifndef _EFL_VG_GRADIENT_EO_CLASS_TYPE
#define _EFL_VG_GRADIENT_EO_CLASS_TYPE

typedef Eo Efl_VG_Gradient;

#endif

#ifndef _EFL_VG_GRADIENT_EO_TYPES
#define _EFL_VG_GRADIENT_EO_TYPES


#endif

#endif
