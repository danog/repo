#ifndef _EVAS_3D_OBJECT_EO_LEGACY_H_
#define _EVAS_3D_OBJECT_EO_LEGACY_H_

#ifndef _EVAS_3D_OBJECT_EO_CLASS_TYPE
#define _EVAS_3D_OBJECT_EO_CLASS_TYPE

typedef Eo Evas_3D_Object;

#endif

#ifndef _EVAS_3D_OBJECT_EO_TYPES
#define _EVAS_3D_OBJECT_EO_TYPES


#endif

#endif
