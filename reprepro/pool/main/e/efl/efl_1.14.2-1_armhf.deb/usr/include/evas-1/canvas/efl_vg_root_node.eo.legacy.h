#ifndef _EFL_VG_ROOT_NODE_EO_LEGACY_H_
#define _EFL_VG_ROOT_NODE_EO_LEGACY_H_

#ifndef _EFL_VG_ROOT_NODE_EO_CLASS_TYPE
#define _EFL_VG_ROOT_NODE_EO_CLASS_TYPE

typedef Eo Efl_VG_Root_Node;

#endif

#ifndef _EFL_VG_ROOT_NODE_EO_TYPES
#define _EFL_VG_ROOT_NODE_EO_TYPES


#endif

#endif
