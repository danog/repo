/// @cond EO_CXX_EO_IMPL

inline ssize_t ecore_audio_in::read(void * buf_, size_t len_) const
{
   ssize_t _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_read(buf_, len_));
   return _tmp_ret;
}

inline ssize_t ecore_audio_in::read_internal(void * buf_, size_t len_) const
{
   ssize_t _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_read_internal(buf_, len_));
   return _tmp_ret;
}

inline double ecore_audio_in::seek(double offs_, int mode_) const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_seek(offs_, mode_));
   return _tmp_ret;
}

inline double ecore_audio_in::speed_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_speed_get());
   return _tmp_ret;
}

inline void ecore_audio_in::speed_set(double speed_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_speed_set(speed_));
}

inline int ecore_audio_in::samplerate_get() const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_samplerate_get());
   return _tmp_ret;
}

inline void ecore_audio_in::samplerate_set(int samplerate_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_samplerate_set(samplerate_));
}

inline int ecore_audio_in::channels_get() const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_channels_get());
   return _tmp_ret;
}

inline void ecore_audio_in::channels_set(int channels_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_channels_set(channels_));
}

inline bool ecore_audio_in::preloaded_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_preloaded_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void ecore_audio_in::preloaded_set(bool preloaded_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_preloaded_set(::efl::eolian::to_c(preloaded_)));
}

inline bool ecore_audio_in::looped_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_looped_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void ecore_audio_in::looped_set(bool looped_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_looped_set(::efl::eolian::to_c(looped_)));
}

inline double ecore_audio_in::length_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_length_get());
   return _tmp_ret;
}

inline void ecore_audio_in::length_set(double length_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_length_set(length_));
}

inline ::efl::eo::concrete ecore_audio_in::output_get() const
{
   Eo * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_output_get());
   return ::efl::eolian::to_cxx<::efl::eo::concrete>(_tmp_ret, std::tuple<std::false_type>());
}

inline double ecore_audio_in::remaining_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_remaining_get());
   return _tmp_ret;
}

inline ssize_t eo_cxx::ecore_audio_in::read(void * buf_, size_t len_) const
{
   ssize_t _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_read(buf_, len_));
   return _tmp_ret;
}

inline ssize_t eo_cxx::ecore_audio_in::read_internal(void * buf_, size_t len_) const
{
   ssize_t _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_read_internal(buf_, len_));
   return _tmp_ret;
}

inline double eo_cxx::ecore_audio_in::seek(double offs_, int mode_) const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_seek(offs_, mode_));
   return _tmp_ret;
}

inline double eo_cxx::ecore_audio_in::speed_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_speed_get());
   return _tmp_ret;
}

inline void eo_cxx::ecore_audio_in::speed_set(double speed_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_speed_set(speed_));
}

inline int eo_cxx::ecore_audio_in::samplerate_get() const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_samplerate_get());
   return _tmp_ret;
}

inline void eo_cxx::ecore_audio_in::samplerate_set(int samplerate_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_samplerate_set(samplerate_));
}

inline int eo_cxx::ecore_audio_in::channels_get() const
{
   int _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_channels_get());
   return _tmp_ret;
}

inline void eo_cxx::ecore_audio_in::channels_set(int channels_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_channels_set(channels_));
}

inline bool eo_cxx::ecore_audio_in::preloaded_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_preloaded_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::ecore_audio_in::preloaded_set(bool preloaded_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_preloaded_set(::efl::eolian::to_c(preloaded_)));
}

inline bool eo_cxx::ecore_audio_in::looped_get() const
{
   Eina_Bool _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_looped_get());
   return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
}

inline void eo_cxx::ecore_audio_in::looped_set(bool looped_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_looped_set(::efl::eolian::to_c(looped_)));
}

inline double eo_cxx::ecore_audio_in::length_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_length_get());
   return _tmp_ret;
}

inline void eo_cxx::ecore_audio_in::length_set(double length_) const
{
   eo_do(_concrete_eo_ptr(), ::ecore_audio_obj_in_length_set(length_));
}

inline ::efl::eo::concrete eo_cxx::ecore_audio_in::output_get() const
{
   Eo * _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_output_get());
   return ::efl::eolian::to_cxx<::efl::eo::concrete>(_tmp_ret, std::tuple<std::false_type>());
}

inline double eo_cxx::ecore_audio_in::remaining_get() const
{
   double _tmp_ret;
   eo_do(_concrete_eo_ptr(), _tmp_ret = ::ecore_audio_obj_in_remaining_get());
   return _tmp_ret;
}

inline ::eo_cxx::ecore_audio_in::operator ::ecore_audio_in() const
{
   return *static_cast<::ecore_audio_in const*>(static_cast<void const*>(this));
}

inline ::eo_cxx::ecore_audio_in::operator ::ecore_audio_in&()
{
   return *static_cast<::ecore_audio_in*>(static_cast<void*>(this));
}

inline ::eo_cxx::ecore_audio_in::operator ::ecore_audio_in const&() const
{
   return *static_cast<::ecore_audio_in const*>(static_cast<void const*>(this));
}

template <typename T>
ssize_t _ecore_audio_in_read_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, void * buf_, size_t len_)
{
   ssize_t _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->read(buf_, len_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
ssize_t _ecore_audio_in_read_internal_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, void * buf_, size_t len_)
{
   ssize_t _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->read_internal(buf_, len_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
double _ecore_audio_in_seek_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, double offs_, int mode_)
{
   double _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->seek(offs_, mode_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
double _ecore_audio_in_speed_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   double _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->speed_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void _ecore_audio_in_speed_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, double speed_)
{
   try
      {
         static_cast<T*>(self->this_)->speed_set(speed_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
int _ecore_audio_in_samplerate_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   int _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->samplerate_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void _ecore_audio_in_samplerate_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, int samplerate_)
{
   try
      {
         static_cast<T*>(self->this_)->samplerate_set(samplerate_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
int _ecore_audio_in_channels_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   int _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->channels_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void _ecore_audio_in_channels_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, int channels_)
{
   try
      {
         static_cast<T*>(self->this_)->channels_set(channels_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool _ecore_audio_in_preloaded_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->preloaded_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void _ecore_audio_in_preloaded_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Eina_Bool preloaded_)
{
   try
      {
         static_cast<T*>(self->this_)->preloaded_set(::efl::eolian::to_cxx<bool>(preloaded_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
bool _ecore_audio_in_looped_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   bool _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->looped_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void _ecore_audio_in_looped_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, Eina_Bool looped_)
{
   try
      {
         static_cast<T*>(self->this_)->looped_set(::efl::eolian::to_cxx<bool>(looped_, std::tuple<std::false_type>()));
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
double _ecore_audio_in_length_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   double _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->length_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
void _ecore_audio_in_length_set_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self, double length_)
{
   try
      {
         static_cast<T*>(self->this_)->length_set(length_);
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
}

template <typename T>
::efl::eo::concrete _ecore_audio_in_output_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   ::efl::eo::concrete _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->output_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

template <typename T>
double _ecore_audio_in_remaining_get_wrapper(Eo* objid EINA_UNUSED, ::efl::eo::detail::Inherit_Private_Data* self)
{
   double _tmp_ret{};
   try
      {
         _tmp_ret = static_cast<T*>(self->this_)->remaining_get();
      }
   catch (...)
      {
         eina_error_set( ::efl::eina::unknown_error() );
      }
   return _tmp_ret;
}

namespace efl { namespace eo { namespace detail {

template<>
struct operations< ::ecore_audio_in >
{
   template <typename T>
   struct type
         : virtual operations< ::ecore_audio >::template type<T>
   {
      virtual ssize_t read(void * buf_, size_t len_)
      {
         ssize_t _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_read(buf_, len_));
            return _tmp_ret;
      }

      virtual ssize_t read_internal(void * buf_, size_t len_)
      {
         ssize_t _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_read_internal(buf_, len_));
            return _tmp_ret;
      }

      virtual double seek(double offs_, int mode_)
      {
         double _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_seek(offs_, mode_));
            return _tmp_ret;
      }

      virtual double speed_get()
      {
         double _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_speed_get());
            return _tmp_ret;
      }

      virtual void speed_set(double speed_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::ecore_audio_obj_in_speed_set(speed_));
      }

      virtual int samplerate_get()
      {
         int _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_samplerate_get());
            return _tmp_ret;
      }

      virtual void samplerate_set(int samplerate_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::ecore_audio_obj_in_samplerate_set(samplerate_));
      }

      virtual int channels_get()
      {
         int _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_channels_get());
            return _tmp_ret;
      }

      virtual void channels_set(int channels_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::ecore_audio_obj_in_channels_set(channels_));
      }

      virtual bool preloaded_get()
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_preloaded_get());
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void preloaded_set(bool preloaded_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::ecore_audio_obj_in_preloaded_set(::efl::eolian::to_c(preloaded_)));
      }

      virtual bool looped_get()
      {
         Eina_Bool _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_looped_get());
            return ::efl::eolian::to_cxx<bool>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual void looped_set(bool looped_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::ecore_audio_obj_in_looped_set(::efl::eolian::to_c(looped_)));
      }

      virtual double length_get()
      {
         double _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_length_get());
            return _tmp_ret;
      }

      virtual void length_set(double length_)
      {

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               ::ecore_audio_obj_in_length_set(length_));
      }

      virtual ::efl::eo::concrete output_get()
      {
         Eo * _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_output_get());
            return ::efl::eolian::to_cxx<::efl::eo::concrete>(_tmp_ret, std::tuple<std::false_type>());
      }

      virtual double remaining_get()
      {
         double _tmp_ret = {};

         eo_do_super(dynamic_cast<T*>(this)->_eo_ptr(),
               dynamic_cast<T*>(this)->_eo_class(),
               _tmp_ret = ::ecore_audio_obj_in_remaining_get());
            return _tmp_ret;
      }

   };
};


#ifdef ECORE_AUDIO_IN_PROTECTED
template<>
struct operation_description_class_size< ::ecore_audio_in >
{
   static constexpr int value = 17 + operation_description_class_size<::ecore_audio >::value;
};

#else
template<>
struct operation_description_class_size< ::ecore_audio_in >
{
   static constexpr int value = 17 + operation_description_class_size<::ecore_audio >::value;
};

#endif

template <typename T>
int initialize_operation_description(::efl::eo::detail::tag<::ecore_audio_in>
                                 , Eo_Op_Description* ops)
{
   (void)ops;
   ops[0].func = reinterpret_cast<void*>(& ::_ecore_audio_in_read_wrapper<T>);
   ops[0].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_read);
   ops[0].op = EO_OP_OVERRIDE;
   ops[0].op_type = EO_OP_TYPE_REGULAR;
   ops[0].doc = NULL;

   ops[1].func = reinterpret_cast<void*>(& ::_ecore_audio_in_read_internal_wrapper<T>);
   ops[1].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_read_internal);
   ops[1].op = EO_OP_OVERRIDE;
   ops[1].op_type = EO_OP_TYPE_REGULAR;
   ops[1].doc = NULL;

   ops[2].func = reinterpret_cast<void*>(& ::_ecore_audio_in_seek_wrapper<T>);
   ops[2].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_seek);
   ops[2].op = EO_OP_OVERRIDE;
   ops[2].op_type = EO_OP_TYPE_REGULAR;
   ops[2].doc = NULL;

   ops[3].func = reinterpret_cast<void*>(& ::_ecore_audio_in_speed_get_wrapper<T>);
   ops[3].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_speed_get);
   ops[3].op = EO_OP_OVERRIDE;
   ops[3].op_type = EO_OP_TYPE_REGULAR;
   ops[3].doc = NULL;

   ops[4].func = reinterpret_cast<void*>(& ::_ecore_audio_in_speed_set_wrapper<T>);
   ops[4].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_speed_set);
   ops[4].op = EO_OP_OVERRIDE;
   ops[4].op_type = EO_OP_TYPE_REGULAR;
   ops[4].doc = NULL;

   ops[5].func = reinterpret_cast<void*>(& ::_ecore_audio_in_samplerate_get_wrapper<T>);
   ops[5].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_samplerate_get);
   ops[5].op = EO_OP_OVERRIDE;
   ops[5].op_type = EO_OP_TYPE_REGULAR;
   ops[5].doc = NULL;

   ops[6].func = reinterpret_cast<void*>(& ::_ecore_audio_in_samplerate_set_wrapper<T>);
   ops[6].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_samplerate_set);
   ops[6].op = EO_OP_OVERRIDE;
   ops[6].op_type = EO_OP_TYPE_REGULAR;
   ops[6].doc = NULL;

   ops[7].func = reinterpret_cast<void*>(& ::_ecore_audio_in_channels_get_wrapper<T>);
   ops[7].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_channels_get);
   ops[7].op = EO_OP_OVERRIDE;
   ops[7].op_type = EO_OP_TYPE_REGULAR;
   ops[7].doc = NULL;

   ops[8].func = reinterpret_cast<void*>(& ::_ecore_audio_in_channels_set_wrapper<T>);
   ops[8].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_channels_set);
   ops[8].op = EO_OP_OVERRIDE;
   ops[8].op_type = EO_OP_TYPE_REGULAR;
   ops[8].doc = NULL;

   ops[9].func = reinterpret_cast<void*>(& ::_ecore_audio_in_preloaded_get_wrapper<T>);
   ops[9].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_preloaded_get);
   ops[9].op = EO_OP_OVERRIDE;
   ops[9].op_type = EO_OP_TYPE_REGULAR;
   ops[9].doc = NULL;

   ops[10].func = reinterpret_cast<void*>(& ::_ecore_audio_in_preloaded_set_wrapper<T>);
   ops[10].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_preloaded_set);
   ops[10].op = EO_OP_OVERRIDE;
   ops[10].op_type = EO_OP_TYPE_REGULAR;
   ops[10].doc = NULL;

   ops[11].func = reinterpret_cast<void*>(& ::_ecore_audio_in_looped_get_wrapper<T>);
   ops[11].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_looped_get);
   ops[11].op = EO_OP_OVERRIDE;
   ops[11].op_type = EO_OP_TYPE_REGULAR;
   ops[11].doc = NULL;

   ops[12].func = reinterpret_cast<void*>(& ::_ecore_audio_in_looped_set_wrapper<T>);
   ops[12].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_looped_set);
   ops[12].op = EO_OP_OVERRIDE;
   ops[12].op_type = EO_OP_TYPE_REGULAR;
   ops[12].doc = NULL;

   ops[13].func = reinterpret_cast<void*>(& ::_ecore_audio_in_length_get_wrapper<T>);
   ops[13].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_length_get);
   ops[13].op = EO_OP_OVERRIDE;
   ops[13].op_type = EO_OP_TYPE_REGULAR;
   ops[13].doc = NULL;

   ops[14].func = reinterpret_cast<void*>(& ::_ecore_audio_in_length_set_wrapper<T>);
   ops[14].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_length_set);
   ops[14].op = EO_OP_OVERRIDE;
   ops[14].op_type = EO_OP_TYPE_REGULAR;
   ops[14].doc = NULL;

   ops[15].func = reinterpret_cast<void*>(& ::_ecore_audio_in_output_get_wrapper<T>);
   ops[15].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_output_get);
   ops[15].op = EO_OP_OVERRIDE;
   ops[15].op_type = EO_OP_TYPE_REGULAR;
   ops[15].doc = NULL;

   ops[16].func = reinterpret_cast<void*>(& ::_ecore_audio_in_remaining_get_wrapper<T>);
   ops[16].api_func = reinterpret_cast<void*>(& ::ecore_audio_obj_in_remaining_get);
   ops[16].op = EO_OP_OVERRIDE;
   ops[16].op_type = EO_OP_TYPE_REGULAR;
   ops[16].doc = NULL;

   initialize_operation_description<T>(::efl::eo::detail::tag<::ecore_audio>(), &ops[operation_description_class_size< ::ecore_audio_in >::value]);
   return 0;
}
inline Eo_Class const* get_eo_class(tag<::ecore_audio_in>)
{
   return (ECORE_AUDIO_IN_CLASS);
}

} } }

/// @endcond

