#ifndef ECORE_AUDIO_PROTECTED_H_
#define ECORE_AUDIO_PROTECTED_H_

#include "Eo.h"
#include "Ecore.h"
#include "Ecore_Audio.h"

#endif
